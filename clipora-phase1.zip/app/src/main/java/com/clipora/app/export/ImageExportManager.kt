package com.clipora.app.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import com.clipora.app.model.EditorState
import com.clipora.app.model.ThemePreset
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

class ImageExportManager(private val context: Context) {
    fun export(state: EditorState): Result<File> = runCatching {
        val input = requireNotNull(state.mediaUri) { "Choose an image first." }
        val bitmap = context.contentResolver.openInputStream(Uri.parse(input)).use { stream ->
            requireNotNull(stream) { "Unable to open image." }
            requireNotNull(BitmapFactory.decodeStream(stream)) { "Unable to decode image." }
        }

        val cropped = centerCrop(bitmap, state.aspectRatio.ratio)
        val mutable = cropped.copy(Bitmap.Config.ARGB_8888, true)
        if (cropped !== bitmap) cropped.recycle()
        if (bitmap !== cropped) bitmap.recycle()

        drawTemplate(Canvas(mutable), mutable.width, mutable.height, state)

        val output = File(context.cacheDir, "clipora_${System.currentTimeMillis()}.jpg")
        FileOutputStream(output).use {
            check(mutable.compress(Bitmap.CompressFormat.JPEG, 94, it)) { "JPEG export failed." }
        }
        mutable.recycle()
        output
    }

    private fun centerCrop(source: Bitmap, ratio: Float): Bitmap {
        val sourceRatio = source.width.toFloat() / source.height
        if (sourceRatio > ratio) {
            val width = (source.height * ratio).roundToInt().coerceAtMost(source.width)
            val x = (source.width - width) / 2
            return Bitmap.createBitmap(source, x, 0, width, source.height)
        }
        val height = (source.width / ratio).roundToInt().coerceAtMost(source.height)
        val y = (source.height - height) / 2
        return Bitmap.createBitmap(source, 0, y, source.width, height)
    }

    private fun drawTemplate(canvas: Canvas, width: Int, height: Int, state: EditorState) {
        val accent = when (state.theme) {
            ThemePreset.NEWS -> Color.rgb(178, 0, 0)
            ThemePreset.WEDDING -> Color.rgb(118, 64, 96)
            ThemePreset.BIRTHDAY -> Color.rgb(110, 68, 170)
            ThemePreset.BUSINESS -> Color.rgb(23, 55, 85)
            ThemePreset.CUSTOM -> Color.rgb(35, 35, 35)
        }
        val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
        val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(220, 20, 20, 20) }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        }

        canvas.drawRect(0f, height * 0.68f, width.toFloat(), height * 0.82f, bar)
        canvas.drawRect(0f, height * 0.88f, width.toFloat(), height.toFloat(), dark)

        text.textSize = (width * 0.055f).coerceAtLeast(24f)
        canvas.drawText(state.logoText.take(18), width * 0.05f, height * 0.10f, text)
        text.textSize = (width * 0.038f).coerceAtLeast(20f)
        canvas.drawText(state.location.take(22), width * 0.62f, height * 0.10f, text)

        text.textSize = (width * 0.052f).coerceAtLeast(24f)
        canvas.drawText(state.headline.take(42), width * 0.05f, height * 0.77f, text)
        text.textSize = (width * 0.038f).coerceAtLeast(20f)
        canvas.drawText(state.ticker.take(60), width * 0.05f, height * 0.95f, text)
    }
}
