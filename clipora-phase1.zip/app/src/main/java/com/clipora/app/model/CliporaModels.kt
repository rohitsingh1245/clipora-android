package com.clipora.app.model

enum class AspectRatioOption(val label: String, val ratio: Float) {
    PORTRAIT("9:16", 9f / 16f),
    LANDSCAPE("16:9", 16f / 9f),
    SQUARE("1:1", 1f),
    SOCIAL("4:5", 4f / 5f)
}

enum class DurationOption(val label: String, val millis: Long) {
    THIRTY_SECONDS("30 sec", 30_000L),
    ONE_MINUTE("1 min", 60_000L),
    TWO_MINUTES("2 min", 120_000L)
}

enum class ThemePreset(val title: String, val subtitle: String) {
    NEWS("News", "Breaking news, headline, location and ticker"),
    WEDDING("Wedding", "Elegant title and celebration lower-third"),
    BIRTHDAY("Birthday", "Bright celebration layout"),
    BUSINESS("Business", "Clean professional lower-third"),
    CUSTOM("Custom", "Start with editable layers")
}

data class EditorState(
    val mediaUri: String? = null,
    val aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT,
    val duration: DurationOption = DurationOption.THIRTY_SECONDS,
    val theme: ThemePreset = ThemePreset.NEWS,
    val headline: String = "Your headline goes here",
    val ticker: String = "Add your scrolling ticker text here",
    val location: String = "LONDON",
    val logoText: String = "CLIPORA",
    val trimStartMs: Long = 0L,
    val sourceDurationMs: Long = 0L,
    val exportStatus: String? = null
) {
    val effectiveEndMs: Long?
        get() {
            if (sourceDurationMs <= 0L) return trimStartMs + duration.millis
            val requested = trimStartMs + duration.millis
            return requested.takeIf { it < sourceDurationMs }
        }
}
