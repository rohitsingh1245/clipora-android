package com.clipora.app.media

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import com.clipora.app.model.EditorState
import com.clipora.app.model.ThemePreset

@UnstableApi
object CliporaVideoEffects {
    fun aspectRatioOnly(state: EditorState): List<Effect> = listOf(
        Presentation.createForAspectRatio(
            state.aspectRatio.ratio,
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        )
    )

    fun exportEffects(state: EditorState): List<Effect> {
        val effects = aspectRatioOnly(state).toMutableList()
        val overlays = mutableListOf<TextureOverlay>()

        fun addText(text: String, x: Float, y: Float, scale: Float, background: Int) {
            if (text.isBlank()) return
            val styled = SpannableString(text.trim()).apply {
                setSpan(ForegroundColorSpan(Color.WHITE), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(BackgroundColorSpan(background), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(StyleSpan(Typeface.BOLD), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            val settings = StaticOverlaySettings.Builder()
                .setBackgroundFrameAnchor(x, y)
                .setScale(scale, scale)
                .build()
            overlays += TextOverlay.createStaticTextOverlay(styled, settings)
        }

        val accent = when (state.theme) {
            ThemePreset.NEWS -> Color.rgb(178, 0, 0)
            ThemePreset.WEDDING -> Color.rgb(118, 64, 96)
            ThemePreset.BIRTHDAY -> Color.rgb(110, 68, 170)
            ThemePreset.BUSINESS -> Color.rgb(23, 55, 85)
            ThemePreset.CUSTOM -> Color.rgb(35, 35, 35)
        }

        addText(state.logoText, -0.72f, 0.82f, 0.38f, accent)
        addText(state.location, 0.62f, 0.82f, 0.32f, Color.rgb(45, 45, 45))
        addText(state.headline, 0f, -0.56f, 0.48f, accent)
        addText(state.ticker, 0f, -0.88f, 0.30f, Color.rgb(25, 25, 25))

        if (overlays.isNotEmpty()) effects += OverlayEffect(overlays)
        return effects
    }
}
