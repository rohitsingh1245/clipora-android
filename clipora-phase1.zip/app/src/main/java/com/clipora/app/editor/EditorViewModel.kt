package com.clipora.app.editor

import androidx.lifecycle.ViewModel
import com.clipora.app.model.AspectRatioOption
import com.clipora.app.model.DurationOption
import com.clipora.app.model.EditorState
import com.clipora.app.model.ThemePreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class EditorViewModel : ViewModel() {
    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()

    fun setMediaUri(uri: String) = _state.update {
        it.copy(mediaUri = uri, trimStartMs = 0L, sourceDurationMs = 0L, exportStatus = null)
    }

    fun setSourceDuration(durationMs: Long) = _state.update {
        it.copy(sourceDurationMs = durationMs.coerceAtLeast(0L))
    }

    fun setAspectRatio(value: AspectRatioOption) = _state.update { it.copy(aspectRatio = value) }
    fun setDuration(value: DurationOption) = _state.update { it.copy(duration = value) }
    fun setTheme(value: ThemePreset) = _state.update { it.copy(theme = value) }
    fun setHeadline(value: String) = _state.update { it.copy(headline = value) }
    fun setTicker(value: String) = _state.update { it.copy(ticker = value) }
    fun setLocation(value: String) = _state.update { it.copy(location = value) }
    fun setLogoText(value: String) = _state.update { it.copy(logoText = value) }

    fun setTrimStart(valueMs: Long) = _state.update { current ->
        val maxStart = (current.sourceDurationMs - 1_000L).coerceAtLeast(0L)
        current.copy(trimStartMs = valueMs.coerceIn(0L, maxStart))
    }

    fun setExportStatus(message: String?) = _state.update { it.copy(exportStatus = message) }
}
