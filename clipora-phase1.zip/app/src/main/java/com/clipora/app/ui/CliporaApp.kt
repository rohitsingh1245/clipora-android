package com.clipora.app.ui

import android.net.Uri
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.clipora.app.editor.EditorViewModel
import com.clipora.app.export.ImageExportManager
import com.clipora.app.export.VideoExportManager
import com.clipora.app.model.*
import kotlin.math.roundToLong

private enum class Screen { HOME, VIDEO, IMAGE, THEMES, PROJECTS }

@Composable
fun CliporaApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    when (screen) {
        Screen.HOME -> HomeScreen(
            onVideo = { screen = Screen.VIDEO },
            onImage = { screen = Screen.IMAGE },
            onThemes = { screen = Screen.THEMES },
            onProjects = { screen = Screen.PROJECTS }
        )
        Screen.VIDEO -> VideoEditorScreen(onBack = { screen = Screen.HOME })
        Screen.IMAGE -> ImageEditorScreen(onBack = { screen = Screen.HOME })
        Screen.THEMES -> SimpleListScreen("Themes", ThemePreset.entries.map { "${it.title} — ${it.subtitle}" }) { screen = Screen.HOME }
        Screen.PROJECTS -> SimpleListScreen(
            "My Projects",
            listOf("Phase 1 keeps project state in memory.", "Persistent project drafts are the next storage milestone.")
        ) { screen = Screen.HOME }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(onVideo: () -> Unit, onImage: () -> Unit, onThemes: () -> Unit, onProjects: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Clipora") }) }) { padding ->
        Column(
            Modifier.padding(padding).padding(20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Create polished themed content from your own media.", style = MaterialTheme.typography.titleMedium)
            ActionCard("Create Video", "Import, crop, trim, theme, preview and export MP4", onVideo)
            ActionCard("Create Image", "Import, crop, theme and export JPG", onImage)
            ActionCard("My Themes", "News, Wedding, Birthday, Business and Custom", onThemes)
            ActionCard("My Projects", "Project persistence scaffold", onProjects)
            Text("Phase 1 test build: login/subscription gate is bypassed.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, action: () -> Unit) {
    Card(onClick = action, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun VideoEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { vm.setMediaUri(it.toString()) }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Video editor") }, navigationIcon = { OutlinedButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Button(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            }) { Text(if (state.mediaUri == null) "Import video" else "Change video") }

            VideoPreview(state, vm::setSourceDuration)
            EditorControls(state, vm)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting MP4…")
                    VideoExportManager(context).export(state) { result ->
                        vm.setExportStatus(result.fold(
                            { "Exported: ${it.name}" },
                            { "Export failed: ${it.message ?: "unknown error"}" }
                        ))
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export MP4") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPreview(state: EditorState, onDuration: (Long) -> Unit) {
    val context = LocalContext.current
    val uri = state.mediaUri
    if (uri == null) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color(0xFF202124)),
            contentAlignment = Alignment.Center
        ) { Text("Video preview", color = Color.White) }
        return
    }

    val player = remember(uri, state.aspectRatio) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
            setVideoEffects(listOf(
                Presentation.createForAspectRatio(state.aspectRatio.ratio, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            ))
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY && duration > 0L) onDuration(duration)
                }
            })
            prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Box(
        Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color.Black)
    ) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxSize())
        TemplateOverlay(state)
    }
}

@Composable
private fun TemplateOverlay(state: EditorState) {
    val accent = when (state.theme) {
        ThemePreset.NEWS -> Color(0xFFB00020)
        ThemePreset.WEDDING -> Color(0xFF764060)
        ThemePreset.BIRTHDAY -> Color(0xFF6E44AA)
        ThemePreset.BUSINESS -> Color(0xFF173755)
        ThemePreset.CUSTOM -> Color(0xFF303030)
    }
    Column(
        Modifier.fillMaxSize().padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(state.logoText, color = Color.White, modifier = Modifier.background(accent).padding(5.dp))
            Text(state.location, color = Color.White, modifier = Modifier.background(Color.DarkGray).padding(5.dp))
        }
        Column {
            Text(state.headline, color = Color.White, modifier = Modifier.fillMaxWidth().background(accent).padding(7.dp))
            Text(state.ticker, color = Color.White, modifier = Modifier.fillMaxWidth().background(Color(0xDD202020)).padding(6.dp))
        }
    }
}

@Composable
private fun EditorControls(state: EditorState, vm: EditorViewModel) {
    Text("Aspect ratio", style = MaterialTheme.typography.titleSmall)
    ChoiceRow(AspectRatioOption.entries, state.aspectRatio, { it.label }, vm::setAspectRatio)

    Text("Duration", style = MaterialTheme.typography.titleSmall)
    ChoiceRow(DurationOption.entries, state.duration, { it.label }, vm::setDuration)

    Text("Theme", style = MaterialTheme.typography.titleSmall)
    ChoiceRow(ThemePreset.entries, state.theme, { it.title }, vm::setTheme)

    if (state.sourceDurationMs > 1_000L) {
        Text("Trim start: ${state.trimStartMs / 1000}s")
        Slider(
            value = state.trimStartMs.toFloat(),
            onValueChange = { vm.setTrimStart(it.roundToLong()) },
            valueRange = 0f..(state.sourceDurationMs - 1_000L).toFloat()
        )
    }

    OutlinedTextField(state.logoText, vm::setLogoText, label = { Text("Logo / brand label") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(state.location, vm::setLocation, label = { Text("Location") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(state.headline, vm::setHeadline, label = { Text("Headline") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(state.ticker, vm::setTicker, label = { Text("Ticker") }, modifier = Modifier.fillMaxWidth())
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImageEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel(key = "image-editor")) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { vm.setMediaUri(it.toString()) }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Image editor") }, navigationIcon = { OutlinedButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Button(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text(if (state.mediaUri == null) "Import image" else "Change image") }

            Box(Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color(0xFF202124))) {
                state.mediaUri?.let { value ->
                    AndroidView(
                        factory = { ctx -> ImageView(ctx).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            setImageURI(Uri.parse(value))
                        }},
                        update = { it.setImageURI(Uri.parse(value)) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                TemplateOverlay(state)
            }

            EditorControls(state, vm)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting JPG…")
                    val result = ImageExportManager(context).export(state)
                    vm.setExportStatus(result.fold(
                        { "Exported: ${it.name}" },
                        { "Export failed: ${it.message ?: "unknown error"}" }
                    ))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export JPG") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun <T> ChoiceRow(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(values) { value ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label(value)) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleListScreen(title: String, lines: List<String>, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { OutlinedButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            lines.forEach { Text(it) }
        }
    }
}
