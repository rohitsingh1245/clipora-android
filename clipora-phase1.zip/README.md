# Clipora Android

Clipora is a template-driven video and image maker. Users import their own real media, apply an editable visual theme, preview the result and export shareable media.

## Phase 1 baseline

Implemented:
- Kotlin + Jetpack Compose shell using package `com.clipora.app`.
- Test-build login/subscription bypass.
- Video/image import via Android Photo Picker.
- Ratios 9:16, 16:9, 1:1 and 4:5.
- Durations 30 sec, 1 min and 2 min.
- Video trim start, Media3 preview and MP4 H.264/AAC export.
- News, Wedding, Birthday, Business and Custom presets.
- Editable logo label, location, headline and ticker.
- JPG image export.
- GitHub Actions debug build workflow.

## Subscription requirement

Production monetisation is a one-month free trial followed by a paid Google Play subscription. Trial/paid entitlement must survive uninstall/reinstall, so production entitlement must be restored from an account/server plus Google Play Billing state and must not rely on local-only storage.

Phase 1 deliberately bypasses the gate while the editor workflow is being developed.
