# Clipora Android — V2

Clipora is a template-driven Android video/image editor.

## V2 implemented

- 8-row breaking-news layout:
  1. Location + channel logo
  2. Main headline
  3. Breaking / Exclusive banner
  4. Main video/image area + watermark
  5. Advertiser/shop name
  6. Dynamic sponsor/ad columns
  7. Address/contact
  8. LIVE + ticker
- Add/remove up to 6 sponsor columns; each can be text or a picked logo image.
- Theme styling: background, accent, font colour, font family, font style, headline size.
- Save reusable themes locally and apply them again later.
- Update selected theme, rename, duplicate and delete saved themes.
- Photo Picker support for channel logo, watermark and sponsor logos.
- MP4 export uses H.264 + AAC and saves through MediaStore to `Movies/Clipora/Videos`.
- JPG export saves through MediaStore to `Pictures/Clipora/Images`.
- Gallery folders are created automatically by MediaStore on modern Android.
- Export and preview share the same logical 8-row template.

## Build stack

- Kotlin / Jetpack Compose
- compileSdk / targetSdk 36
- Java 17
- AndroidX Media3 1.8.0
- AGP 9.4.0 / Gradle 9.6

## Subscription

The development build continues to bypass login/subscription. Production entitlement remains planned as account/server + Google Play Billing so reinstalling the app cannot reset the trial.


## Clipora brand assets

V2.1 includes the approved Clipora C + play app icon as the launcher icon and the full Clipora wordmark on the home screen.
