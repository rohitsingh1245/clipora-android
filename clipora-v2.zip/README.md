# Clipora Android — V2.2 editor patch

Current development build focuses on a working India-first news video editor without login/subscription.

## Included in this patch
- Plain headline (no forced border).
- Breaking News defaults to bold bright red text with transparent background; each text box can enable its own background.
- Inset video frame with Fit/Fill framing.
- Larger expressive advertisement/shop name.
- Sponsor/banner strip reduced to a compact height; supports 1 full-width banner or 2–6 columns.
- Optional sponsor/logo marquee animation in preview and MP4 export.
- Independent blinking LIVE strip and multi-item news marquee.
- Per-text-box font family, style, size, colour, alignment and optional background.
- Any canvas background colour via hex value.
- Optional background image with blur control.
- Saved themes persist the new style settings.
- Video/JPG exports save into Clipora Gallery folders.
- Stable development signing key is included so future test APKs can update in place after the first install of this signing key.

## Build
Use the existing Codemagic workflow and upload this archive as `clipora-v2.zip`.
