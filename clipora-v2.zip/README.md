# Clipora Android — 0.4.0 ratio-specific layout redesign

Clipora is an India-first news video/image editor. This build redesigns the editor around the client reference screenshots instead of stretching one layout across every aspect ratio.

## Platform/output ratios
- 9:16 — Shorts/Reels vertical output
- 16:9 — YouTube landscape output
- 1:1 — square social output
- 4:5 — Facebook/Instagram feed output

## Ratio-specific designs
Each output ratio now has its own layout family. Changing ratio automatically selects a valid default layout.

### 16:9 YouTube layouts
- YouTube — classic
- YouTube — side text
- YouTube — side image/poster
- YouTube — left/right side panels

For every 16:9 layout, the actual media viewport is also locked to 16:9. Side panels, headlines, ticker and other graphics use the remaining space without distorting the video window.

### 4:5 Facebook/Instagram
- headline area above media
- Breaking/Exclusive badge across the media top edge
- landscape media window
- single advertisement banner area below media
- LIVE + scrolling ticker at the bottom

### 9:16 and 1:1
Dedicated compact news layouts are used instead of scaling the 16:9 design.

## Content controls kept because they are used by the client references
- location/city
- channel name or uploaded logo
- optional video watermark
- up to 3 rotating top headlines
- up to 5 rotating lower headlines on layouts that use them
- Breaking/Exclusive/custom rotating badge
- right-side story text or image/poster where the layout supports it
- one full advertisement banner, with optional multi-banner rotation where applicable
- left/right panel artwork in the side-panel YouTube design
- LIVE label + multi-item scrolling ticker
- canvas colour or blurred background image
- per-visible-text font, size, colour, style, alignment and optional background

Obsolete separate advertiser-name/contact rows were removed from the product model and editor.

## Media behavior
- Fit is the safe default; Fill crops instead of stretching.
- Re-import replaces the current media and forces preview refresh.
- Ratio/layout changes restart preview geometry.
- Image preview/export uses the same aspect-preserving geometry.
- Video preview can capture the current source frame as a thumbnail.
- MP4/JPG export saves to Clipora Gallery folders and shows export progress.

## Build
Use the existing Codemagic workflow. Upload this archive to the repository as `clipora-v2.zip`.

## Tests
`testDebugUnitTest` remains the gate before APK assembly. The suite now includes ratio/layout contracts, 16:9 media-window rules, client-reference headline counts, side-panel geometry, image Fit/Fill behavior and the existing export/editor rules. See `TESTING.md`.
