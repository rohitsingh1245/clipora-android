# Clipora Android — 0.4.4 professional news graphics pass

Clipora is an India-first template-driven news video/image editor. This package keeps the simplified client-style editor while making the preview/export graphics behave more like an integrated TV-news composition.

## Professional-news changes in 0.4.4
- Top and lower rotating headlines use a broadcast popup/lower-third strap instead of loose text on the canvas.
- Landscape lower-thirds overlap the media edge so the graphic feels attached to the video rather than a separate block.
- Popup headlines use a short scale/slide/fade entrance/exit in exported video.
- Side-story text uses a framed `TOP STORY` broadcast card.
- Side images use fixed masks, centre-crop without stretching, and have a consistent broadcast frame.
- EXIF orientation is applied when images are decoded for export, fixing the case where a portrait/landscape side image looked correct in preview but rotated 90° in the exported video.
- Fixed mask dimensions are shown in the editor for logo, side images, left/right panels, advertisement banners, and the full background canvas.
- Saved themes can be deleted from the editor as well as from the theme list.

## 16:9 YouTube designs
- Classic
- Side text
- Side image
- Both sides

Every 16:9 design keeps the actual video viewport at exactly 16:9. The new landscape geometry gives the media more visual weight while reserving fixed-size panel slots.

Current 16:9 fixed panel masks at 1920×1080 output:
- Side-image design: 518×702 px
- Both-sides design: left 326×648 px, right 326×648 px

Images are cropped to fill these masks and are never stretched.

## Headline behavior
- Up to 3 rotating top headlines where the layout supports them.
- Up to 5 rotating lower headlines.
- Breaking News / Exclusive / Special Report remains a separate glossy 3D badge with the slower front/back flip.
- LIVE + ticker remain independent of headline rotation.

## Media/export behavior
- Video preview remains behind the news overlay rather than being covered by the template background.
- Fit preserves the full source; Fill crops without distortion.
- Export uses the same layout geometry as preview.
- MP4 export: H.264 + AAC.
- Gallery: `Movies/Clipora/Videos`.
- Images: `Pictures/Clipora/Images`.
- Thumbnails: `Pictures/Clipora/Thumbnails`.

## Build
Keep the existing Codemagic workflow unchanged and replace the repository archive with this file as `clipora-v2.zip`.

The authoritative Android/Compose/Media3 compile still runs in Codemagic because the local tool environment used for this package does not contain an Android SDK/platform installation.


0.4.6: widened 16:9 classic media viewport; separated Breaking News from top headline; constrained landscape lower thirds to real video width; added FLASH NEWS delayed left-to-right lower-third animation shared by preview/export.
