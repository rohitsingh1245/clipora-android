# Clipora regression rules — 0.4.4

Codemagic should run `testDebugUnitTest` before `assembleDebug` using the existing workflow.

The source currently contains 86 `@Test` methods.

## Professional-news regression coverage
- all 16:9 media viewports remain exactly 16:9
- landscape lower-third headline straps overlap the video edge by design
- side panels remain outside the media viewport
- fixed panel mask sizes are deterministic
- popup animation enters, holds and exits smoothly
- popup animation advances to the next headline at the selected interval
- exported animated headlines call the shared broadcast strap renderer
- exported image decoding applies EXIF orientation handling
- preview uses the professional headline strap

## Existing regression coverage retained
- output dimensions for 9:16, 16:9, 1:1 and 4:5
- ratio/layout normalization
- Breaking badge placement and animation timing
- top headline max 3 / lower headline max 5
- Fit/Fill aspect preservation
- media re-import/revision behavior
- trim clamping
- Gallery folder contracts
- ticker/ad rotation
- thumbnail timestamp/path behavior
- per-text styling and theme application
- preview layering contract

## Local validation performed for 0.4.4
- `CliporaModels.kt`, `LayoutEngine.kt`, and `CliporaRules.kt` compiled successfully with local `kotlinc`.
- 37 pure rule/layout JUnit tests compiled and were executed locally via a lightweight JUnit harness: `PURE_TESTS_OK=37`.
- A separate professional-news smoke run passed: `PRO_NEWS_SMOKE_OK`.
- Android-facing Kotlin source was parsed with `kotlinc`; expected unresolved Android/Compose symbols were present because no Android SDK/classpath exists locally, but no Kotlin parser/brace errors were found.
- ZIP integrity is checked before release.

## Codemagic validation still required
The final Android/Compose/Media3 compile and APK assembly must be treated as authoritative. Do not treat the local pure-Kotlin checks as a replacement for `compileDebugKotlin`/`assembleDebug`.


0.4.6: widened 16:9 classic media viewport; separated Breaking News from top headline; constrained landscape lower thirds to real video width; added FLASH NEWS delayed left-to-right lower-third animation shared by preview/export.


## 0.4.6 regression correction
The 16:9 lower-third contract now verifies the actual client requirement: the strap overlaps the video and never exceeds the video window horizontally. Classic layouts may keep the strap entirely over the picture; side layouts may straddle the lower edge.
## 2026-09-20 9:16 composition fix
- 9:16 preview/export remain a true 1080x1920 (9:16) canvas.
- Removed FLASH NEWS treatment from the portrait top headline; it is now clean text on the template background.
- Portrait headline, video, sponsor banner and ticker share one width and have zero vertical gaps.
- Portrait video defaults to Fill/Crop (aspect preserved, center-cropped) so the media viewport has no empty blue/black bands.
- The content stack now reaches close to the bottom of the 9:16 frame, removing the large unused blue area below the ticker.
- Preview and export use the same NewsLayoutEngine rectangles for WYSIWYG placement.

