# Clipora regression rules — 0.4.0

Codemagic must run:

`testDebugUnitTest`

before:

`assembleDebug`

The project currently contains 68 JUnit tests.

## Ratio and layout contracts
- output sizes remain 1080×1920, 1920×1080, 1080×1080 and 1080×1350
- each ratio only exposes layouts designed for that ratio
- invalid layout selections are normalized to the ratio default
- all normalized layout rectangles remain inside the canvas
- every 16:9 YouTube media viewport is exactly 16:9 in pixels
- 4:5 social layout keeps a landscape media viewport above the ad area
- Breaking badge straddles the media top border when that layout uses a badge
- side text/image panels never overlap the video
- left/right side panels never overlap each other or the video
- ticker never overlaps the video
- ad banner never overlaps the video

## Client-reference content rules
- top rotating headline capacity: 3
- lower rotating headline capacity: 5
- Breaking/Exclusive/custom badge list remains bounded
- side-text and side-image controls only appear on layouts that use them
- separate obsolete advertiser/contact rows are no longer editor controls

## Video/editor rules
- Fit is the safe default
- re-importing the same or different URI forces a fresh player revision
- aspect ratio/layout/framing changes refresh preview geometry
- trim start is clamped
- export progress is clamped to 0–100%
- Gallery folder paths remain stable
- LIVE blink and Breaking front/back flip timing remain deterministic
- multi-item ticker and advertisement rotation remain deterministic

## Image rules
- Fit preserves source aspect ratio
- Fill crops to frame ratio without stretching
- image editor hides video-only timeline controls
- imported assets can be removed
- thumbnail path remains `Pictures/Clipora/Thumbnails`

## Theme rules
- per-text styles are independent
- background colour/image/blur are independent
- saved theme application restores aspect/layout but does not replace currently imported media

## Local validation performed for this package
- production model/rule/layout Kotlin compiled successfully with `kotlinc`
- ViewModel + production rules compiled successfully with lightweight lifecycle/flow stubs
- all 68 JUnit test sources compiled successfully against the production rule/ViewModel API using JUnit stubs
- rule/layout and ViewModel smoke tests executed successfully

The final Android/Compose/Media3 compile still runs on Codemagic because this chat container does not contain the Android SDK dependency set.
