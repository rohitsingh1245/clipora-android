plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.clipora.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.clipora.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 12
        versionName = "0.3.6"
    }

    signingConfigs {
        create("cliporaDebug") {
            storeFile = file("clipora-debug.keystore")
            storePassword = "clipora-dev"
            keyAlias = "clipora"
            keyPassword = "clipora-dev"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("cliporaDebug")
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")

    implementation("androidx.compose.ui:ui:1.9.5")
    implementation("androidx.compose.ui:ui-tooling-preview:1.9.5")
    implementation("androidx.compose.foundation:foundation:1.9.5")
    implementation("androidx.compose.material3:material3:1.3.2")
    debugImplementation("androidx.compose.ui:ui-tooling:1.9.5")

    val media3 = "1.8.0"
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")

    testImplementation("junit:junit:4.13.2")
}

// Keep the downloadable debug APK name branded as Clipora.
tasks.configureEach {
    if (name == "assembleDebug") {
        doLast {
            val apkDir = layout.buildDirectory.dir("outputs/apk/debug").get().asFile
            val defaultApk = apkDir.resolve("app-debug.apk")
            val cliporaApk = apkDir.resolve("Clipora.apk")
            if (defaultApk.exists()) {
                defaultApk.copyTo(cliporaApk, overwrite = true)
                defaultApk.delete()
            }
        }
    }
}
