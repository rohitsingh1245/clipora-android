package com.clipora.app

import com.clipora.app.model.DurationOption
import com.clipora.app.model.EditorState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EditorStateTest {
    @Test
    fun effectiveEndUsesSelectedDurationWhenSourceIsLonger() {
        val state = EditorState(
            duration = DurationOption.THIRTY_SECONDS,
            trimStartMs = 5_000L,
            sourceDurationMs = 120_000L
        )
        assertEquals(35_000L, state.effectiveEndMs)
    }

    @Test
    fun effectiveEndIsOpenWhenSelectedDurationReachesEndOfSource() {
        val state = EditorState(
            duration = DurationOption.TWO_MINUTES,
            trimStartMs = 0L,
            sourceDurationMs = 60_000L
        )
        assertNull(state.effectiveEndMs)
    }
}
