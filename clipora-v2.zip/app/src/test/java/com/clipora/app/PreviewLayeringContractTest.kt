package com.clipora.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class PreviewLayeringContractTest {
    @Test
    fun `news overlay must not paint full canvas background over media preview`() {
        val source = File("src/main/java/com/clipora/app/ui/CliporaApp.kt").readText()
        val overlayStart = source.indexOf("private fun NewsTemplateOverlay")
        val nextFunction = source.indexOf("\n@Composable", overlayStart + 30)
        val overlay = if (nextFunction > overlayStart) {
            source.substring(overlayStart, nextFunction)
        } else {
            source.substring(overlayStart)
        }

        assertTrue(
            "Foreground overlay must stay transparent over the media viewport",
            !overlay.contains("BackgroundBox(state.style, Modifier.fillMaxSize())")
        )
    }

    @Test
    fun `video preview background is rendered before player layer`() {
        val source = File("src/main/java/com/clipora/app/ui/CliporaApp.kt").readText()
        val previewStart = source.indexOf("private fun VideoPreview")
        val overlayStart = source.indexOf("private fun NewsTemplateOverlay", previewStart)
        val preview = source.substring(previewStart, overlayStart)

        val background = preview.indexOf("BackgroundBox(state.style, Modifier.fillMaxSize())")
        val player = preview.indexOf("PlayerView(ctx)")
        assertTrue(background >= 0)
        assertTrue(player > background)
    }
}
