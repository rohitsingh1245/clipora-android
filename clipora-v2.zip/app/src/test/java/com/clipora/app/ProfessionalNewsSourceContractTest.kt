package com.clipora.app

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ProfessionalNewsSourceContractTest {
    @Test
    fun `export image loader applies exif orientation`() {
        val source = File("src/main/java/com/clipora/app/media/OrientedBitmapLoader.kt").readText()
        assertTrue(source.contains("ExifInterface.TAG_ORIENTATION"))
        assertTrue(source.contains("ORIENTATION_ROTATE_90"))
        assertTrue(source.contains("ORIENTATION_ROTATE_270"))
    }

    @Test
    fun `animated export headlines use professional popup renderer`() {
        val source = File("src/main/java/com/clipora/app/media/AnimatedTickerOverlay.kt").readText()
        assertTrue(source.contains("popupAnimationFrame"))
        assertTrue(source.contains("BroadcastGraphicsRenderer.drawHeadlineStrap"))
    }

    @Test
    fun `preview headlines use professional strap`() {
        val source = File("src/main/java/com/clipora/app/ui/CliporaApp.kt").readText()
        assertTrue(source.contains("ProfessionalHeadlineStrap"))
        assertTrue(source.contains("Fixed image mask:"))
    }
}
