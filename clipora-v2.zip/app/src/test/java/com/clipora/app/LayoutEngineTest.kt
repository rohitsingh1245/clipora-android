package com.clipora.app

import com.clipora.app.model.*
import org.junit.Assert.*
import org.junit.Test

class LayoutEngineTest {

    @Test fun allLayoutRectsStayInsideCanvas() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            val rects = listOfNotNull(
                spec.videoRect,
                spec.headlineRect,
                spec.breakingBadgeRect,
                spec.locationRect,
                spec.logoRect,
                spec.bottomHeadlineRect,
                spec.adRect,
                spec.tickerRect,
                spec.rightPanelRect,
                spec.leftPanelRect
            )
            rects.forEach { rect ->
                assertTrue("${preset.name}: left", rect.left >= 0f)
                assertTrue("${preset.name}: top", rect.top >= 0f)
                assertTrue("${preset.name}: right", rect.right <= 1f)
                assertTrue("${preset.name}: bottom", rect.bottom <= 1f)
                assertTrue("${preset.name}: width", rect.width > 0f)
                assertTrue("${preset.name}: height", rect.height > 0f)
            }
        }
    }

    @Test fun everyLandscapeVideoViewportIsExactlySixteenByNine() {
        CliporaRules.validLayouts(AspectRatioOption.LANDSCAPE).forEach { preset ->
            val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, preset)
            val actual = NewsLayoutEngine.actualPixelAspect(spec.videoRect, 16f / 9f)
            assertEquals("$preset", 16f / 9f, actual, .002f)
            assertTrue("$preset must declare the lock", spec.locksVideoTo16x9)
        }
    }

    @Test fun socialFeedUsesLandscapeMediaWindowInsideFourByFiveCanvas() {
        val spec = NewsLayoutEngine.spec(AspectRatioOption.SOCIAL, LayoutPreset.SOCIAL_FEED)
        val actual = NewsLayoutEngine.actualPixelAspect(spec.videoRect, 4f / 5f)
        assertEquals(16f / 9f, actual, .01f)
        assertNotNull(spec.headlineRect)
        assertNotNull(spec.adRect)
        assertNotNull(spec.breakingBadgeRect)
    }

    @Test fun breakingBadgeStraddlesTopEdgeOfVideoWhenPresent() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            val badge = spec.breakingBadgeRect ?: return@forEach
            assertTrue("$preset badge must start above video", badge.top < spec.videoRect.top)
            assertTrue("$preset badge must end inside video", badge.bottom > spec.videoRect.top)
        }
    }

    @Test fun sideTextPanelDoesNotOverlapVideo() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_TEXT
        )
        assertEquals(SidePanelMode.TEXT, spec.sidePanelMode)
        assertNotNull(spec.rightPanelRect)
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, requireNotNull(spec.rightPanelRect)))
    }

    @Test fun sideImagePanelDoesNotOverlapVideo() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_IMAGE
        )
        assertEquals(SidePanelMode.IMAGE, spec.sidePanelMode)
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, requireNotNull(spec.rightPanelRect)))
    }

    @Test fun sidePanelTemplateHasTwoIndependentPanels() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_PANELS
        )
        val left = requireNotNull(spec.leftPanelRect)
        val right = requireNotNull(spec.rightPanelRect)
        assertEquals(SidePanelMode.LEFT_AND_RIGHT, spec.sidePanelMode)
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, left))
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, right))
        assertFalse(NewsLayoutEngine.rectsOverlap(left, right))
    }

    @Test fun classicLandscapeHasNoTopHeadlineButKeepsLowerHeadlineAndNoAdBanner() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_CLASSIC
        )
        assertNull(spec.headlineRect)
        assertNotNull(spec.bottomHeadlineRect)
        assertNull(spec.adRect)
    }

    @Test fun socialAndShortsLayoutsReserveAdArea() {
        val shorts = NewsLayoutEngine.spec(
            AspectRatioOption.PORTRAIT,
            LayoutPreset.SHORTS_CLASSIC
        )
        val social = NewsLayoutEngine.spec(
            AspectRatioOption.SOCIAL,
            LayoutPreset.SOCIAL_FEED
        )
        assertNotNull(shorts.adRect)
        assertNotNull(social.adRect)
    }

    @Test fun tickerNeverOverlapsVideo() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            assertFalse("$preset", NewsLayoutEngine.rectsOverlap(spec.videoRect, spec.tickerRect))
        }
    }

    @Test fun advertisementNeverOverlapsVideo() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            val ad = spec.adRect ?: return@forEach
            assertFalse("$preset", NewsLayoutEngine.rectsOverlap(spec.videoRect, ad))
        }
    }

    @Test fun ratioDefaultsMatchClientPlatformMapping() {
        assertEquals(LayoutPreset.SHORTS_CLASSIC, NewsLayoutEngine.defaultPreset(AspectRatioOption.PORTRAIT))
        assertEquals(LayoutPreset.LANDSCAPE_CLASSIC, NewsLayoutEngine.defaultPreset(AspectRatioOption.LANDSCAPE))
        assertEquals(LayoutPreset.SQUARE_CLASSIC, NewsLayoutEngine.defaultPreset(AspectRatioOption.SQUARE))
        assertEquals(LayoutPreset.SOCIAL_FEED, NewsLayoutEngine.defaultPreset(AspectRatioOption.SOCIAL))
    }

    @Test fun landscapeLowerThirdIsIntegratedWithVideoAndNeverExceedsVideoWidth() {
        CliporaRules.validLayouts(AspectRatioOption.LANDSCAPE).forEach { preset ->
            val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, preset)
            val lower = spec.bottomHeadlineRect ?: return@forEach
            val epsilon = 0.0001f

            // Broadcast lower-thirds must sit on the picture, not float below it.
            assertTrue("$preset lower-third should overlap the video", lower.top < spec.videoRect.bottom)
            assertTrue("$preset lower-third should reach into the video", lower.bottom > spec.videoRect.top)

            // User requirement: the lower headline must never run wider than the real video window.
            assertTrue("$preset lower-third left edge exceeds video", lower.left + epsilon >= spec.videoRect.left)
            assertTrue("$preset lower-third right edge exceeds video", lower.right - epsilon <= spec.videoRect.right)
        }
    }

    @Test fun fixedSideImageMasksHaveStableExportPixelSizes() {
        val single = CliporaRules.panelMaskSize(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_IMAGE
        )
        assertEquals(518 to 702, single)

        val left = CliporaRules.panelMaskSize(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_PANELS,
            isLeft = true
        )
        val right = CliporaRules.panelMaskSize(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_PANELS,
            isLeft = false
        )
        assertEquals(326 to 648, left)
        assertEquals(326 to 648, right)
    }

    @Test fun classicLandscapeUsesMostOfCanvasWidth() {
        val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, LayoutPreset.LANDSCAPE_CLASSIC)
        assertTrue("Classic 16:9 media should not leave large empty side gutters", spec.videoRect.width >= .82f)
    }

    @Test fun classicBreakingBadgeIsLiftedMostlyAboveVideoBorder() {
        val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, LayoutPreset.LANDSCAPE_CLASSIC)
        val breaking = requireNotNull(spec.breakingBadgeRect)
        assertNull(spec.headlineRect)
        assertTrue("Breaking badge must start above video", breaking.top < spec.videoRect.top)
        assertTrue("Breaking badge must only slightly enter video", breaking.centerY <= spec.videoRect.top)
        assertTrue("Breaking badge must still touch the video border", breaking.bottom > spec.videoRect.top)
    }

    @Test fun everyLandscapePresetRemovesTopHeadline() {
        CliporaRules.validLayouts(AspectRatioOption.LANDSCAPE).forEach { preset ->
            assertNull("$preset should not have a top headline in 16:9",
                NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, preset).headlineRect)
        }
    }

    @Test fun classicLandscapeLeavesClearMastheadAboveVideo() {
        val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, LayoutPreset.LANDSCAPE_CLASSIC)
        assertTrue(spec.locationRect.bottom < spec.videoRect.top)
        assertTrue(spec.logoRect.bottom < spec.videoRect.top)
    }

    @Test fun everyLandscapeLowerThirdStaysInsideRealVideoWidth() {
        CliporaRules.validLayouts(AspectRatioOption.LANDSCAPE).forEach { preset ->
            val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, preset)
            val lower = spec.bottomHeadlineRect ?: return@forEach
            assertTrue("$preset lower third starts outside video", lower.left >= spec.videoRect.left - .0001f)
            assertTrue("$preset lower third ends outside video", lower.right <= spec.videoRect.right + .0001f)
        }
    }

    @Test fun flashLowerThirdWaitsThenRevealsLeftToRight() {
        val interval = 5_000L
        assertEquals(0f, CliporaRules.lowerThirdRevealProgress(interval, 100_000L), .001f)
        val midway = CliporaRules.lowerThirdRevealProgress(interval, 950_000L)
        assertTrue(midway > 0f && midway < 1f)
        assertEquals(1f, CliporaRules.lowerThirdRevealProgress(interval, 2_000_000L), .001f)
    }
}
