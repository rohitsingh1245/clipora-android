package com.clipora.app

import com.clipora.app.model.*
import org.junit.Assert.*
import org.junit.Test

class LayoutEngineTest {

    @Test fun allLayoutRectsStayInsideCanvas() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            val rects = listOfNotNull(
                spec.videoRect,
                spec.headlineRect,
                spec.breakingBadgeRect,
                spec.locationRect,
                spec.logoRect,
                spec.bottomHeadlineRect,
                spec.adRect,
                spec.tickerRect,
                spec.rightPanelRect,
                spec.leftPanelRect
            )
            rects.forEach { rect ->
                assertTrue("${preset.name}: left", rect.left >= 0f)
                assertTrue("${preset.name}: top", rect.top >= 0f)
                assertTrue("${preset.name}: right", rect.right <= 1f)
                assertTrue("${preset.name}: bottom", rect.bottom <= 1f)
                assertTrue("${preset.name}: width", rect.width > 0f)
                assertTrue("${preset.name}: height", rect.height > 0f)
            }
        }
    }

    @Test fun everyLandscapeVideoViewportIsExactlySixteenByNine() {
        CliporaRules.validLayouts(AspectRatioOption.LANDSCAPE).forEach { preset ->
            val spec = NewsLayoutEngine.spec(AspectRatioOption.LANDSCAPE, preset)
            val actual = NewsLayoutEngine.actualPixelAspect(spec.videoRect, 16f / 9f)
            assertEquals("$preset", 16f / 9f, actual, .002f)
            assertTrue("$preset must declare the lock", spec.locksVideoTo16x9)
        }
    }

    @Test fun socialFeedUsesLandscapeMediaWindowInsideFourByFiveCanvas() {
        val spec = NewsLayoutEngine.spec(AspectRatioOption.SOCIAL, LayoutPreset.SOCIAL_FEED)
        val actual = NewsLayoutEngine.actualPixelAspect(spec.videoRect, 4f / 5f)
        assertEquals(16f / 9f, actual, .01f)
        assertNotNull(spec.headlineRect)
        assertNotNull(spec.adRect)
        assertNotNull(spec.breakingBadgeRect)
    }

    @Test fun breakingBadgeStraddlesTopEdgeOfVideoWhenPresent() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            val badge = spec.breakingBadgeRect ?: return@forEach
            assertTrue("$preset badge must start above video", badge.top < spec.videoRect.top)
            assertTrue("$preset badge must end inside video", badge.bottom > spec.videoRect.top)
        }
    }

    @Test fun sideTextPanelDoesNotOverlapVideo() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_TEXT
        )
        assertEquals(SidePanelMode.TEXT, spec.sidePanelMode)
        assertNotNull(spec.rightPanelRect)
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, requireNotNull(spec.rightPanelRect)))
    }

    @Test fun sideImagePanelDoesNotOverlapVideo() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_IMAGE
        )
        assertEquals(SidePanelMode.IMAGE, spec.sidePanelMode)
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, requireNotNull(spec.rightPanelRect)))
    }

    @Test fun sidePanelTemplateHasTwoIndependentPanels() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_SIDE_PANELS
        )
        val left = requireNotNull(spec.leftPanelRect)
        val right = requireNotNull(spec.rightPanelRect)
        assertEquals(SidePanelMode.LEFT_AND_RIGHT, spec.sidePanelMode)
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, left))
        assertFalse(NewsLayoutEngine.rectsOverlap(spec.videoRect, right))
        assertFalse(NewsLayoutEngine.rectsOverlap(left, right))
    }

    @Test fun classicLandscapeHasTopAndLowerHeadlinesButNoAdBanner() {
        val spec = NewsLayoutEngine.spec(
            AspectRatioOption.LANDSCAPE,
            LayoutPreset.LANDSCAPE_CLASSIC
        )
        assertNotNull(spec.headlineRect)
        assertNotNull(spec.bottomHeadlineRect)
        assertNull(spec.adRect)
    }

    @Test fun socialAndShortsLayoutsReserveAdArea() {
        val shorts = NewsLayoutEngine.spec(
            AspectRatioOption.PORTRAIT,
            LayoutPreset.SHORTS_CLASSIC
        )
        val social = NewsLayoutEngine.spec(
            AspectRatioOption.SOCIAL,
            LayoutPreset.SOCIAL_FEED
        )
        assertNotNull(shorts.adRect)
        assertNotNull(social.adRect)
    }

    @Test fun tickerNeverOverlapsVideo() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            assertFalse("$preset", NewsLayoutEngine.rectsOverlap(spec.videoRect, spec.tickerRect))
        }
    }

    @Test fun advertisementNeverOverlapsVideo() {
        LayoutPreset.entries.forEach { preset ->
            val spec = NewsLayoutEngine.spec(preset.aspect, preset)
            val ad = spec.adRect ?: return@forEach
            assertFalse("$preset", NewsLayoutEngine.rectsOverlap(spec.videoRect, ad))
        }
    }

    @Test fun ratioDefaultsMatchClientPlatformMapping() {
        assertEquals(LayoutPreset.SHORTS_CLASSIC, NewsLayoutEngine.defaultPreset(AspectRatioOption.PORTRAIT))
        assertEquals(LayoutPreset.LANDSCAPE_CLASSIC, NewsLayoutEngine.defaultPreset(AspectRatioOption.LANDSCAPE))
        assertEquals(LayoutPreset.SQUARE_CLASSIC, NewsLayoutEngine.defaultPreset(AspectRatioOption.SQUARE))
        assertEquals(LayoutPreset.SOCIAL_FEED, NewsLayoutEngine.defaultPreset(AspectRatioOption.SOCIAL))
    }
}
