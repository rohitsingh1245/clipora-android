package com.clipora.app

import com.clipora.app.model.*
import org.junit.Assert.*
import org.junit.Test

class CliporaRulesTest {

    @Test fun outputSizesMatchAllSupportedRatios() {
        assertEquals(1080 to 1920, CliporaRules.outputSize(AspectRatioOption.PORTRAIT))
        assertEquals(1920 to 1080, CliporaRules.outputSize(AspectRatioOption.LANDSCAPE))
        assertEquals(1080 to 1080, CliporaRules.outputSize(AspectRatioOption.SQUARE))
        assertEquals(1080 to 1350, CliporaRules.outputSize(AspectRatioOption.SOCIAL))
    }

    @Test fun galleryPathsStayStable() {
        assertEquals("Movies/Clipora/Videos", CliporaRules.VIDEO_GALLERY_PATH)
        assertEquals("Pictures/Clipora/Images", CliporaRules.IMAGE_GALLERY_PATH)
        assertEquals("Pictures/Clipora/Thumbnails", CliporaRules.THUMBNAIL_GALLERY_PATH)
    }

    @Test fun itemLimitsMatchProductContract() {
        assertEquals(3, CliporaRules.MAX_BREAKING_ITEMS)
        assertEquals(3, CliporaRules.MAX_HEADLINE_ITEMS)
        assertEquals(5, CliporaRules.MAX_LOWER_HEADLINE_ITEMS)
        assertEquals(10, CliporaRules.MAX_MARQUEE_ITEMS)
        assertEquals(10, CliporaRules.MAX_AD_BANNERS)
    }

    @Test fun eachRatioOnlyReturnsItsOwnLayouts() {
        AspectRatioOption.entries.forEach { aspect ->
            val presets = CliporaRules.validLayouts(aspect)
            assertTrue(presets.isNotEmpty())
            assertTrue(presets.all { it.aspect == aspect })
        }
    }

    @Test fun invalidLayoutIsNormalizedToRatioDefault() {
        assertEquals(
            LayoutPreset.SOCIAL_FEED,
            CliporaRules.normalizeLayout(AspectRatioOption.SOCIAL, LayoutPreset.LANDSCAPE_SIDE_TEXT)
        )
    }

    @Test fun landscapeHasAllClientReferenceVariants() {
        val presets = CliporaRules.validLayouts(AspectRatioOption.LANDSCAPE)
        assertTrue(presets.contains(LayoutPreset.LANDSCAPE_CLASSIC))
        assertTrue(presets.contains(LayoutPreset.LANDSCAPE_SIDE_TEXT))
        assertTrue(presets.contains(LayoutPreset.LANDSCAPE_SIDE_IMAGE))
        assertTrue(presets.contains(LayoutPreset.LANDSCAPE_SIDE_PANELS))
    }

    @Test fun rotatingTextCyclesByInterval() {
        assertEquals(0, CliporaRules.activeRotatingTextIndex(3, 1_000L, 100_000L))
        assertEquals(1, CliporaRules.activeRotatingTextIndex(3, 1_000L, 1_100_000L))
        assertEquals(2, CliporaRules.activeRotatingTextIndex(3, 1_000L, 2_100_000L))
        assertEquals(0, CliporaRules.activeRotatingTextIndex(3, 1_000L, 3_100_000L))
    }

    @Test fun advertisementRotationUsesFirstWhenDisabled() {
        assertEquals(0, CliporaRules.activeAdvertisementIndex(1, true, 1_000L, 9_000_000L))
        assertEquals(0, CliporaRules.activeAdvertisementIndex(3, false, 1_000L, 9_000_000L))
    }

    @Test fun advertisementRotationNeverRunsFasterThanHalfSecond() {
        assertEquals(0, CliporaRules.activeAdvertisementIndex(2, true, 10L, 499_000L))
        assertEquals(1, CliporaRules.activeAdvertisementIndex(2, true, 10L, 501_000L))
    }

    @Test fun breakingBadgeFlipsFrontThenBack() {
        val intervalUs = 3_000_000L
        val front = CliporaRules.breakingAnimationFrame(2, 3_000L, (intervalUs * .80).toLong(), true)
        val back = CliporaRules.breakingAnimationFrame(2, 3_000L, (intervalUs * .94).toLong(), true)

        assertTrue(front.inTransition)
        assertEquals(0, front.labelIndex)
        assertTrue(front.rotationX > 0f)

        assertTrue(back.inTransition)
        assertEquals(1, back.labelIndex)
        assertTrue(back.rotationX < 0f)
    }

    @Test fun breakingBadgeNeverCyclesFasterThanTwoSeconds() {
        val before = CliporaRules.breakingAnimationFrame(2, 100L, 1_100_000L, false)
        val after = CliporaRules.breakingAnimationFrame(2, 100L, 2_100_000L, false)
        assertEquals(0, before.labelIndex)
        assertEquals(1, after.labelIndex)
    }

    @Test fun liveLabelBlinksEveryHalfSecond() {
        assertTrue(CliporaRules.isLiveVisible(0L))
        assertFalse(CliporaRules.isLiveVisible(500_000L))
        assertTrue(CliporaRules.isLiveVisible(1_000_000L))
    }

    @Test fun fitDestinationPreservesImageAspectRatio() {
        val rect = CliporaRules.fitDestinationRect(1600, 900, 100f, 200f, 900f, 1000f)
        assertTrue(rect.left >= 100f)
        assertTrue(rect.top >= 200f)
        assertTrue(rect.right <= 900f)
        assertTrue(rect.bottom <= 1000f)
        assertEquals(1600f / 900f, rect.width / rect.height, .001f)
    }

    @Test fun fillCropMatchesTargetRatioWithoutStretching() {
        val crop = CliporaRules.fillSourceCropRect(1600, 900, 9f / 16f)
        assertTrue(crop.left >= 0f)
        assertTrue(crop.top >= 0f)
        assertTrue(crop.right <= 1600f)
        assertTrue(crop.bottom <= 900f)
        assertEquals(9f / 16f, crop.width / crop.height, .001f)
    }

    @Test fun imageEditorHidesVideoOnlyTimelineControls() {
        assertFalse(CliporaRules.supportsTimelineControls(EditorMediaMode.IMAGE))
        assertFalse(CliporaRules.supportsAnimationControls(EditorMediaMode.IMAGE))
        assertTrue(CliporaRules.supportsTimelineControls(EditorMediaMode.VIDEO))
    }

    @Test fun styleTargetsOnlyContainElementsVisibleForLayout() {
        val sideTextTargets = CliporaRules.editableTextTargets(LayoutPreset.LANDSCAPE_SIDE_TEXT)
        assertTrue(sideTextTargets.contains(TextTarget.SIDE_TEXT))
        assertTrue(sideTextTargets.contains(TextTarget.BOTTOM_HEADLINE))
        assertFalse(sideTextTargets.contains(TextTarget.BREAKING))

        val socialTargets = CliporaRules.editableTextTargets(LayoutPreset.SOCIAL_FEED)
        assertTrue(socialTargets.contains(TextTarget.HEADLINE))
        assertTrue(socialTargets.contains(TextTarget.BREAKING))
        assertTrue(socialTargets.contains(TextTarget.SPONSOR))
        assertFalse(socialTargets.contains(TextTarget.SIDE_TEXT))
    }
    @Test fun demoContentMatchesClientSlotCounts() {
        LayoutPreset.entries.forEach { preset ->
            val demo = CliporaRules.demoContent(preset)
            assertTrue(demo.topHeadlines.size <= CliporaRules.MAX_HEADLINE_ITEMS)
            assertTrue(demo.lowerHeadlines.size <= CliporaRules.MAX_LOWER_HEADLINE_ITEMS)
            assertTrue(demo.breakingLabels.size <= CliporaRules.MAX_BREAKING_ITEMS)
            assertTrue(demo.tickerItems.isNotEmpty())
        }
    }

    @Test fun advertisementRotationBecomesAutomaticWhenMultipleBannersExist() {
        assertFalse(CliporaRules.shouldRotateAdvertisements(0))
        assertFalse(CliporaRules.shouldRotateAdvertisements(1))
        assertTrue(CliporaRules.shouldRotateAdvertisements(2))
    }

}
