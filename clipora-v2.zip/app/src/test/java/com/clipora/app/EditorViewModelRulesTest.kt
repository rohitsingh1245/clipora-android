package com.clipora.app

import com.clipora.app.editor.EditorViewModel
import com.clipora.app.model.*
import org.junit.Assert.*
import org.junit.Test

class EditorViewModelRulesTest {
    @Test fun importingVideoReplacesUriAndResetsTransientMediaState() {
        val vm = EditorViewModel()
        vm.setSourceDuration(90_000L)
        vm.setTrimStart(12_000L)
        vm.setExportStatus("old")
        vm.setExportProgress(88)

        vm.setMediaUri("content://new-video")
        val state = vm.state.value

        assertEquals("content://new-video", state.mediaUri)
        assertEquals(0L, state.trimStartMs)
        assertEquals(0L, state.sourceDurationMs)
        assertNull(state.exportStatus)
        assertNull(state.exportProgress)
        assertEquals(1, state.mediaRevision)
    }

    @Test fun selectingSameVideoAgainStillForcesPlayerRefresh() {
        val vm = EditorViewModel()
        vm.setMediaUri("content://video")
        val firstRevision = vm.state.value.mediaRevision
        vm.setMediaUri("content://video")
        assertEquals(firstRevision + 1, vm.state.value.mediaRevision)
    }

    @Test fun aspectRatioChangeRestartsPreviewRevision() {
        val vm = EditorViewModel()
        val before = vm.state.value.mediaRevision
        vm.setAspectRatio(AspectRatioOption.SQUARE)
        assertEquals(AspectRatioOption.SQUARE, vm.state.value.aspectRatio)
        assertEquals(before + 1, vm.state.value.mediaRevision)
    }

    @Test fun framingModeChangeRestartsPreviewRevision() {
        val vm = EditorViewModel()
        val before = vm.state.value.mediaRevision
        vm.setVideoScaleMode(VideoScaleMode.FILL)
        assertEquals(VideoScaleMode.FILL, vm.state.value.videoScaleMode)
        assertEquals(before + 1, vm.state.value.mediaRevision)
    }

    @Test fun trimStartNeverGoesBeforeZeroOrIntoLastSecond() {
        val vm = EditorViewModel()
        vm.setSourceDuration(10_000L)
        vm.setTrimStart(-500L)
        assertEquals(0L, vm.state.value.trimStartMs)
        vm.setTrimStart(50_000L)
        assertEquals(9_000L, vm.state.value.trimStartMs)
    }

    @Test fun exportProgressIsAlwaysClampedToPercentRange() {
        val vm = EditorViewModel()
        vm.setExportProgress(-10)
        assertEquals(0, vm.state.value.exportProgress)
        vm.setExportProgress(150)
        assertEquals(100, vm.state.value.exportProgress)
        vm.setExportProgress(null)
        assertNull(vm.state.value.exportProgress)
    }

    @Test fun backgroundBlurIsClampedToSupportedRange() {
        val vm = EditorViewModel()
        vm.setBackgroundBlur(-1f)
        assertEquals(0f, vm.state.value.style.backgroundBlur, 0.001f)
        vm.setBackgroundBlur(100f)
        assertEquals(30f, vm.state.value.style.backgroundBlur, 0.001f)
    }

    @Test fun textSizeScaleIsClampedForEveryTextBox() {
        val vm = EditorViewModel()
        vm.setTextBoxSizeScale(TextTarget.HEADLINE, 0.1f)
        assertEquals(0.55f, vm.state.value.textStyle(TextTarget.HEADLINE).sizeScale, 0.001f)
        vm.setTextBoxSizeScale(TextTarget.HEADLINE, 9f)
        assertEquals(2f, vm.state.value.textStyle(TextTarget.HEADLINE).sizeScale, 0.001f)
    }

    @Test fun breakingLabelsCannotExceedThreeOrDropBelowOne() {
        val vm = EditorViewModel()
        repeat(20) { vm.addBreakingItem() }
        assertEquals(CliporaRules.MAX_BREAKING_ITEMS, vm.state.value.breakingItems.size)
        vm.state.value.breakingItems.drop(1).forEach { vm.removeBreakingItem(it.id) }
        val finalId = vm.state.value.breakingItems.single().id
        vm.removeBreakingItem(finalId)
        assertEquals(1, vm.state.value.breakingItems.size)
    }

    @Test fun marqueeLinesCannotExceedTenOrDropBelowOne() {
        val vm = EditorViewModel()
        repeat(20) { vm.addMarqueeLine() }
        assertEquals(CliporaRules.MAX_MARQUEE_ITEMS, vm.state.value.marqueeItems.size)
        vm.state.value.marqueeItems.drop(1).forEach { vm.removeMarqueeLine(it.id) }
        val finalId = vm.state.value.marqueeItems.single().id
        vm.removeMarqueeLine(finalId)
        assertEquals(1, vm.state.value.marqueeItems.size)
    }

    @Test fun firstCustomAdvertisementReplacesPlaceholderInsteadOfCreatingHiddenSecondBanner() {
        val vm = EditorViewModel()
        vm.addSponsorText()
        assertEquals(1, vm.state.value.sponsors.size)
        assertEquals("NEW TEXT", vm.state.value.sponsors.single().text)
    }

    @Test fun advertisementBannersCannotExceedTenOrDropBelowOne() {
        val vm = EditorViewModel()
        vm.addSponsorText() // replaces placeholder
        repeat(20) { vm.addSponsorText() }
        assertEquals(CliporaRules.MAX_AD_BANNERS, vm.state.value.sponsors.size)
        vm.state.value.sponsors.drop(1).forEach { vm.removeSponsor(it.id) }
        val finalId = vm.state.value.sponsors.single().id
        vm.removeSponsor(finalId)
        assertEquals(1, vm.state.value.sponsors.size)
    }

    @Test fun bannerTextAlwaysTracksFirstBreakingLabel() {
        val vm = EditorViewModel()
        val first = vm.state.value.breakingItems.first()
        vm.setBreakingText(first.id, "SPECIAL REPORT")
        assertEquals("SPECIAL REPORT", vm.state.value.bannerText)
        assertEquals("SPECIAL REPORT", vm.state.value.breakingItems.first().text)
    }

    @Test fun applyingThemeRestoresDesignSettingsWithoutReplacingCurrentVideo() {
        val vm = EditorViewModel()
        vm.setMediaUri("content://keep-me")
        val saved = SavedTheme(
            id = "t1",
            name = "Red News",
            style = TemplateStyle(backgroundColor = 0xFF112233.toInt()),
            textStyles = defaultTextStyles().toMutableMap().apply {
                put(TextTarget.HEADLINE, defaultTextStyle(TextTarget.HEADLINE).copy(textColor = 0xFF00FF00.toInt()))
            },
            logoText = "CHANNEL",
            channelLogoUri = "content://logo",
            watermarkLogoUri = "content://watermark",
            bannerText = "BREAKING",
            breakingItems = listOf(BreakingItem(1, "BREAKING"), BreakingItem(2, "EXCLUSIVE")),
            liveLabel = "LIVE NOW",
            marqueeInterval = MarqueeIntervalOption.LONG
        )
        vm.applySavedTheme(saved)
        val state = vm.state.value
        assertEquals("content://keep-me", state.mediaUri)
        assertEquals(0xFF112233.toInt(), state.style.backgroundColor)
        assertEquals("CHANNEL", state.logoText)
        assertEquals("LIVE NOW", state.liveLabel)
        assertEquals(0xFF00FF00.toInt(), state.textStyle(TextTarget.HEADLINE).textColor)
    }

    @Test fun canvasBackgroundColorImageAndBlurAreIndependentlyEditable() {
        val vm = EditorViewModel()
        vm.setBackgroundColor(0xFF123456.toInt())
        vm.setBackgroundImageUri("content://background")
        vm.setBackgroundBlur(14f)
        val style = vm.state.value.style
        assertEquals(0xFF123456.toInt(), style.backgroundColor)
        assertEquals("content://background", style.backgroundImageUri)
        assertEquals(14f, style.backgroundBlur, 0.001f)
    }

    @Test fun eachTextBoxKeepsIndependentColourFontAndBackgroundSettings() {
        val vm = EditorViewModel()
        vm.setTextBoxTextColor(TextTarget.HEADLINE, 0xFF112233.toInt())
        vm.setTextBoxBackgroundColor(TextTarget.HEADLINE, 0x80123456.toInt())
        vm.setTextBoxBackgroundEnabled(TextTarget.HEADLINE, true)
        vm.setTextBoxFontFamily(TextTarget.HEADLINE, FontFamilyOption.SERIF)
        vm.setTextBoxFontStyle(TextTarget.HEADLINE, FontStyleOption.ITALIC)
        vm.setTextBoxAlignment(TextTarget.HEADLINE, TextAlignmentOption.END)

        val headline = vm.state.value.textStyle(TextTarget.HEADLINE)
        val ticker = vm.state.value.textStyle(TextTarget.TICKER)
        assertEquals(0xFF112233.toInt(), headline.textColor)
        assertEquals(0x80123456.toInt(), headline.backgroundColor)
        assertTrue(headline.backgroundEnabled)
        assertEquals(FontFamilyOption.SERIF, headline.fontFamily)
        assertEquals(FontStyleOption.ITALIC, headline.fontStyle)
        assertEquals(TextAlignmentOption.END, headline.alignment)
        assertNotEquals(headline, ticker)
    }

    @Test fun imageAdvertisementCanReplacePlaceholderAndKeepSelectedUri() {
        val vm = EditorViewModel()
        vm.addSponsorLogo()
        val bannerId = vm.state.value.sponsors.single().id
        vm.setSponsorLogo(bannerId, "content://full-banner")
        val banner = vm.state.value.sponsors.single()
        assertEquals(SponsorKind.LOGO, banner.kind)
        assertEquals("content://full-banner", banner.imageUri)
    }

    @Test fun advertisementRotationSettingsAreEditable() {
        val vm = EditorViewModel()
        vm.setSponsorMarqueeEnabled(true)
        vm.setSponsorMarqueeInterval(MarqueeIntervalOption.LONG)
        assertTrue(vm.state.value.style.sponsorMarqueeEnabled)
        assertEquals(MarqueeIntervalOption.LONG, vm.state.value.style.sponsorMarqueeInterval)
    }

    @Test fun breakingAnimationSettingsAreEditable() {
        val vm = EditorViewModel()
        vm.setBreakingFlashEnabled(false)
        vm.setBreakingFlipEnabled(false)
        vm.setBreakingBadge3dEnabled(false)
        vm.setBreakingInterval(MarqueeIntervalOption.LONG)
        val style = vm.state.value.style
        assertFalse(style.breakingFlashEnabled)
        assertFalse(style.breakingFlipEnabled)
        assertFalse(style.breakingBadge3dEnabled)
        assertEquals(MarqueeIntervalOption.LONG, style.breakingInterval)
    }

    @Test fun marqueeIntervalIsEditable() {
        val vm = EditorViewModel()
        vm.setMarqueeInterval(MarqueeIntervalOption.EXTRA_LONG)
        assertEquals(MarqueeIntervalOption.EXTRA_LONG, vm.state.value.marqueeInterval)
    }
    @Test fun removeMediaClearsImportedAssetState() {
        val vm = EditorViewModel()
        vm.setMediaUri("content://media")
        vm.setSourceDuration(12_000L)
        vm.setTrimStart(4_000L)
        val before = vm.state.value.mediaRevision

        vm.removeMedia()

        assertNull(vm.state.value.mediaUri)
        assertEquals(0L, vm.state.value.sourceDurationMs)
        assertEquals(0L, vm.state.value.trimStartMs)
        assertEquals(before + 1, vm.state.value.mediaRevision)
    }

    @Test fun selectedImageAssetsCanBeCleared() {
        val vm = EditorViewModel()
        vm.setChannelLogoUri("content://logo")
        vm.setWatermarkLogoUri("content://watermark")
        vm.setBackgroundImageUri("content://background")
        val adId = vm.state.value.sponsors.single().id
        vm.setSponsorLogo(adId, "content://ad")

        vm.setChannelLogoUri(null)
        vm.setWatermarkLogoUri(null)
        vm.setBackgroundImageUri(null)
        vm.clearSponsorLogo(adId)

        assertNull(vm.state.value.channelLogoUri)
        assertNull(vm.state.value.watermarkLogoUri)
        assertNull(vm.state.value.style.backgroundImageUri)
        assertNull(vm.state.value.sponsors.single().imageUri)
    }


    @Test fun aspectRatioChangeAlsoSelectsCorrectDefaultLayout() {
        val vm = EditorViewModel()
        vm.setAspectRatio(AspectRatioOption.LANDSCAPE)
        assertEquals(LayoutPreset.LANDSCAPE_CLASSIC, vm.state.value.layoutPreset)

        vm.setAspectRatio(AspectRatioOption.SOCIAL)
        assertEquals(LayoutPreset.SOCIAL_FEED, vm.state.value.layoutPreset)
    }

    @Test fun invalidLayoutSelectionIsNormalizedForCurrentRatio() {
        val vm = EditorViewModel()
        vm.setAspectRatio(AspectRatioOption.SOCIAL)
        vm.setLayoutPreset(LayoutPreset.LANDSCAPE_SIDE_TEXT)
        assertEquals(LayoutPreset.SOCIAL_FEED, vm.state.value.layoutPreset)
    }

    @Test fun headlineSlotsNeverExceedThree() {
        val vm = EditorViewModel()
        repeat(10) { vm.addHeadlineItem() }
        assertEquals(CliporaRules.MAX_HEADLINE_ITEMS, vm.state.value.headlineItems.size)
    }

    @Test fun lowerHeadlineSlotsNeverExceedFive() {
        val vm = EditorViewModel()
        repeat(10) { vm.addLowerHeadlineItem() }
        assertEquals(CliporaRules.MAX_LOWER_HEADLINE_ITEMS, vm.state.value.lowerHeadlineItems.size)
    }

    @Test fun sidePanelTextAndImageCanBeChangedAndRemoved() {
        val vm = EditorViewModel()
        vm.setSidePanelText("Side story")
        vm.setSidePanelImageUri("content://poster")
        assertEquals("Side story", vm.state.value.sidePanelText)
        assertEquals("content://poster", vm.state.value.sidePanelImageUri)

        vm.setSidePanelImageUri(null)
        assertNull(vm.state.value.sidePanelImageUri)
    }

    @Test fun applyingSavedThemeRestoresRatioAndLayoutWithoutReplacingMedia() {
        val vm = EditorViewModel()
        vm.setMediaUri("content://keep")
        val theme = SavedTheme(
            id = "layout",
            name = "YouTube side text",
            style = TemplateStyle(),
            textStyles = defaultTextStyles(),
            logoText = "CHANNEL",
            channelLogoUri = null,
            watermarkLogoUri = null,
            bannerText = "BREAKING",
            breakingItems = listOf(BreakingItem(1, "BREAKING")),
            liveLabel = "LIVE",
            marqueeInterval = MarqueeIntervalOption.NORMAL,
            aspectRatio = AspectRatioOption.LANDSCAPE,
            layoutPreset = LayoutPreset.LANDSCAPE_SIDE_TEXT
        )

        vm.applySavedTheme(theme)

        assertEquals("content://keep", vm.state.value.mediaUri)
        assertEquals(AspectRatioOption.LANDSCAPE, vm.state.value.aspectRatio)
        assertEquals(LayoutPreset.LANDSCAPE_SIDE_TEXT, vm.state.value.layoutPreset)
    }

    @Test fun changingLayoutWhileUsingDemoContentLoadsThatLayoutsSample() {
        val vm = EditorViewModel()
        vm.setAspectRatio(AspectRatioOption.LANDSCAPE)
        val state = vm.state.value
        assertTrue(state.isUsingDemoContent)
        assertEquals(LayoutPreset.LANDSCAPE_CLASSIC, state.layoutPreset)
        assertEquals(CliporaRules.demoContent(LayoutPreset.LANDSCAPE_CLASSIC).location, state.location)
        assertEquals(3, state.headlineItems.size)
        assertEquals(5, state.lowerHeadlineItems.size)
    }

    @Test fun customHeadlineIsPreservedWhenChangingDesign() {
        val vm = EditorViewModel()
        val first = vm.state.value.headlineItems.first()
        vm.setHeadlineText(first.id, "MY CUSTOM HEADLINE")
        assertFalse(vm.state.value.isUsingDemoContent)
        vm.setAspectRatio(AspectRatioOption.LANDSCAPE)
        assertEquals("MY CUSTOM HEADLINE", vm.state.value.headlineItems.first().text)
    }

    @Test fun addingSecondAdvertisementEnablesAutomaticRotation() {
        val vm = EditorViewModel()
        vm.addSponsorLogo()
        vm.addSponsorLogo()
        assertTrue(vm.state.value.sponsors.size >= 2)
        assertTrue(vm.state.value.style.sponsorMarqueeEnabled)
    }



    @Test fun lowerHeadlineSlidesKeepIndependentColours() {
        val vm = EditorViewModel()
        val first = vm.state.value.lowerHeadlineItems.first()
        val second = vm.state.value.lowerHeadlineItems[1]
        vm.setLowerHeadlineTextColor(first.id, 0xFF102030.toInt())
        vm.setLowerHeadlineBackgroundColor(first.id, 0xFFABCDEF.toInt())
        val state = vm.state.value
        assertEquals(0xFF102030.toInt(), state.lowerHeadlineItems.first { it.id == first.id }.textColor)
        assertEquals(0xFFABCDEF.toInt(), state.lowerHeadlineItems.first { it.id == first.id }.backgroundColor)
        assertNotEquals(state.lowerHeadlineItems.first { it.id == first.id }.backgroundColor, state.lowerHeadlineItems.first { it.id == second.id }.backgroundColor)
    }
}
