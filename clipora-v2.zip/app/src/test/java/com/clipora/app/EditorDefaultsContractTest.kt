package com.clipora.app

import com.clipora.app.model.*
import org.junit.Assert.*
import org.junit.Test

class EditorDefaultsContractTest {
    @Test fun videoDefaultsToFaceSafeFitMode() {
        assertEquals(VideoScaleMode.FIT, EditorState().videoScaleMode)
    }

    @Test fun breakingNewsStartsWithProfessionalRotationDefaults() {
        val state = EditorState()
        assertEquals(listOf("BREAKING NEWS", "EXCLUSIVE", "SPECIAL REPORT"), state.breakingItems.map { it.text })
        assertEquals(MarqueeIntervalOption.EXTRA_LONG, state.style.breakingInterval)
        assertTrue(state.style.breakingFlipEnabled)
        assertTrue(state.style.breakingFlashEnabled)
        assertTrue(state.style.breakingBadge3dEnabled)
    }

    @Test fun advertisementStartsAsOneFullBanner() {
        val state = EditorState()
        assertEquals(1, state.sponsors.size)
        assertEquals(SponsorKind.TEXT, state.sponsors.single().kind)
        assertEquals("YOUR ADVERTISEMENT", state.sponsors.single().text)
    }

    @Test fun everyTextTargetHasAnEditableStyle() {
        val state = EditorState()
        TextTarget.entries.forEach { target ->
            assertNotNull("Missing text style for $target", state.textStyles[target])
            assertTrue(state.textStyle(target).sizeScale > 0f)
        }
    }

    @Test fun headlineHasNoForcedBackgroundByDefault() {
        assertFalse(EditorState().textStyle(TextTarget.HEADLINE).backgroundEnabled)
    }

    @Test fun breakingBadgeHasBoldReadableDefaultStyle() {
        val style = EditorState().textStyle(TextTarget.BREAKING)
        assertEquals(FontStyleOption.BOLD, style.fontStyle)
        assertTrue(style.backgroundEnabled)
        assertEquals(0xFFFFFFFF.toInt(), style.textColor)
    }

    @Test fun canvasSupportsEditableBackgroundAndBlur() {
        val style = EditorState().style
        assertNull(style.backgroundImageUri)
        assertEquals(0f, style.backgroundBlur, 0.001f)
    }

    @Test fun editorStartsWithShortsLayoutForPortraitOutput() {
        val state = EditorState()
        assertEquals(AspectRatioOption.PORTRAIT, state.aspectRatio)
        assertEquals(LayoutPreset.SHORTS_CLASSIC, state.layoutPreset)
    }

    @Test fun headlineSlotsMatchClientReferenceCounts() {
        val state = EditorState()
        assertEquals(3, state.headlineItems.size)
        assertEquals(5, state.lowerHeadlineItems.size)
    }

    @Test fun portraitStartsWithUsefulClientStyleDemoText() {
        val state = EditorState()
        assertEquals("नई दिल्ली", state.location)
        assertEquals("भारत की बड़ी खबर", state.headlineItems.first().text)
        assertTrue(state.marqueeItems.first().text.isNotBlank())
        assertTrue(state.isUsingDemoContent)
    }

}
