package com.clipora.app.model

data class NormalizedRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    init {
        require(left in 0f..1f && right in 0f..1f && top in 0f..1f && bottom in 0f..1f)
        require(right > left && bottom > top)
    }

    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f

    fun toPixels(widthPx: Int, heightPx: Int): FloatRectSpec =
        FloatRectSpec(
            left = left * widthPx,
            top = top * heightPx,
            right = right * widthPx,
            bottom = bottom * heightPx
        )
}

data class NewsLayoutSpec(
    val preset: LayoutPreset,
    val videoRect: NormalizedRect,
    val headlineRect: NormalizedRect?,
    val breakingBadgeRect: NormalizedRect?,
    val locationRect: NormalizedRect,
    val logoRect: NormalizedRect,
    val bottomHeadlineRect: NormalizedRect? = null,
    val adRect: NormalizedRect? = null,
    val tickerRect: NormalizedRect,
    val rightPanelRect: NormalizedRect? = null,
    val leftPanelRect: NormalizedRect? = null,
    val sidePanelMode: SidePanelMode = SidePanelMode.NONE,
    val locksVideoTo16x9: Boolean = false
)

object NewsLayoutEngine {
    fun presetsFor(aspect: AspectRatioOption): List<LayoutPreset> = LayoutPreset.entries.filter { it.aspect == aspect }

    fun defaultPreset(aspect: AspectRatioOption): LayoutPreset = when (aspect) {
        AspectRatioOption.PORTRAIT -> LayoutPreset.SHORTS_CLASSIC
        AspectRatioOption.LANDSCAPE -> LayoutPreset.LANDSCAPE_CLASSIC
        AspectRatioOption.SQUARE -> LayoutPreset.SQUARE_CLASSIC
        AspectRatioOption.SOCIAL -> LayoutPreset.SOCIAL_FEED
    }

    fun normalizePreset(aspect: AspectRatioOption, preset: LayoutPreset): LayoutPreset =
        if (preset.aspect == aspect) preset else defaultPreset(aspect)

    fun spec(aspect: AspectRatioOption, preset: LayoutPreset): NewsLayoutSpec {
        val p = normalizePreset(aspect, preset)
        return when (p) {
            LayoutPreset.SHORTS_CLASSIC -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.08f, .035f, .36f, .09f),
                logoRect = r(.74f, .035f, .92f, .09f),
                // Portrait output is always a true 9:16 canvas. Keep one continuous
                // content column with no vertical gaps: headline -> video -> ad -> ticker.
                // The stack reaches close to the bottom of the 9:16 frame so there is no
                // large unused background band below the ticker.
                headlineRect = r(.07f, .105f, .93f, .205f),
                videoRect = r(.07f, .205f, .93f, .685f),
                breakingBadgeRect = r(.25f, .184f, .75f, .226f),
                adRect = r(.07f, .685f, .93f, .895f),
                tickerRect = r(.07f, .895f, .93f, .965f)
            )

            LayoutPreset.LANDSCAPE_CLASSIC -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.025f, .018f, .18f, .075f),
                logoRect = r(.875f, .018f, .97f, .085f),
                // Keep a clean masthead for location/logo, then place the 16:9 video below it.
                videoRect = r(.09f, .10f, .91f, .92f),
                // No separate top headline in 16:9. Badge is lifted mostly above the video border.
                breakingBadgeRect = r(.35f, .052f, .65f, .112f),
                headlineRect = null,
                // Lower-third stays locked to the real video width.
                bottomHeadlineRect = r(.09f, .775f, .91f, .895f),
                tickerRect = r(.09f, .935f, .91f, .99f),
                locksVideoTo16x9 = true
            )

            LayoutPreset.LANDSCAPE_SIDE_TEXT -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.03f, .025f, .16f, .085f),
                logoRect = r(.88f, .025f, .97f, .095f),
                headlineRect = null,
                videoRect = r(.03f, .11f, .68f, .76f),
                breakingBadgeRect = null,
                rightPanelRect = r(.68f, .11f, .97f, .76f),
                bottomHeadlineRect = r(.03f, .67f, .68f, .815f),
                tickerRect = r(.03f, .90f, .97f, .98f),
                sidePanelMode = SidePanelMode.TEXT,
                locksVideoTo16x9 = true
            )

            LayoutPreset.LANDSCAPE_SIDE_IMAGE -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.03f, .025f, .16f, .085f),
                logoRect = r(.88f, .025f, .97f, .095f),
                headlineRect = null,
                videoRect = r(.03f, .11f, .68f, .76f),
                breakingBadgeRect = null,
                rightPanelRect = r(.68f, .11f, .97f, .76f),
                bottomHeadlineRect = r(.03f, .67f, .68f, .815f),
                tickerRect = r(.03f, .90f, .97f, .98f),
                sidePanelMode = SidePanelMode.IMAGE,
                locksVideoTo16x9 = true
            )

            LayoutPreset.LANDSCAPE_SIDE_PANELS -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.03f, .025f, .16f, .085f),
                logoRect = r(.88f, .025f, .97f, .095f),
                headlineRect = null,
                // A larger centre video is kept exactly 16:9; portrait artwork slots flank it.
                videoRect = r(.20f, .11f, .80f, .71f),
                breakingBadgeRect = null,
                leftPanelRect = r(.02f, .11f, .20f, .71f),
                rightPanelRect = r(.80f, .11f, .98f, .71f),
                bottomHeadlineRect = r(.20f, .62f, .80f, .785f),
                tickerRect = r(.03f, .885f, .97f, .97f),
                sidePanelMode = SidePanelMode.LEFT_AND_RIGHT,
                locksVideoTo16x9 = true
            )

            LayoutPreset.SQUARE_CLASSIC -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.05f, .04f, .32f, .105f),
                logoRect = r(.78f, .035f, .95f, .105f),
                headlineRect = r(.07f, .12f, .93f, .225f),
                videoRect = r(.08f, .275f, .92f, .7475f),
                breakingBadgeRect = r(.27f, .252f, .73f, .298f),
                adRect = r(.06f, .765f, .94f, .895f),
                tickerRect = r(.04f, .925f, .96f, .98f)
            )

            LayoutPreset.SOCIAL_FEED -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.05f, .035f, .34f, .09f),
                logoRect = r(.80f, .03f, .95f, .095f),
                headlineRect = r(.07f, .105f, .93f, .225f),
                // 16:9 media window inside 4:5 social canvas.
                videoRect = r(.08f, .285f, .92f, .663f),
                breakingBadgeRect = r(.27f, .262f, .73f, .307f),
                adRect = r(.06f, .69f, .94f, .875f),
                tickerRect = r(.04f, .925f, .96f, .985f)
            )
        }
    }

    fun actualPixelAspect(rect: NormalizedRect, canvasAspect: Float): Float =
        (rect.width * canvasAspect) / rect.height

    fun rectsOverlap(a: NormalizedRect, b: NormalizedRect): Boolean =
        a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top

    private fun r(l: Float, t: Float, r: Float, b: Float) = NormalizedRect(l, t, r, b)
}
