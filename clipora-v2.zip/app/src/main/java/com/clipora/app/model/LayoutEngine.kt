package com.clipora.app.model

data class NormalizedRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    init {
        require(left in 0f..1f && right in 0f..1f && top in 0f..1f && bottom in 0f..1f)
        require(right > left && bottom > top)
    }

    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f

    fun toPixels(widthPx: Int, heightPx: Int): FloatRectSpec =
        FloatRectSpec(
            left = left * widthPx,
            top = top * heightPx,
            right = right * widthPx,
            bottom = bottom * heightPx
        )
}

data class NewsLayoutSpec(
    val preset: LayoutPreset,
    val videoRect: NormalizedRect,
    val headlineRect: NormalizedRect?,
    val breakingBadgeRect: NormalizedRect?,
    val locationRect: NormalizedRect,
    val logoRect: NormalizedRect,
    val bottomHeadlineRect: NormalizedRect? = null,
    val adRect: NormalizedRect? = null,
    val tickerRect: NormalizedRect,
    val rightPanelRect: NormalizedRect? = null,
    val leftPanelRect: NormalizedRect? = null,
    val sidePanelMode: SidePanelMode = SidePanelMode.NONE,
    val locksVideoTo16x9: Boolean = false
)

object NewsLayoutEngine {
    fun presetsFor(aspect: AspectRatioOption): List<LayoutPreset> = LayoutPreset.entries.filter { it.aspect == aspect }

    fun defaultPreset(aspect: AspectRatioOption): LayoutPreset = when (aspect) {
        AspectRatioOption.PORTRAIT -> LayoutPreset.SHORTS_CLASSIC
        AspectRatioOption.LANDSCAPE -> LayoutPreset.LANDSCAPE_CLASSIC
        AspectRatioOption.SQUARE -> LayoutPreset.SQUARE_CLASSIC
        AspectRatioOption.SOCIAL -> LayoutPreset.SOCIAL_FEED
    }

    fun normalizePreset(aspect: AspectRatioOption, preset: LayoutPreset): LayoutPreset =
        if (preset.aspect == aspect) preset else defaultPreset(aspect)

    fun spec(aspect: AspectRatioOption, preset: LayoutPreset): NewsLayoutSpec {
        val p = normalizePreset(aspect, preset)
        return when (p) {
            LayoutPreset.SHORTS_CLASSIC -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.05f, .035f, .36f, .09f),
                logoRect = r(.74f, .035f, .95f, .09f),
                headlineRect = r(.06f, .105f, .94f, .215f),
                videoRect = r(.08f, .255f, .92f, .69f),
                breakingBadgeRect = r(.24f, .232f, .76f, .278f),
                adRect = r(.06f, .715f, .94f, .90f),
                tickerRect = r(.04f, .935f, .96f, .985f)
            )

            LayoutPreset.LANDSCAPE_CLASSIC -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.035f, .035f, .18f, .105f),
                logoRect = r(.86f, .03f, .965f, .11f),
                headlineRect = r(.20f, .03f, .80f, .145f),
                // Width fraction == height fraction, therefore the pixel viewport is 16:9 on a 16:9 canvas.
                videoRect = r(.18f, .19f, .82f, .83f),
                breakingBadgeRect = r(.36f, .165f, .64f, .215f),
                bottomHeadlineRect = r(.18f, .835f, .82f, .905f),
                tickerRect = r(.035f, .93f, .965f, .985f),
                locksVideoTo16x9 = true
            )

            LayoutPreset.LANDSCAPE_SIDE_TEXT -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.035f, .045f, .18f, .105f),
                logoRect = r(.875f, .035f, .965f, .11f),
                headlineRect = null,
                videoRect = r(.045f, .17f, .645f, .77f),
                breakingBadgeRect = null,
                rightPanelRect = r(.67f, .17f, .965f, .77f),
                bottomHeadlineRect = r(.045f, .785f, .965f, .885f),
                tickerRect = r(.035f, .91f, .965f, .98f),
                sidePanelMode = SidePanelMode.TEXT,
                locksVideoTo16x9 = true
            )

            LayoutPreset.LANDSCAPE_SIDE_IMAGE -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.035f, .045f, .18f, .105f),
                logoRect = r(.875f, .035f, .965f, .11f),
                headlineRect = null,
                videoRect = r(.045f, .17f, .645f, .77f),
                breakingBadgeRect = null,
                rightPanelRect = r(.67f, .17f, .965f, .77f),
                bottomHeadlineRect = r(.045f, .785f, .965f, .885f),
                tickerRect = r(.035f, .91f, .965f, .98f),
                sidePanelMode = SidePanelMode.IMAGE,
                locksVideoTo16x9 = true
            )

            LayoutPreset.LANDSCAPE_SIDE_PANELS -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.035f, .035f, .18f, .105f),
                logoRect = r(.875f, .03f, .965f, .11f),
                headlineRect = r(.20f, .03f, .80f, .12f),
                // Center video stays 16:9; left/right panels are independent artwork zones.
                videoRect = r(.255f, .205f, .715f, .665f),
                breakingBadgeRect = null,
                leftPanelRect = r(.04f, .205f, .225f, .665f),
                rightPanelRect = r(.745f, .205f, .96f, .665f),
                bottomHeadlineRect = r(.04f, .695f, .96f, .84f),
                tickerRect = r(.035f, .88f, .965f, .965f),
                sidePanelMode = SidePanelMode.LEFT_AND_RIGHT,
                locksVideoTo16x9 = true
            )

            LayoutPreset.SQUARE_CLASSIC -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.05f, .04f, .32f, .105f),
                logoRect = r(.78f, .035f, .95f, .105f),
                headlineRect = r(.07f, .12f, .93f, .225f),
                videoRect = r(.08f, .275f, .92f, .7475f),
                breakingBadgeRect = r(.27f, .252f, .73f, .298f),
                adRect = r(.06f, .765f, .94f, .895f),
                tickerRect = r(.04f, .925f, .96f, .98f)
            )

            LayoutPreset.SOCIAL_FEED -> NewsLayoutSpec(
                preset = p,
                locationRect = r(.05f, .035f, .34f, .09f),
                logoRect = r(.80f, .03f, .95f, .095f),
                headlineRect = r(.07f, .105f, .93f, .225f),
                // 16:9 media window inside 4:5 social canvas.
                videoRect = r(.08f, .285f, .92f, .663f),
                breakingBadgeRect = r(.27f, .262f, .73f, .307f),
                adRect = r(.06f, .69f, .94f, .875f),
                tickerRect = r(.04f, .925f, .96f, .985f)
            )
        }
    }

    fun actualPixelAspect(rect: NormalizedRect, canvasAspect: Float): Float =
        (rect.width * canvasAspect) / rect.height

    fun rectsOverlap(a: NormalizedRect, b: NormalizedRect): Boolean =
        a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top

    private fun r(l: Float, t: Float, r: Float, b: Float) = NormalizedRect(l, t, r, b)
}
