package com.clipora.app.media

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.clipora.app.model.FontFamilyOption
import com.clipora.app.model.FontStyleOption
import com.clipora.app.model.TextAlignmentOption
import com.clipora.app.model.TextBoxStyle

/** Shared Canvas renderer for professional news straps used by exported images/videos. */
object BroadcastGraphicsRenderer {

    fun drawHeadlineStrap(
        canvas: Canvas,
        rect: RectF,
        text: String,
        textStyle: TextBoxStyle,
        accentColor: Int,
        alpha: Int = 255,
        scale: Float = 1f,
        translationY: Float = 0f,
        maxLines: Int = 2
    ) {
        if (text.isBlank() || rect.width() <= 1f || rect.height() <= 1f) return

        val save = canvas.save()
        canvas.translate(0f, translationY)
        canvas.scale(scale, scale, rect.centerX(), rect.centerY())
        val layer = RectF(
            rect.left - rect.height() * .2f,
            rect.top - rect.height() * .2f,
            rect.right + rect.height() * .2f,
            rect.bottom + rect.height() * .28f
        )
        val layerSave = canvas.saveLayerAlpha(layer, alpha.coerceIn(0, 255))

        val radius = rect.height() * .10f
        val shadow = RectF(rect).apply { offset(0f, rect.height() * .10f) }
        canvas.drawRoundRect(
            shadow,
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x6A000000 }
        )

        val darkAccent = darken(accentColor, .56f)
        val gradient = LinearGradient(
            rect.left,
            rect.top,
            rect.right,
            rect.bottom,
            intArrayOf(0xFF071A33.toInt(), 0xFF0B2748.toInt(), darkAccent),
            floatArrayOf(0f, .58f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(
            rect,
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient }
        )

        // Glossy top edge.
        canvas.drawRoundRect(
            RectF(rect.left + 1f, rect.top + 1f, rect.right - 1f, rect.top + rect.height() * .17f),
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x35FFFFFF }
        )

        // Strong red/accent blade on the left, inspired by broadcast lower-thirds.
        val bladeWidth = (rect.width() * .045f).coerceAtLeast(rect.height() * .16f)
        val blade = Path().apply {
            moveTo(rect.left, rect.top)
            lineTo(rect.left + bladeWidth, rect.top)
            lineTo(rect.left + bladeWidth * .72f, rect.bottom)
            lineTo(rect.left, rect.bottom)
            close()
        }
        canvas.drawPath(blade, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor })

        // Fine outline keeps the strap attached to the video visually.
        canvas.drawRoundRect(
            rect,
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x55FFFFFF
                style = Paint.Style.STROKE
                strokeWidth = (rect.height() * .018f).coerceAtLeast(1f)
            }
        )

        val content = RectF(
            rect.left + bladeWidth + rect.width() * .025f,
            rect.top + rect.height() * .08f,
            rect.right - rect.width() * .025f,
            rect.bottom - rect.height() * .07f
        )
        drawText(canvas, content, text, textStyle.copy(backgroundEnabled = false), maxLines)

        canvas.restoreToCount(layerSave)
        canvas.restoreToCount(save)
    }

    fun drawSideTextCard(
        canvas: Canvas,
        rect: RectF,
        text: String,
        textStyle: TextBoxStyle,
        accentColor: Int
    ) {
        if (rect.width() <= 1f || rect.height() <= 1f) return
        val radius = minOf(rect.width(), rect.height()) * .035f
        val shadow = RectF(rect).apply { offset(0f, rect.height() * .018f) }
        canvas.drawRoundRect(shadow, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x62000000 })

        val gradient = LinearGradient(
            rect.left,
            rect.top,
            rect.right,
            rect.bottom,
            intArrayOf(0xFF071A33.toInt(), 0xFF0D3158.toInt(), darken(accentColor, .62f)),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient })

        val headerH = rect.height() * .12f
        canvas.drawRoundRect(
            RectF(rect.left, rect.top, rect.right, rect.top + headerH),
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
        )
        canvas.drawRect(
            RectF(rect.left, rect.top + headerH * .55f, rect.right, rect.top + headerH),
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
        )

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = headerH * .42f
            typeface = Typeface.DEFAULT_BOLD
        }
        val fm = labelPaint.fontMetrics
        val baseline = rect.top + headerH / 2f - (fm.ascent + fm.descent) / 2f
        canvas.drawText("TOP STORY", rect.left + rect.width() * .055f, baseline, labelPaint)

        val body = RectF(
            rect.left + rect.width() * .055f,
            rect.top + headerH + rect.height() * .035f,
            rect.right - rect.width() * .055f,
            rect.bottom - rect.height() * .045f
        )
        drawText(
            canvas,
            body,
            text,
            textStyle.copy(textColor = Color.WHITE, backgroundEnabled = false, alignment = TextAlignmentOption.START),
            maxLines = 8
        )

        canvas.drawRoundRect(
            rect,
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x55FFFFFF
                style = Paint.Style.STROKE
                strokeWidth = (rect.width() * .006f).coerceAtLeast(1f)
            }
        )
    }

    fun drawImagePanelFrame(canvas: Canvas, rect: RectF, accentColor: Int) {
        val radius = minOf(rect.width(), rect.height()) * .035f
        val shadow = RectF(rect).apply { offset(0f, rect.height() * .015f) }
        canvas.drawRoundRect(shadow, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 })
        canvas.drawRoundRect(rect, radius, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF06172B.toInt() })
        canvas.drawRect(
            RectF(rect.left, rect.bottom - rect.height() * .025f, rect.right, rect.bottom),
            Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
        )
        canvas.drawRoundRect(
            rect,
            radius,
            radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x77FFFFFF
                style = Paint.Style.STROKE
                strokeWidth = (rect.width() * .008f).coerceAtLeast(1.5f)
            }
        )
    }

    private fun drawText(
        canvas: Canvas,
        rect: RectF,
        text: String,
        style: TextBoxStyle,
        maxLines: Int
    ) {
        if (text.isBlank() || rect.width() <= 1f || rect.height() <= 1f) return
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = style.textColor
            textSize = (minOf(rect.height() * .42f, rect.width() * .085f) * style.sizeScale).coerceAtLeast(12f)
            typeface = typeface(style)
        }
        val alignment = when (style.alignment) {
            TextAlignmentOption.START -> Layout.Alignment.ALIGN_NORMAL
            TextAlignmentOption.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignmentOption.END -> Layout.Alignment.ALIGN_OPPOSITE
        }
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, rect.width().toInt().coerceAtLeast(1))
            .setAlignment(alignment)
            .setIncludePad(false)
            .setMaxLines(maxLines)
            .setLineSpacing(0f, .96f)
            .build()
        val dy = ((rect.height() - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left, rect.top + dy)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun typeface(style: TextBoxStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun darken(color: Int, amount: Float): Int {
        val factor = (1f - amount).coerceIn(0f, 1f)
        return Color.argb(
            Color.alpha(color),
            (Color.red(color) * factor).toInt(),
            (Color.green(color) * factor).toInt(),
            (Color.blue(color) * factor).toInt()
        )
    }
}
