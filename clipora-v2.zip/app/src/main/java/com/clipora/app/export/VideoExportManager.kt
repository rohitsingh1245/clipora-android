package com.clipora.app.export

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.clipora.app.media.CliporaVideoEffects
import com.clipora.app.model.EditorState
import java.io.File

@UnstableApi
class VideoExportManager(private val context: Context) {
    fun export(
        state: EditorState,
        onProgress: (Int) -> Unit = {},
        onResult: (Result<Uri>) -> Unit
    ) {
        val input = state.mediaUri
        if (input.isNullOrBlank()) {
            onResult(Result.failure(IllegalStateException("Choose a video first.")))
            return
        }

        val clipBuilder = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(state.trimStartMs)
        state.effectiveEndMs?.let { clipBuilder.setEndPositionMs(it) }

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(input))
            .setClippingConfiguration(clipBuilder.build())
            .build()

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), CliporaVideoEffects.exportEffects(context, state)))
            .build()

        val temporaryOutput = File(context.cacheDir, "clipora_export_${System.currentTimeMillis()}.mp4")
        val mainHandler = Handler(Looper.getMainLooper())
        val progressHolder = ProgressHolder()
        var finished = false
        lateinit var progressRunnable: Runnable

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    finished = true
                    mainHandler.removeCallbacks(progressRunnable)
                    onProgress(100)
                    runCatching { GalleryStore.saveVideo(context, temporaryOutput) }
                        .also { temporaryOutput.delete() }
                        .let(onResult)
                }

                override fun onError(composition: Composition, result: ExportResult, exception: ExportException) {
                    finished = true
                    mainHandler.removeCallbacks(progressRunnable)
                    temporaryOutput.delete()
                    onResult(Result.failure(exception))
                }
            })
            .build()

        progressRunnable = object : Runnable {
            override fun run() {
                if (finished) return
                val progressState = transformer.getProgress(progressHolder)
                if (progressState == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(progressHolder.progress.coerceIn(0, 99))
                }
                if (progressState != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    mainHandler.postDelayed(this, 400L)
                }
            }
        }

        onProgress(0)
        transformer.start(editedMediaItem, temporaryOutput.absolutePath)
        mainHandler.post(progressRunnable)
    }
}
