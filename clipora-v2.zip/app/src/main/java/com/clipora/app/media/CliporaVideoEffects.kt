package com.clipora.app.media

import android.content.Context
import android.graphics.Matrix
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import com.clipora.app.model.*

@UnstableApi
object CliporaVideoEffects {

    fun aspectRatioOnly(state: EditorState): List<Effect> {
        val layout = when (state.videoScaleMode) {
            VideoScaleMode.FIT -> Presentation.LAYOUT_SCALE_TO_FIT
            VideoScaleMode.FILL -> Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        }
        val (width, height) = CliporaRules.outputSize(state.aspectRatio)
        val spec = NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset)

        val presentation = Presentation.createForWidthAndHeight(width, height, layout)
        val viewport = spec.videoRect

        // Media3 transformations operate in normalized device coordinates (-1..1).
        // We first present into the final canvas without distortion, then uniformly scale and
        // translate the video into the template's viewport. The full-canvas template mask clips
        // everything outside that viewport.
        val viewportTransform = MatrixTransformation {
            val scale = when (state.videoScaleMode) {
                VideoScaleMode.FIT -> minOf(viewport.width, viewport.height)
                VideoScaleMode.FILL -> maxOf(viewport.width, viewport.height)
            }
            val tx = viewport.centerX * 2f - 1f
            // Canvas Y grows downward; NDC Y grows upward.
            val ty = 1f - viewport.centerY * 2f

            Matrix().apply {
                postScale(scale, scale)
                postTranslate(tx, ty)
            }
        }

        return listOf(presentation, viewportTransform)
    }

    fun exportEffects(context: Context, state: EditorState): List<Effect> {
        val effects = aspectRatioOnly(state).toMutableList()
        val (width, height) = CliporaRules.outputSize(state.aspectRatio)

        val overlayBitmap = NewsTemplateRenderer(context).render(
            state = state,
            width = width,
            height = height,
            includeTickerText = false,
            includeSponsorContent = false,
            includeBreakingContent = false,
            includeHeadlineContent = false,
            includeLowerHeadlineContent = false
        )
        val staticOverlay = BitmapOverlay.createStaticBitmapOverlay(overlayBitmap)
        val animatedOverlay = AnimatedTickerOverlay(context, state, width, height)
        effects += OverlayEffect(listOf(staticOverlay, animatedOverlay))
        return effects
    }
}
