package com.clipora.app.media

import android.content.Context
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import com.clipora.app.model.AspectRatioOption
import com.clipora.app.model.EditorState

@UnstableApi
object CliporaVideoEffects {
    fun aspectRatioOnly(state: EditorState): List<Effect> = listOf(
        Presentation.createForAspectRatio(
            state.aspectRatio.ratio,
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        )
    )

    fun exportEffects(context: Context, state: EditorState): List<Effect> {
        val effects = aspectRatioOnly(state).toMutableList()
        val (width, height) = outputSize(state.aspectRatio)
        val overlayBitmap = NewsTemplateRenderer(context).render(state, width, height)
        val overlay = BitmapOverlay.createStaticBitmapOverlay(overlayBitmap)
        effects += OverlayEffect(listOf(overlay))
        return effects
    }

    private fun outputSize(aspect: AspectRatioOption): Pair<Int, Int> = when (aspect) {
        AspectRatioOption.PORTRAIT -> 1080 to 1920
        AspectRatioOption.LANDSCAPE -> 1920 to 1080
        AspectRatioOption.SQUARE -> 1080 to 1080
        AspectRatioOption.SOCIAL -> 1080 to 1350
    }
}
