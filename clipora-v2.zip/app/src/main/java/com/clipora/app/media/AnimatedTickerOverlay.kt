package com.clipora.app.media

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import com.clipora.app.model.EditorState
import com.clipora.app.model.FontFamilyOption
import com.clipora.app.model.FontStyleOption
import com.clipora.app.model.TemplateStyle

@UnstableApi
class AnimatedTickerOverlay(
    private val state: EditorState,
    private val width: Int,
    private val height: Int
) : CanvasOverlay(false) {

    init {
        setCanvasSize(width, height)
    }

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val rowTop = height * 0.935f
        val rowBottom = height.toFloat()
        val liveWidth = width * 0.20f
        val liveRect = RectF(0f, rowTop, liveWidth, rowBottom)
        val tickerRect = RectF(liveWidth, rowTop, width.toFloat(), rowBottom)

        drawBlinkingLive(canvas, liveRect, presentationTimeUs)
        drawMarquee(canvas, tickerRect, presentationTimeUs)
    }

    private fun drawBlinkingLive(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val visible = (presentationTimeUs / 500_000L) % 2L == 0L
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = width * 0.032f
            textAlign = Paint.Align.CENTER
            typeface = typeface(state.style)
            alpha = if (visible) 255 else 45
        }
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f
        canvas.drawText(state.liveLabel, rect.centerX(), baseline, paint)
    }

    private fun drawMarquee(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val messages = state.marqueeItems.map { it.text.trim() }.filter { it.isNotEmpty() }
        if (messages.isEmpty()) return

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = state.style.textColor
            textSize = width * 0.027f
            textAlign = Paint.Align.LEFT
            typeface = typeface(state.style)
        }
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f

        // Scale speed with output width so motion feels similar for every aspect ratio.
        val speedPxPerSecond = width * 0.22f
        // The selected interval is implemented as real blank travel time between news lines.
        val gapPx = speedPxPerSecond * (state.marqueeInterval.millis / 1000f)
        val messageWidths = messages.map { paint.measureText(it) }
        val cycleWidth = messageWidths.sum() + gapPx * messages.size
        if (cycleWidth <= 1f) return

        val elapsedSeconds = presentationTimeUs / 1_000_000f
        val travelled = (elapsedSeconds * speedPxPerSecond) % cycleWidth
        val baseX = rect.right - travelled

        canvas.save()
        canvas.clipRect(rect)
        drawCycle(canvas, paint, messages, messageWidths, gapPx, baseX, baseline)
        drawCycle(canvas, paint, messages, messageWidths, gapPx, baseX - cycleWidth, baseline)
        drawCycle(canvas, paint, messages, messageWidths, gapPx, baseX + cycleWidth, baseline)
        canvas.restore()
    }

    private fun drawCycle(
        canvas: Canvas,
        paint: Paint,
        messages: List<String>,
        widths: List<Float>,
        gapPx: Float,
        startX: Float,
        baseline: Float
    ) {
        var x = startX
        messages.forEachIndexed { index, message ->
            canvas.drawText(message, x, baseline, paint)
            x += widths[index] + gapPx
        }
    }

    private fun typeface(style: TemplateStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }
}
