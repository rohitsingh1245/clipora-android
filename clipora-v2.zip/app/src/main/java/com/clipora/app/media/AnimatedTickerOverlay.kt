package com.clipora.app.media

import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import com.clipora.app.model.*

@UnstableApi
class AnimatedTickerOverlay(
    context: Context,
    private val state: EditorState,
    private val width: Int,
    private val height: Int
) : CanvasOverlay(false) {

    private val sponsorBitmaps: Map<Int, Bitmap> = state.sponsors.mapNotNull { item ->
        val uri = item.imageUri ?: return@mapNotNull null
        runCatching {
            val bitmap = context.contentResolver.openInputStream(Uri.parse(uri)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            item.id to bitmap
        }.getOrNull()
    }.toMap()

    init {
        setCanvasSize(width, height)
    }

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        if (state.style.sponsorMarqueeEnabled && state.sponsors.size > 1) {
            val adRect = RectF(
                0f,
                NewsLayoutMetrics.adTop(height),
                width.toFloat(),
                NewsLayoutMetrics.adBottom(height)
            )
            drawRotatingAdBanner(canvas, adRect, presentationTimeUs)
        }

        val rowTop = NewsLayoutMetrics.tickerTop(height)
        val rowBottom = height.toFloat()
        val liveWidth = width * 0.20f
        val liveRect = RectF(0f, rowTop, liveWidth, rowBottom)
        val tickerRect = RectF(liveWidth, rowTop, width.toFloat(), rowBottom)

        drawBlinkingLive(canvas, liveRect, presentationTimeUs)
        drawMarquee(canvas, tickerRect, presentationTimeUs)
    }

    private fun drawBlinkingLive(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val visible = (presentationTimeUs / 500_000L) % 2L == 0L
        val boxStyle = state.textStyle(TextTarget.LIVE)
        val paint = textPaint(boxStyle, width * 0.032f, Paint.Align.CENTER).apply {
            alpha = if (visible) 255 else 45
        }
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f
        canvas.drawText(state.liveLabel, rect.centerX(), baseline, paint)
    }

    private fun drawMarquee(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val messages = state.marqueeItems.map { it.text.trim() }.filter { it.isNotEmpty() }
        if (messages.isEmpty()) return

        val boxStyle = state.textStyle(TextTarget.TICKER)
        val paint = textPaint(boxStyle, width * 0.027f, Paint.Align.LEFT)
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f

        val speedPxPerSecond = width * 0.22f
        val gapPx = speedPxPerSecond * (state.marqueeInterval.millis / 1000f)
        val messageWidths = messages.map { paint.measureText(it) }
        val cycleWidth = messageWidths.sum() + gapPx * messages.size
        if (cycleWidth <= 1f) return

        val elapsedSeconds = presentationTimeUs / 1_000_000f
        val travelled = (elapsedSeconds * speedPxPerSecond) % cycleWidth
        val baseX = rect.right - travelled

        canvas.save()
        canvas.clipRect(rect)
        drawTextCycle(canvas, paint, messages, messageWidths, gapPx, baseX, baseline)
        drawTextCycle(canvas, paint, messages, messageWidths, gapPx, baseX - cycleWidth, baseline)
        drawTextCycle(canvas, paint, messages, messageWidths, gapPx, baseX + cycleWidth, baseline)
        canvas.restore()
    }

    private fun drawRotatingAdBanner(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val items = state.sponsors
        if (items.isEmpty()) return
        val intervalUs = state.style.sponsorMarqueeInterval.millis.coerceAtLeast(500L) * 1000L
        val index = ((presentationTimeUs / intervalUs) % items.size).toInt()
        val item = items[index]

        canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        val content = rect.insetCopy(rect.width() * .012f, rect.height() * .06f)

        if (item.kind == SponsorKind.LOGO) {
            val bitmap = sponsorBitmaps[item.id]
            if (bitmap != null) {
                val fitted = fitRect(bitmap.width, bitmap.height, content)
                canvas.drawBitmap(bitmap, null, fitted, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                return
            }
        }

        val style = state.textStyle(TextTarget.SPONSOR)
        val paint = textPaint(style, rect.height() * .28f, Paint.Align.CENTER)
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f
        canvas.drawText(item.text.ifBlank { "Advertisement" }, rect.centerX(), baseline, paint)
    }

    private fun drawTextCycle(
        canvas: Canvas,
        paint: Paint,
        messages: List<String>,
        widths: List<Float>,
        gapPx: Float,
        startX: Float,
        baseline: Float
    ) {
        var x = startX
        messages.forEachIndexed { index, message ->
            canvas.drawText(message, x, baseline, paint)
            x += widths[index] + gapPx
        }
    }

    private fun textPaint(style: TextBoxStyle, baseSize: Float, align: Paint.Align): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = style.textColor
        textSize = baseSize * style.sizeScale
        textAlign = align
        typeface = typeface(style)
    }

    private fun typeface(style: TextBoxStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun fitRect(bitmapWidth: Int, bitmapHeight: Int, target: RectF): RectF {
        val scale = minOf(target.width() / bitmapWidth.coerceAtLeast(1), target.height() / bitmapHeight.coerceAtLeast(1))
        val w = bitmapWidth * scale
        val h = bitmapHeight * scale
        return RectF(target.centerX() - w / 2f, target.centerY() - h / 2f, target.centerX() + w / 2f, target.centerY() + h / 2f)
    }

    private fun RectF.insetCopy(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right - dx, bottom - dy)
}
