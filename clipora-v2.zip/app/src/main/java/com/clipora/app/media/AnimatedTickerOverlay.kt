package com.clipora.app.media

import android.content.Context
import android.graphics.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import com.clipora.app.model.*

@UnstableApi
class AnimatedTickerOverlay(
    context: Context,
    private val state: EditorState,
    private val width: Int,
    private val height: Int
) : CanvasOverlay(false) {

    private val sponsorBitmaps: Map<Int, Bitmap> = state.sponsors.mapNotNull { item ->
        val uri = item.imageUri ?: return@mapNotNull null
        OrientedBitmapLoader.load(context, uri)?.let { item.id to it }
    }.toMap()

    init {
        setCanvasSize(width, height)
    }

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val spec = NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset)

        drawRotatingHeadline(
            canvas = canvas,
            rect = spec.headlineRect?.toAndroidRect(width, height),
            items = state.headlineItems,
            interval = state.headlineInterval,
            target = TextTarget.HEADLINE,
            presentationTimeUs = presentationTimeUs
        )

        drawBreakingBadge(canvas, spec.breakingBadgeRect?.toAndroidRect(width, height), presentationTimeUs)

        drawFlashLowerThird(
            canvas = canvas,
            rect = spec.bottomHeadlineRect?.toAndroidRect(width, height),
            presentationTimeUs = presentationTimeUs
        )

        spec.adRect?.let {
            if (CliporaRules.shouldRenderAdvertisement(state.sponsors.size)) {
                drawAdvertisementBanner(canvas, it.toAndroidRect(width, height), presentationTimeUs)
            }
        }

        val tickerRect = spec.tickerRect.toAndroidRect(width, height)
        val liveWidth = tickerRect.width() * 0.16f
        val liveRect = RectF(tickerRect.left, tickerRect.top, tickerRect.left + liveWidth, tickerRect.bottom)
        val textRect = RectF(liveRect.right, tickerRect.top, tickerRect.right, tickerRect.bottom)

        drawBlinkingLive(canvas, liveRect, presentationTimeUs)
        drawMarquee(canvas, textRect, presentationTimeUs)
    }

    private fun drawRotatingHeadline(
        canvas: Canvas,
        rect: RectF?,
        items: List<HeadlineItem>,
        interval: MarqueeIntervalOption,
        target: TextTarget,
        presentationTimeUs: Long
    ) {
        if (rect == null) return
        val visibleItems = items.filter { it.text.trim().isNotEmpty() }
        if (visibleItems.isEmpty()) return

        val frame = CliporaRules.popupAnimationFrame(
            itemCount = visibleItems.size,
            intervalMillis = interval.millis,
            presentationTimeUs = presentationTimeUs
        )
        if (frame.itemIndex < 0) return

        BroadcastGraphicsRenderer.drawHeadlineStrap(
            canvas = canvas,
            rect = rect,
            text = visibleItems[frame.itemIndex].text,
            textStyle = state.textStyle(target).copy(textColor = visibleItems[frame.itemIndex].textColor),
            accentColor = visibleItems[frame.itemIndex].backgroundColor,
            alpha = (frame.alpha * 255f).toInt(),
            scale = frame.scale,
            translationY = rect.height() * frame.translationFraction,
            maxLines = if (target == TextTarget.HEADLINE) 2 else 2
        )
    }

    private fun drawFlashLowerThird(canvas: Canvas, rect: RectF?, presentationTimeUs: Long) {
        if (rect == null) return
        val visibleItems = state.lowerHeadlineItems.filter { it.text.trim().isNotEmpty() }
        if (visibleItems.isEmpty()) return
        val index = CliporaRules.activeRotatingTextIndex(
            itemCount = visibleItems.size,
            intervalMillis = state.lowerHeadlineInterval.millis,
            presentationTimeUs = presentationTimeUs
        )
        if (index < 0) return
        val reveal = CliporaRules.lowerThirdRevealProgress(
            intervalMillis = state.lowerHeadlineInterval.millis,
            presentationTimeUs = presentationTimeUs
        )
        BroadcastGraphicsRenderer.drawFlashNewsStrap(
            canvas = canvas,
            rect = rect,
            text = visibleItems[index].text,
            textStyle = state.textStyle(TextTarget.BOTTOM_HEADLINE).copy(textColor = visibleItems[index].textColor),
            backgroundColor = visibleItems[index].backgroundColor,
            revealProgress = reveal,
            alpha = 255
        )
    }

    private fun drawBreakingBadge(canvas: Canvas, rect: RectF?, presentationTimeUs: Long) {
        val labels = state.breakingItems.map { it.text.trim() }.filter { it.isNotEmpty() }
        if (labels.isEmpty()) return

        if (rect == null) return

        // Hold the label for most of the cycle, then perform one deliberate front-to-back flip.
        val breakingFrame = CliporaRules.breakingAnimationFrame(
            itemCount = labels.size,
            intervalMillis = state.style.breakingInterval.millis,
            presentationTimeUs = presentationTimeUs,
            flipEnabled = state.style.breakingFlipEnabled
        )
        val labelIndex = breakingFrame.labelIndex
        val rotationX = breakingFrame.rotationX
        val phase = breakingFrame.phase
        val transitionAmount = if (breakingFrame.inTransition) 1f else 0f

        val text = labels[labelIndex]
        val textStyle = state.textStyle(TextTarget.BREAKING)
        val radius = rect.height() * .08f

        canvas.save()

        if (state.style.breakingFlipEnabled && transitionAmount > 0f) {
            val camera = Camera()
            val matrix = Matrix()
            camera.save()
            camera.rotateX(rotationX)
            camera.getMatrix(matrix)
            camera.restore()
            matrix.preTranslate(-rect.centerX(), -rect.centerY())
            matrix.postTranslate(rect.centerX(), rect.centerY())
            canvas.concat(matrix)
        }

        if (textStyle.backgroundEnabled) {
            if (state.style.breakingBadge3dEnabled) {
                val shadow = RectF(rect).apply { offset(0f, rect.height() * .10f) }
                canvas.drawRoundRect(
                    shadow,
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x70000000 }
                )

                val bg = textStyle.backgroundColor
                val gradient = LinearGradient(
                    rect.left,
                    rect.top,
                    rect.left,
                    rect.bottom,
                    intArrayOf(
                        lightenColor(bg, .34f),
                        bg,
                        darkenColor(bg, .18f),
                        darkenColor(bg, .42f)
                    ),
                    floatArrayOf(0f, .23f, .68f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(
                    rect,
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient }
                )

                canvas.drawRoundRect(
                    RectF(rect.left + 2f, rect.top + 2f, rect.right - 2f, rect.top + rect.height() * .20f),
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF }
                )
                canvas.drawRect(
                    RectF(
                        rect.left + rect.width() * .02f,
                        rect.bottom - rect.height() * .10f,
                        rect.right - rect.width() * .02f,
                        rect.bottom - rect.height() * .045f
                    ),
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000 }
                )

                // A single soft shine sweep per cycle instead of rapid strobing.
                if (state.style.breakingFlashEnabled) {
                    val shineX = rect.left + (rect.width() + rect.height() * 2f) * phase - rect.height()
                    val shineGradient = LinearGradient(
                        shineX - rect.height(),
                        rect.top,
                        shineX + rect.height(),
                        rect.top,
                        intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF),
                        floatArrayOf(0f, .5f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    canvas.save()
                    val badgeClip = Path().apply {
                        addRoundRect(rect, radius, radius, Path.Direction.CW)
                    }
                    canvas.clipPath(badgeClip)
                    canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = shineGradient })
                    canvas.restore()
                }
            } else {
                canvas.drawRoundRect(
                    rect,
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textStyle.backgroundColor }
                )
            }
        }

        val paint = textPaint(
            textStyle.copy(backgroundEnabled = false),
            rect.height() * .60f,
            Paint.Align.CENTER
        )
        val fm = paint.fontMetrics
        val baseline = rect.centerY() - (fm.ascent + fm.descent) / 2f
        canvas.drawText(text, rect.centerX(), baseline, paint)

        canvas.restore()
    }

    private fun lightenColor(color: Int, amount: Float): Int {
        val a = amount.coerceIn(0f, 1f)
        return Color.argb(
            Color.alpha(color),
            (Color.red(color) + (255 - Color.red(color)) * a).toInt(),
            (Color.green(color) + (255 - Color.green(color)) * a).toInt(),
            (Color.blue(color) + (255 - Color.blue(color)) * a).toInt()
        )
    }

    private fun darkenColor(color: Int, amount: Float): Int {
        val factor = (1f - amount).coerceIn(0f, 1f)
        return Color.argb(
            Color.alpha(color),
            (Color.red(color) * factor).toInt(),
            (Color.green(color) * factor).toInt(),
            (Color.blue(color) * factor).toInt()
        )
    }

    private fun drawBlinkingLive(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val visible = CliporaRules.isLiveVisible(presentationTimeUs)
        val boxStyle = state.textStyle(TextTarget.LIVE)
        val paint = textPaint(boxStyle, width * 0.032f, Paint.Align.CENTER).apply {
            alpha = if (visible) 255 else 45
        }
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f
        canvas.drawText(state.liveLabel, rect.centerX(), baseline, paint)
    }

    private fun drawMarquee(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val messages = state.marqueeItems.map { it.text.trim() }.filter { it.isNotEmpty() }
        if (messages.isEmpty()) return

        val boxStyle = state.textStyle(TextTarget.TICKER)
        val paint = textPaint(boxStyle, width * 0.027f, Paint.Align.LEFT)
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f

        val speedPxPerSecond = width * 0.22f
        val gapPx = speedPxPerSecond * (state.marqueeInterval.millis / 1000f)
        val messageWidths = messages.map { paint.measureText(it) }
        val cycleWidth = messageWidths.sum() + gapPx * messages.size
        if (cycleWidth <= 1f) return

        val elapsedSeconds = presentationTimeUs / 1_000_000f
        val travelled = (elapsedSeconds * speedPxPerSecond) % cycleWidth
        val baseX = rect.right - travelled

        canvas.save()
        canvas.clipRect(rect)
        drawTextCycle(canvas, paint, messages, messageWidths, gapPx, baseX, baseline)
        drawTextCycle(canvas, paint, messages, messageWidths, gapPx, baseX - cycleWidth, baseline)
        drawTextCycle(canvas, paint, messages, messageWidths, gapPx, baseX + cycleWidth, baseline)
        canvas.restore()
    }

    private fun drawAdvertisementBanner(canvas: Canvas, rect: RectF, presentationTimeUs: Long) {
        val items = state.sponsors
        if (items.isEmpty()) return
        val index = CliporaRules.activeAdvertisementIndex(
            itemCount = items.size,
            rotationEnabled = state.style.sponsorMarqueeEnabled,
            intervalMillis = state.style.sponsorMarqueeInterval.millis,
            presentationTimeUs = presentationTimeUs
        )
        val item = items[index]

        canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        val content = rect.insetCopy(rect.width() * .012f, rect.height() * .06f)

        if (item.kind == SponsorKind.LOGO) {
            val bitmap = sponsorBitmaps[item.id]
            if (bitmap != null) {
                val fitted = fitRect(bitmap.width, bitmap.height, content)
                canvas.drawBitmap(bitmap, null, fitted, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                return
            }
        }

        val style = state.textStyle(TextTarget.SPONSOR)
        val paint = textPaint(style, rect.height() * .28f, Paint.Align.CENTER)
        val metrics = paint.fontMetrics
        val baseline = rect.centerY() - (metrics.ascent + metrics.descent) / 2f
        canvas.drawText(item.text.ifBlank { "Advertisement" }, rect.centerX(), baseline, paint)
    }

    private fun drawTextCycle(
        canvas: Canvas,
        paint: Paint,
        messages: List<String>,
        widths: List<Float>,
        gapPx: Float,
        startX: Float,
        baseline: Float
    ) {
        var x = startX
        messages.forEachIndexed { index, message ->
            canvas.drawText(message, x, baseline, paint)
            x += widths[index] + gapPx
        }
    }

    private fun textPaint(style: TextBoxStyle, baseSize: Float, align: Paint.Align): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = style.textColor
        textSize = baseSize * style.sizeScale
        textAlign = align
        typeface = typeface(style)
    }

    private fun typeface(style: TextBoxStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun fitRect(bitmapWidth: Int, bitmapHeight: Int, target: RectF): RectF {
        val scale = minOf(target.width() / bitmapWidth.coerceAtLeast(1), target.height() / bitmapHeight.coerceAtLeast(1))
        val w = bitmapWidth * scale
        val h = bitmapHeight * scale
        return RectF(target.centerX() - w / 2f, target.centerY() - h / 2f, target.centerX() + w / 2f, target.centerY() + h / 2f)
    }

    private fun NormalizedRect.toAndroidRect(width: Int, height: Int): RectF =
        RectF(left * width, top * height, right * width, bottom * height)

    private fun RectF.insetCopy(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right - dx, bottom - dy)
}
