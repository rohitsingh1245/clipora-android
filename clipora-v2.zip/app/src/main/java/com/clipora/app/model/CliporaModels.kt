package com.clipora.app.model

enum class AspectRatioOption(val label: String, val ratio: Float) {
    PORTRAIT("9:16", 9f / 16f),
    LANDSCAPE("16:9", 16f / 9f),
    SQUARE("1:1", 1f),
    SOCIAL("4:5", 4f / 5f)
}

enum class DurationOption(val label: String, val millis: Long) {
    THIRTY_SECONDS("30 sec", 30_000L),
    ONE_MINUTE("1 min", 60_000L),
    TWO_MINUTES("2 min", 120_000L)
}

enum class ThemePreset(val title: String, val subtitle: String) {
    NEWS("News", "Layered breaking-news layout"),
    WEDDING("Wedding", "Elegant celebration styling"),
    BIRTHDAY("Birthday", "Bright celebration styling"),
    BUSINESS("Business", "Clean professional styling"),
    CUSTOM("Custom", "Fully editable styling")
}

enum class SponsorKind { TEXT, LOGO }

enum class VideoScaleMode(val label: String) {
    FIT("Fit - show full video"),
    FILL("Fill - crop to frame")
}

enum class FontFamilyOption(val label: String) {
    SANS("Sans"), SERIF("Serif"), MONOSPACE("Mono")
}

enum class FontStyleOption(val label: String) {
    NORMAL("Normal"), BOLD("Bold"), ITALIC("Italic"), BOLD_ITALIC("Bold Italic")
}

enum class HeadlineSizeOption(val label: String, val scale: Float) {
    SMALL("Small", 0.86f), MEDIUM("Medium", 1f), LARGE("Large", 1.18f)
}

enum class MarqueeIntervalOption(val label: String, val millis: Long) {
    SHORT("0.5 sec", 500L),
    NORMAL("1 sec", 1_000L),
    LONG("2 sec", 2_000L),
    EXTRA_LONG("3 sec", 3_000L)
}

data class TemplateStyle(
    val backgroundColor: Int = 0xFF0B2B59.toInt(),
    val accentColor: Int = 0xFFD71920.toInt(),
    val secondaryColor: Int = 0xFFF0C419.toInt(),
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val borderColor: Int = 0xFFFFFFFF.toInt(),
    val tickerBackgroundColor: Int = 0xFF9E1117.toInt(),
    val fontFamily: FontFamilyOption = FontFamilyOption.SANS,
    val fontStyle: FontStyleOption = FontStyleOption.BOLD,
    val headlineSize: HeadlineSizeOption = HeadlineSizeOption.MEDIUM,
    val sponsorColumns: Int = 3
)

data class SponsorItem(
    val id: Int,
    val kind: SponsorKind,
    val text: String = "Sponsor",
    val imageUri: String? = null
)

data class MarqueeItem(
    val id: Int,
    val text: String
)

data class SavedTheme(
    val id: String,
    val name: String,
    val style: TemplateStyle,
    val logoText: String,
    val channelLogoUri: String?,
    val watermarkLogoUri: String?,
    val bannerText: String,
    val liveLabel: String,
    val marqueeInterval: MarqueeIntervalOption
)

data class EditorState(
    val mediaUri: String? = null,
    val aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT,
    val duration: DurationOption = DurationOption.THIRTY_SECONDS,
    val theme: ThemePreset = ThemePreset.NEWS,
    val style: TemplateStyle = TemplateStyle(),
    val location: String = "LONDON",
    val logoText: String = "CLIPORA",
    val channelLogoUri: String? = null,
    val headline: String = "YOUR BREAKING NEWS HEADLINE GOES HERE",
    val bannerText: String = "BREAKING NEWS",
    val watermarkLogoUri: String? = null,
    val advertiserName: String = "YOUR ADVERTISER / SHOP NAME",
    val sponsors: List<SponsorItem> = listOf(
        SponsorItem(1, SponsorKind.TEXT, "50% OFF"),
        SponsorItem(2, SponsorKind.TEXT, "SPONSOR 1"),
        SponsorItem(3, SponsorKind.TEXT, "SPONSOR 2")
    ),
    val contactText: String = "Address • Phone • Website",
    val liveLabel: String = "LIVE",
    val marqueeItems: List<MarqueeItem> = listOf(
        MarqueeItem(1, "Add your latest news ticker here")
    ),
    val marqueeInterval: MarqueeIntervalOption = MarqueeIntervalOption.NORMAL,
    val videoScaleMode: VideoScaleMode = VideoScaleMode.FIT,
    val mediaRevision: Int = 0,
    val trimStartMs: Long = 0L,
    val sourceDurationMs: Long = 0L,
    val exportStatus: String? = null
) {
    val effectiveEndMs: Long?
        get() {
            if (sourceDurationMs <= 0L) return null
            val requested = trimStartMs + duration.millis
            return requested.takeIf { it < sourceDurationMs }
        }
}

fun presetStyle(preset: ThemePreset): TemplateStyle = when (preset) {
    ThemePreset.NEWS -> TemplateStyle()
    ThemePreset.WEDDING -> TemplateStyle(
        backgroundColor = 0xFF5D2848.toInt(), accentColor = 0xFF9E5E7B.toInt(), secondaryColor = 0xFFE4B7C8.toInt()
    )
    ThemePreset.BIRTHDAY -> TemplateStyle(
        backgroundColor = 0xFF3C256B.toInt(), accentColor = 0xFF7E57C2.toInt(), secondaryColor = 0xFFFFC857.toInt()
    )
    ThemePreset.BUSINESS -> TemplateStyle(
        backgroundColor = 0xFF173755.toInt(), accentColor = 0xFF245F8F.toInt(), secondaryColor = 0xFFB8D8F0.toInt()
    )
    ThemePreset.CUSTOM -> TemplateStyle(
        backgroundColor = 0xFF303030.toInt(), accentColor = 0xFF555555.toInt(), secondaryColor = 0xFFE0E0E0.toInt()
    )
}
