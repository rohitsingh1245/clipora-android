package com.clipora.app.model

enum class AspectRatioOption(val label: String, val ratio: Float) {
    PORTRAIT("9:16", 9f / 16f),
    LANDSCAPE("16:9", 16f / 9f),
    SQUARE("1:1", 1f),
    SOCIAL("4:5", 4f / 5f)
}


enum class LayoutPreset(val label: String, val aspect: AspectRatioOption) {
    SHORTS_CLASSIC("Classic", AspectRatioOption.PORTRAIT),
    LANDSCAPE_CLASSIC("Classic", AspectRatioOption.LANDSCAPE),
    LANDSCAPE_SIDE_TEXT("Side text", AspectRatioOption.LANDSCAPE),
    LANDSCAPE_SIDE_IMAGE("Side image", AspectRatioOption.LANDSCAPE),
    LANDSCAPE_SIDE_PANELS("Both sides", AspectRatioOption.LANDSCAPE),
    SQUARE_CLASSIC("Classic", AspectRatioOption.SQUARE),
    SOCIAL_FEED("Feed", AspectRatioOption.SOCIAL)
}

enum class SidePanelMode { NONE, TEXT, IMAGE, LEFT_AND_RIGHT }

data class HeadlineItem(
    val id: Int,
    val text: String,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val backgroundColor: Int = 0xFFD71920.toInt()
)

enum class DurationOption(val label: String, val millis: Long) {
    THIRTY_SECONDS("30 sec", 30_000L),
    ONE_MINUTE("1 min", 60_000L),
    TWO_MINUTES("2 min", 120_000L)
}

enum class ThemePreset(val title: String, val subtitle: String) {
    NEWS("News", "Layered breaking-news layout"),
    WEDDING("Wedding", "Elegant celebration styling"),
    BIRTHDAY("Birthday", "Bright celebration styling"),
    BUSINESS("Business", "Clean professional styling"),
    CUSTOM("Custom", "Fully editable styling")
}

enum class SponsorKind { TEXT, LOGO }

enum class EditorMediaMode { VIDEO, IMAGE }

enum class VideoScaleMode(val label: String) {
    FIT("Fit - show full video"),
    FILL("Fill - crop to frame")
}

enum class FontFamilyOption(val label: String) {
    SANS("Sans"), SERIF("Serif"), MONOSPACE("Mono")
}

enum class FontStyleOption(val label: String) {
    NORMAL("Normal"), BOLD("Bold"), ITALIC("Italic"), BOLD_ITALIC("Bold Italic")
}

enum class HeadlineSizeOption(val label: String, val scale: Float) {
    SMALL("Small", 0.86f), MEDIUM("Medium", 1f), LARGE("Large", 1.18f)
}

enum class MarqueeIntervalOption(val label: String, val millis: Long) {
    SHORT("0.5 sec", 500L),
    NORMAL("1 sec", 1_000L),
    LONG("2 sec", 2_000L),
    EXTRA_LONG("3 sec", 3_000L),
    FIVE_SECONDS("5 sec", 5_000L)
}

enum class TextAlignmentOption(val label: String) {
    START("Left"), CENTER("Centre"), END("Right")
}

enum class TextTarget(val label: String) {
    LOCATION("Location"),
    CHANNEL("Channel / logo text"),
    HEADLINE("Headline"),
    BOTTOM_HEADLINE("Lower headline"),
    SIDE_TEXT("Side text"),
    BREAKING("Breaking News"),
    SPONSOR("Sponsor / banner text"),
    LIVE("LIVE"),
    TICKER("News marquee")
}

data class TextBoxStyle(
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val backgroundColor: Int = 0x00000000,
    val backgroundEnabled: Boolean = false,
    val fontFamily: FontFamilyOption = FontFamilyOption.SANS,
    val fontStyle: FontStyleOption = FontStyleOption.BOLD,
    val sizeScale: Float = 1f,
    val alignment: TextAlignmentOption = TextAlignmentOption.CENTER
)

data class TemplateStyle(
    val backgroundColor: Int = 0xFF0B2B59.toInt(),
    val backgroundImageUri: String? = null,
    val backgroundBlur: Float = 0f,
    val accentColor: Int = 0xFFD71920.toInt(),
    val secondaryColor: Int = 0xFFF0C419.toInt(),
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val borderColor: Int = 0xFFFFFFFF.toInt(),
    val tickerBackgroundColor: Int = 0xFF9E1117.toInt(),
    val fontFamily: FontFamilyOption = FontFamilyOption.SANS,
    val fontStyle: FontStyleOption = FontStyleOption.BOLD,
    val headlineSize: HeadlineSizeOption = HeadlineSizeOption.MEDIUM,
    val sponsorColumns: Int = 3,
    val sponsorMarqueeEnabled: Boolean = false,
    val sponsorMarqueeInterval: MarqueeIntervalOption = MarqueeIntervalOption.NORMAL,
    val breakingFlashEnabled: Boolean = true,
    val breakingFlipEnabled: Boolean = true,
    val breakingBadge3dEnabled: Boolean = true,
    val breakingInterval: MarqueeIntervalOption = MarqueeIntervalOption.EXTRA_LONG
)

data class SponsorItem(
    val id: Int,
    val kind: SponsorKind,
    val text: String = "Sponsor",
    val imageUri: String? = null
)

data class MarqueeItem(
    val id: Int,
    val text: String
)

data class BreakingItem(
    val id: Int,
    val text: String
)

data class SavedTheme(
    val id: String,
    val name: String,
    val style: TemplateStyle,
    val textStyles: Map<TextTarget, TextBoxStyle>,
    val logoText: String,
    val channelLogoUri: String?,
    val watermarkLogoUri: String?,
    val bannerText: String,
    val breakingItems: List<BreakingItem>,
    val liveLabel: String,
    val marqueeInterval: MarqueeIntervalOption,
    val aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT,
    val layoutPreset: LayoutPreset = LayoutPreset.SHORTS_CLASSIC
)

data class EditorState(
    val mediaUri: String? = null,
    val aspectRatio: AspectRatioOption = AspectRatioOption.PORTRAIT,
    val layoutPreset: LayoutPreset = LayoutPreset.SHORTS_CLASSIC,
    val duration: DurationOption = DurationOption.THIRTY_SECONDS,
    val theme: ThemePreset = ThemePreset.NEWS,
    val style: TemplateStyle = TemplateStyle(),
    val textStyles: Map<TextTarget, TextBoxStyle> = defaultTextStyles(),
    val location: String = "नई दिल्ली",
    val logoText: String = "NEWS 24",
    val channelLogoUri: String? = null,
    val headline: String = "भारत की बड़ी खबर",
    val headlineItems: List<HeadlineItem> = listOf(
        HeadlineItem(1, "भारत की बड़ी खबर"),
        HeadlineItem(2, "देश-दुनिया की ताज़ा अपडेट"),
        HeadlineItem(3, "पूरी रिपोर्ट कुछ ही पलों में")
    ),
    val lowerHeadlineItems: List<HeadlineItem> = listOf(
        HeadlineItem(101, "ताज़ा अपडेट", 0xFF111111.toInt(), 0xFFFFD900.toInt()),
        HeadlineItem(102, "ब्रेकिंग खबर", 0xFF111111.toInt(), 0xFFFFD900.toInt()),
        HeadlineItem(103, "विशेष रिपोर्ट", 0xFF111111.toInt(), 0xFFFFD900.toInt()),
        HeadlineItem(104, "ग्राउंड रिपोर्ट", 0xFF111111.toInt(), 0xFFFFD900.toInt()),
        HeadlineItem(105, "अभी-अभी", 0xFF111111.toInt(), 0xFFFFD900.toInt())
    ),
    val headlineInterval: MarqueeIntervalOption = MarqueeIntervalOption.EXTRA_LONG,
    val lowerHeadlineInterval: MarqueeIntervalOption = MarqueeIntervalOption.EXTRA_LONG,
    val sidePanelText: String = "मुख्य खबर से जुड़ी जरूरी जानकारी यहाँ लिखें।",
    val sidePanelImageUri: String? = null,
    val bannerText: String = "BREAKING NEWS",
    val breakingItems: List<BreakingItem> = listOf(
        BreakingItem(1, "BREAKING NEWS"),
        BreakingItem(2, "EXCLUSIVE"),
        BreakingItem(3, "SPECIAL REPORT")
    ),
    val watermarkLogoUri: String? = null,
    val sponsors: List<SponsorItem> = listOf(
        SponsorItem(1, SponsorKind.TEXT, "YOUR ADVERTISEMENT")
    ),
    val liveLabel: String = "LIVE",
    val marqueeItems: List<MarqueeItem> = listOf(
        MarqueeItem(1, "ताज़ा खबरें लगातार आपके साथ"),
        MarqueeItem(2, "देश और दुनिया की बड़ी खबरें")
    ),
    val marqueeInterval: MarqueeIntervalOption = MarqueeIntervalOption.NORMAL,
    val videoScaleMode: VideoScaleMode = VideoScaleMode.FIT,
    val mediaRevision: Int = 0,
    val trimStartMs: Long = 0L,
    val sourceDurationMs: Long = 0L,
    val exportStatus: String? = null,
    val exportProgress: Int? = null,
    val isUsingDemoContent: Boolean = true
) {
    val effectiveEndMs: Long?
        get() {
            if (sourceDurationMs <= 0L) return null
            val requested = trimStartMs + duration.millis
            return requested.takeIf { it < sourceDurationMs }
        }

    fun textStyle(target: TextTarget): TextBoxStyle = textStyles[target] ?: defaultTextStyle(target)
}

fun defaultTextStyle(target: TextTarget): TextBoxStyle = when (target) {
    TextTarget.LOCATION -> TextBoxStyle(
        textColor = 0xFFFFFFFF.toInt(), backgroundColor = 0xFFD71920.toInt(), backgroundEnabled = true,
        fontStyle = FontStyleOption.BOLD, sizeScale = 0.92f, alignment = TextAlignmentOption.CENTER
    )
    TextTarget.CHANNEL -> TextBoxStyle(fontStyle = FontStyleOption.BOLD, sizeScale = 1.0f)
    TextTarget.HEADLINE -> TextBoxStyle(fontStyle = FontStyleOption.BOLD, sizeScale = 1.0f)
    TextTarget.BOTTOM_HEADLINE -> TextBoxStyle(fontStyle = FontStyleOption.BOLD, sizeScale = 0.95f)
    TextTarget.SIDE_TEXT -> TextBoxStyle(textColor = 0xFF202020.toInt(), backgroundColor = 0xFFFFFFFF.toInt(), backgroundEnabled = true, fontStyle = FontStyleOption.BOLD, sizeScale = 0.9f)
    TextTarget.BREAKING -> TextBoxStyle(
        textColor = 0xFFFFFFFF.toInt(),
        backgroundColor = 0xFFE31B23.toInt(),
        backgroundEnabled = true,
        fontStyle = FontStyleOption.BOLD,
        sizeScale = 1.18f,
        alignment = TextAlignmentOption.CENTER
    )
    TextTarget.SPONSOR -> TextBoxStyle(
        textColor = 0xFF202020.toInt(), backgroundEnabled = false,
        fontStyle = FontStyleOption.BOLD, sizeScale = 0.92f, alignment = TextAlignmentOption.CENTER
    )
    TextTarget.LIVE -> TextBoxStyle(
        textColor = 0xFFFFFFFF.toInt(), backgroundColor = 0xFFD71920.toInt(), backgroundEnabled = true,
        fontStyle = FontStyleOption.BOLD, sizeScale = 0.95f, alignment = TextAlignmentOption.CENTER
    )
    TextTarget.TICKER -> TextBoxStyle(
        textColor = 0xFFFFFFFF.toInt(), backgroundEnabled = false,
        fontStyle = FontStyleOption.NORMAL, sizeScale = 0.88f, alignment = TextAlignmentOption.START
    )
}

fun defaultTextStyles(): Map<TextTarget, TextBoxStyle> = TextTarget.entries.associateWith(::defaultTextStyle)

fun presetStyle(preset: ThemePreset): TemplateStyle = when (preset) {
    ThemePreset.NEWS -> TemplateStyle()
    ThemePreset.WEDDING -> TemplateStyle(
        backgroundColor = 0xFF5D2848.toInt(), accentColor = 0xFF9E5E7B.toInt(), secondaryColor = 0xFFE4B7C8.toInt()
    )
    ThemePreset.BIRTHDAY -> TemplateStyle(
        backgroundColor = 0xFF3C256B.toInt(), accentColor = 0xFF7E57C2.toInt(), secondaryColor = 0xFFFFC857.toInt()
    )
    ThemePreset.BUSINESS -> TemplateStyle(
        backgroundColor = 0xFF173755.toInt(), accentColor = 0xFF245F8F.toInt(), secondaryColor = 0xFFB8D8F0.toInt()
    )
    ThemePreset.CUSTOM -> TemplateStyle(
        backgroundColor = 0xFF303030.toInt(), accentColor = 0xFF555555.toInt(), secondaryColor = 0xFFE0E0E0.toInt()
    )
}
