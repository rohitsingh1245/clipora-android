package com.clipora.app.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import com.clipora.app.media.NewsTemplateRenderer
import com.clipora.app.model.EditorState
import kotlin.math.roundToInt

class ImageExportManager(private val context: Context) {
    fun export(state: EditorState): Result<Uri> = runCatching {
        val input = requireNotNull(state.mediaUri) { "Choose an image first." }
        val bitmap = context.contentResolver.openInputStream(Uri.parse(input)).use { stream ->
            requireNotNull(stream) { "Unable to open image." }
            requireNotNull(BitmapFactory.decodeStream(stream)) { "Unable to decode image." }
        }

        val cropped = centerCrop(bitmap, state.aspectRatio.ratio)
        val mutable = cropped.copy(Bitmap.Config.ARGB_8888, true)
        if (cropped !== bitmap) cropped.recycle()
        if (bitmap !== cropped) bitmap.recycle()

        val overlay = NewsTemplateRenderer(context).render(state, mutable.width, mutable.height)
        Canvas(mutable).drawBitmap(overlay, 0f, 0f, null)
        overlay.recycle()

        val result = GalleryStore.saveImage(context) { output ->
            check(mutable.compress(Bitmap.CompressFormat.JPEG, 94, output)) { "JPEG export failed." }
        }
        mutable.recycle()
        result
    }

    private fun centerCrop(source: Bitmap, ratio: Float): Bitmap {
        val sourceRatio = source.width.toFloat() / source.height
        if (sourceRatio > ratio) {
            val width = (source.height * ratio).roundToInt().coerceAtMost(source.width)
            val x = (source.width - width) / 2
            return Bitmap.createBitmap(source, x, 0, width, source.height)
        }
        val height = (source.width / ratio).roundToInt().coerceAtMost(source.height)
        val y = (source.height - height) / 2
        return Bitmap.createBitmap(source, 0, y, source.width, height)
    }
}
