package com.clipora.app.export

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import com.clipora.app.media.NewsTemplateRenderer
import com.clipora.app.model.CliporaRules
import com.clipora.app.model.EditorState
import com.clipora.app.model.NewsLayoutEngine
import com.clipora.app.model.VideoScaleMode

class ImageExportManager(private val context: Context) {
    fun export(state: EditorState): Result<Uri> = runCatching {
        val input = requireNotNull(state.mediaUri) { "Choose an image first." }
        val source = decodeImage(Uri.parse(input))
        try {
            val (width, height) = CliporaRules.outputSize(state.aspectRatio)
            val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(output)

            val frameSpec = NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset).videoRect.toPixels(width, height)
            val frame = RectF(frameSpec.left, frameSpec.top, frameSpec.right, frameSpec.bottom)

            canvas.drawColor(state.style.backgroundColor)
            canvas.drawRect(frame, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK })
            drawImageIntoFrame(canvas, source, frame, state.videoScaleMode)

            val overlay = NewsTemplateRenderer(context).render(state, width, height)
            canvas.drawBitmap(overlay, 0f, 0f, null)
            overlay.recycle()

            val result = GalleryStore.saveImage(context) { outputStream ->
                check(output.compress(Bitmap.CompressFormat.JPEG, 94, outputStream)) {
                    "JPEG export failed."
                }
            }
            output.recycle()
            result
        } finally {
            source.recycle()
        }
    }

    private fun decodeImage(uri: Uri): Bitmap {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            context.contentResolver.openInputStream(uri).use { stream ->
                requireNotNull(stream) { "Unable to open image." }
                requireNotNull(BitmapFactory.decodeStream(stream)) { "Unable to decode image." }
            }
        }
    }

    private fun drawImageIntoFrame(
        canvas: Canvas,
        source: Bitmap,
        frame: RectF,
        mode: VideoScaleMode
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        when (mode) {
            VideoScaleMode.FIT -> {
                val dest = CliporaRules.fitDestinationRect(
                    source.width,
                    source.height,
                    frame.left,
                    frame.top,
                    frame.right,
                    frame.bottom
                )
                canvas.drawBitmap(
                    source,
                    null,
                    RectF(dest.left, dest.top, dest.right, dest.bottom),
                    paint
                )
            }

            VideoScaleMode.FILL -> {
                val crop = CliporaRules.fillSourceCropRect(
                    source.width,
                    source.height,
                    frame.width() / frame.height()
                )
                canvas.drawBitmap(
                    source,
                    Rect(
                        crop.left.toInt(),
                        crop.top.toInt(),
                        crop.right.toInt(),
                        crop.bottom.toInt()
                    ),
                    frame,
                    paint
                )
            }
        }
    }
}
