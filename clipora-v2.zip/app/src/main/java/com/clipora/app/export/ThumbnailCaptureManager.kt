package com.clipora.app.export

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.clipora.app.model.CliporaRules

object ThumbnailCaptureManager {
    fun capture(
        context: Context,
        mediaUri: String,
        positionMs: Long,
        durationMs: Long = 0L
    ): Result<Uri> = runCatching {
        val uri = Uri.parse(mediaUri)
        val requestedPositionMs = CliporaRules.thumbnailPositionMs(positionMs, durationMs)
        val retriever = MediaMetadataRetriever()

        try {
            setDataSourceSafely(context, retriever, uri)

            val requestedUs = requestedPositionMs * 1_000L
            val frame = retriever.getFrameAtTime(requestedUs, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: retriever.getFrameAtTime(requestedUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: error("Unable to capture a frame from this video.")

            try {
                GalleryStore.saveImage(
                    context = context,
                    relativePath = CliporaRules.THUMBNAIL_GALLERY_PATH,
                    prefix = "Clipora_Thumbnail"
                ) { output ->
                    check(frame.compress(Bitmap.CompressFormat.JPEG, 94, output)) {
                        "Thumbnail JPEG export failed."
                    }
                }
            } finally {
                frame.recycle()
            }
        } finally {
            retriever.release()
        }
    }

    private fun setDataSourceSafely(
        context: Context,
        retriever: MediaMetadataRetriever,
        uri: Uri
    ) {
        var fileDescriptorFailure: Throwable? = null

        try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: error("Unable to open the selected video.")
            pfd.use {
                retriever.setDataSource(it.fileDescriptor)
            }
            return
        } catch (t: Throwable) {
            fileDescriptorFailure = t
        }

        try {
            retriever.setDataSource(context, uri)
        } catch (fallbackFailure: Throwable) {
            fallbackFailure.addSuppressed(fileDescriptorFailure)
            throw IllegalStateException(
                "Clipora could not read this video for thumbnail capture. Try importing the video again.",
                fallbackFailure
            )
        }
    }
}
