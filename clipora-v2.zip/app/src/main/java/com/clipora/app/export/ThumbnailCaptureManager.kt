package com.clipora.app.export

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.clipora.app.model.CliporaRules

object ThumbnailCaptureManager {
    fun capture(context: Context, mediaUri: String, positionMs: Long): Result<Uri> = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(mediaUri))
            val frame = requireNotNull(
                retriever.getFrameAtTime(
                    positionMs.coerceAtLeast(0L) * 1_000L,
                    MediaMetadataRetriever.OPTION_CLOSEST
                )
            ) { "Unable to capture video frame." }

            try {
                GalleryStore.saveImage(
                    context = context,
                    relativePath = CliporaRules.THUMBNAIL_GALLERY_PATH,
                    prefix = "Clipora_Thumbnail"
                ) { output ->
                    check(frame.compress(Bitmap.CompressFormat.JPEG, 94, output)) {
                        "Thumbnail JPEG export failed."
                    }
                }
            } finally {
                frame.recycle()
            }
        } finally {
            retriever.release()
        }
    }
}
