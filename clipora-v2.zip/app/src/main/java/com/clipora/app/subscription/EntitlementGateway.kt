package com.clipora.app.subscription

enum class EntitlementState {
    TRIAL,
    ACTIVE,
    EXPIRED
}

interface EntitlementGateway {
    suspend fun refresh(): EntitlementState
}

/**
 * Phase 1 test build intentionally bypasses sign-in and payment.
 *
 * Production implementation must restore entitlement from a signed-in account/server
 * plus Google Play Billing state. It must never rely on uninstallable local storage
 * to decide whether a one-month trial has already been consumed.
 */
class PhaseOneEntitlementGateway : EntitlementGateway {
    override suspend fun refresh(): EntitlementState = EntitlementState.ACTIVE
}
