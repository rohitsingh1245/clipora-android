package com.clipora.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CliporaColors = lightColorScheme()

@Composable
fun CliporaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CliporaColors,
        content = content
    )
}
