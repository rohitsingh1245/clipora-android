package com.clipora.app.storage

import android.content.Context
import com.clipora.app.model.*
import org.json.JSONArray
import org.json.JSONObject

class ThemeRepository(context: Context) {
    private val prefs = context.getSharedPreferences("clipora_themes", Context.MODE_PRIVATE)

    fun list(): List<SavedTheme> = runCatching {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) add(fromJson(array.getJSONObject(i)))
        }
    }.getOrDefault(emptyList())

    fun save(theme: SavedTheme) {
        val themes = list().toMutableList()
        val index = themes.indexOfFirst { it.id == theme.id }
        if (index >= 0) themes[index] = theme else themes.add(theme)
        write(themes)
    }

    fun delete(id: String) = write(list().filterNot { it.id == id })

    private fun write(themes: List<SavedTheme>) {
        val array = JSONArray()
        themes.forEach { array.put(toJson(it)) }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private fun toJson(theme: SavedTheme) = JSONObject().apply {
        put("id", theme.id)
        put("name", theme.name)
        put("logoText", theme.logoText)
        put("channelLogoUri", theme.channelLogoUri ?: JSONObject.NULL)
        put("watermarkLogoUri", theme.watermarkLogoUri ?: JSONObject.NULL)
        put("bannerText", theme.bannerText)
        put("liveLabel", theme.liveLabel)
        put("marqueeInterval", theme.marqueeInterval.name)
        put("style", JSONObject().apply {
            put("backgroundColor", theme.style.backgroundColor)
            put("accentColor", theme.style.accentColor)
            put("secondaryColor", theme.style.secondaryColor)
            put("textColor", theme.style.textColor)
            put("borderColor", theme.style.borderColor)
            put("tickerBackgroundColor", theme.style.tickerBackgroundColor)
            put("fontFamily", theme.style.fontFamily.name)
            put("fontStyle", theme.style.fontStyle.name)
            put("headlineSize", theme.style.headlineSize.name)
            put("sponsorColumns", theme.style.sponsorColumns)
        })
    }

    private fun fromJson(json: JSONObject): SavedTheme {
        val styleJson = json.getJSONObject("style")
        val style = TemplateStyle(
            backgroundColor = styleJson.getInt("backgroundColor"),
            accentColor = styleJson.getInt("accentColor"),
            secondaryColor = styleJson.getInt("secondaryColor"),
            textColor = styleJson.getInt("textColor"),
            borderColor = styleJson.getInt("borderColor"),
            tickerBackgroundColor = styleJson.getInt("tickerBackgroundColor"),
            fontFamily = FontFamilyOption.valueOf(styleJson.getString("fontFamily")),
            fontStyle = FontStyleOption.valueOf(styleJson.getString("fontStyle")),
            headlineSize = HeadlineSizeOption.valueOf(styleJson.getString("headlineSize")),
            sponsorColumns = styleJson.getInt("sponsorColumns")
        )
        return SavedTheme(
            id = json.getString("id"),
            name = json.getString("name"),
            style = style,
            logoText = json.optString("logoText", "CLIPORA"),
            channelLogoUri = json.optString("channelLogoUri").takeIf { it.isNotBlank() && it != "null" },
            watermarkLogoUri = json.optString("watermarkLogoUri").takeIf { it.isNotBlank() && it != "null" },
            bannerText = json.optString("bannerText", "BREAKING NEWS"),
            liveLabel = json.optString("liveLabel", "LIVE"),
            marqueeInterval = runCatching {
                MarqueeIntervalOption.valueOf(json.optString("marqueeInterval", MarqueeIntervalOption.NORMAL.name))
            }.getOrDefault(MarqueeIntervalOption.NORMAL)
        )
    }

    companion object { private const val KEY = "saved_themes" }
}
