package com.clipora.app.storage

import android.content.Context
import com.clipora.app.model.*
import org.json.JSONObject
import org.json.JSONArray

class ThemeRepository(context: Context) {
    private val prefs = context.getSharedPreferences("clipora_themes", Context.MODE_PRIVATE)

    fun list(): List<SavedTheme> = runCatching {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) add(fromJson(array.getJSONObject(i)))
        }
    }.getOrDefault(emptyList())

    fun save(theme: SavedTheme) {
        val themes = list().toMutableList()
        val index = themes.indexOfFirst { it.id == theme.id }
        if (index >= 0) themes[index] = theme else themes.add(theme)
        write(themes)
    }

    fun delete(id: String) = write(list().filterNot { it.id == id })

    private fun write(themes: List<SavedTheme>) {
        val array = JSONArray()
        themes.forEach { array.put(toJson(it)) }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private fun toJson(theme: SavedTheme) = JSONObject().apply {
        put("id", theme.id)
        put("name", theme.name)
        put("logoText", theme.logoText)
        put("channelLogoUri", theme.channelLogoUri ?: JSONObject.NULL)
        put("watermarkLogoUri", theme.watermarkLogoUri ?: JSONObject.NULL)
        put("bannerText", theme.bannerText)
        put("liveLabel", theme.liveLabel)
        put("marqueeInterval", theme.marqueeInterval.name)
        put("style", JSONObject().apply {
            put("backgroundColor", theme.style.backgroundColor)
            put("backgroundImageUri", theme.style.backgroundImageUri ?: JSONObject.NULL)
            put("backgroundBlur", theme.style.backgroundBlur.toDouble())
            put("accentColor", theme.style.accentColor)
            put("secondaryColor", theme.style.secondaryColor)
            put("textColor", theme.style.textColor)
            put("borderColor", theme.style.borderColor)
            put("tickerBackgroundColor", theme.style.tickerBackgroundColor)
            put("fontFamily", theme.style.fontFamily.name)
            put("fontStyle", theme.style.fontStyle.name)
            put("headlineSize", theme.style.headlineSize.name)
            put("sponsorColumns", theme.style.sponsorColumns)
            put("sponsorMarqueeEnabled", theme.style.sponsorMarqueeEnabled)
            put("sponsorMarqueeInterval", theme.style.sponsorMarqueeInterval.name)
        })
        put("textStyles", JSONObject().apply {
            theme.textStyles.forEach { (target, textStyle) ->
                put(target.name, JSONObject().apply {
                    put("textColor", textStyle.textColor)
                    put("backgroundColor", textStyle.backgroundColor)
                    put("backgroundEnabled", textStyle.backgroundEnabled)
                    put("fontFamily", textStyle.fontFamily.name)
                    put("fontStyle", textStyle.fontStyle.name)
                    put("sizeScale", textStyle.sizeScale.toDouble())
                    put("alignment", textStyle.alignment.name)
                })
            }
        })
    }

    private fun fromJson(json: JSONObject): SavedTheme {
        val styleJson = json.getJSONObject("style")
        val style = TemplateStyle(
            backgroundColor = styleJson.optInt("backgroundColor", TemplateStyle().backgroundColor),
            backgroundImageUri = styleJson.optString("backgroundImageUri").takeIf { it.isNotBlank() && it != "null" },
            backgroundBlur = styleJson.optDouble("backgroundBlur", 0.0).toFloat(),
            accentColor = styleJson.optInt("accentColor", TemplateStyle().accentColor),
            secondaryColor = styleJson.optInt("secondaryColor", TemplateStyle().secondaryColor),
            textColor = styleJson.optInt("textColor", TemplateStyle().textColor),
            borderColor = styleJson.optInt("borderColor", TemplateStyle().borderColor),
            tickerBackgroundColor = styleJson.optInt("tickerBackgroundColor", TemplateStyle().tickerBackgroundColor),
            fontFamily = runCatching { FontFamilyOption.valueOf(styleJson.optString("fontFamily", FontFamilyOption.SANS.name)) }.getOrDefault(FontFamilyOption.SANS),
            fontStyle = runCatching { FontStyleOption.valueOf(styleJson.optString("fontStyle", FontStyleOption.BOLD.name)) }.getOrDefault(FontStyleOption.BOLD),
            headlineSize = runCatching { HeadlineSizeOption.valueOf(styleJson.optString("headlineSize", HeadlineSizeOption.MEDIUM.name)) }.getOrDefault(HeadlineSizeOption.MEDIUM),
            sponsorColumns = styleJson.optInt("sponsorColumns", 3).coerceIn(1, 6),
            sponsorMarqueeEnabled = styleJson.optBoolean("sponsorMarqueeEnabled", false),
            sponsorMarqueeInterval = runCatching {
                MarqueeIntervalOption.valueOf(styleJson.optString("sponsorMarqueeInterval", MarqueeIntervalOption.NORMAL.name))
            }.getOrDefault(MarqueeIntervalOption.NORMAL)
        )

        val defaults = defaultTextStyles().toMutableMap()
        val stylesJson = json.optJSONObject("textStyles")
        if (stylesJson != null) {
            TextTarget.entries.forEach { target ->
                val t = stylesJson.optJSONObject(target.name) ?: return@forEach
                defaults[target] = TextBoxStyle(
                    textColor = t.optInt("textColor", defaultTextStyle(target).textColor),
                    backgroundColor = t.optInt("backgroundColor", defaultTextStyle(target).backgroundColor),
                    backgroundEnabled = t.optBoolean("backgroundEnabled", defaultTextStyle(target).backgroundEnabled),
                    fontFamily = runCatching { FontFamilyOption.valueOf(t.optString("fontFamily", defaultTextStyle(target).fontFamily.name)) }.getOrDefault(defaultTextStyle(target).fontFamily),
                    fontStyle = runCatching { FontStyleOption.valueOf(t.optString("fontStyle", defaultTextStyle(target).fontStyle.name)) }.getOrDefault(defaultTextStyle(target).fontStyle),
                    sizeScale = t.optDouble("sizeScale", defaultTextStyle(target).sizeScale.toDouble()).toFloat(),
                    alignment = runCatching { TextAlignmentOption.valueOf(t.optString("alignment", defaultTextStyle(target).alignment.name)) }.getOrDefault(defaultTextStyle(target).alignment)
                )
            }
        }

        return SavedTheme(
            id = json.getString("id"),
            name = json.getString("name"),
            style = style,
            textStyles = defaults,
            logoText = json.optString("logoText", "CLIPORA"),
            channelLogoUri = json.optString("channelLogoUri").takeIf { it.isNotBlank() && it != "null" },
            watermarkLogoUri = json.optString("watermarkLogoUri").takeIf { it.isNotBlank() && it != "null" },
            bannerText = json.optString("bannerText", "BREAKING NEWS"),
            liveLabel = json.optString("liveLabel", "LIVE"),
            marqueeInterval = runCatching {
                MarqueeIntervalOption.valueOf(json.optString("marqueeInterval", MarqueeIntervalOption.NORMAL.name))
            }.getOrDefault(MarqueeIntervalOption.NORMAL)
        )
    }

    companion object { private const val KEY = "saved_themes" }
}
