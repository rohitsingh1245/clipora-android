package com.clipora.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.net.Uri
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.clipora.app.R
import com.clipora.app.editor.EditorViewModel
import com.clipora.app.export.ImageExportManager
import com.clipora.app.export.VideoExportManager
import com.clipora.app.media.NewsLayoutMetrics
import com.clipora.app.model.*
import com.clipora.app.storage.ThemeRepository
import kotlin.math.roundToLong

private enum class Screen { HOME, VIDEO, IMAGE, THEMES, PROJECTS }

@Composable
fun CliporaApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    when (screen) {
        Screen.HOME -> HomeScreen(
            onVideo = { screen = Screen.VIDEO },
            onImage = { screen = Screen.IMAGE },
            onThemes = { screen = Screen.THEMES },
            onProjects = { screen = Screen.PROJECTS }
        )
        Screen.VIDEO -> VideoEditorScreen(onBack = { screen = Screen.HOME })
        Screen.IMAGE -> ImageEditorScreen(onBack = { screen = Screen.HOME })
        Screen.THEMES -> SavedThemesScreen(onBack = { screen = Screen.HOME })
        Screen.PROJECTS -> SimpleListScreen(
            "My Projects",
            listOf("Project/draft persistence is planned after the V2 template editor is stable.")
        ) { screen = Screen.HOME }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(onVideo: () -> Unit, onImage: () -> Unit, onThemes: () -> Unit, onProjects: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(
                    painter = painterResource(R.drawable.clipora_app_icon),
                    contentDescription = "Clipora",
                    modifier = Modifier.size(34.dp)
                )
                Text("Clipora")
            }
        })
    }) { padding ->
        Column(
            Modifier.padding(padding).padding(20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.clipora_wordmark),
                contentDescription = "Clipora logo",
                modifier = Modifier.fillMaxWidth().heightIn(max = 96.dp)
            )
            Text("Create reusable layered news layouts, videos and images.", style = MaterialTheme.typography.titleMedium)
            ActionCard("Create Video", "Layered news editor + MP4 Gallery export", onVideo)
            ActionCard("Create Image", "Use the same template and export to Gallery", onImage)
            ActionCard("My Themes", "Saved reusable styles", onThemes)
            ActionCard("My Projects", "Saved projects", onProjects)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, action: () -> Unit) {
    Card(onClick = action, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun VideoEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setMediaUri(it.toString())
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("News video editor") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }) {
                Text(if (state.mediaUri == null) "Import video" else "Change video")
            }

            VideoPreview(state, vm::setSourceDuration)
            EditorControls(state, vm)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting MP4 to Gallery…")
                    VideoExportManager(context).export(state) { result ->
                        vm.setExportStatus(result.fold(
                            { "Saved to Gallery: Movies/Clipora/Videos" },
                            { "Export failed: ${it.message ?: "unknown error"}" }
                        ))
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export MP4 to Gallery") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPreview(state: EditorState, onDuration: (Long) -> Unit) {
    val context = LocalContext.current
    val uri = state.mediaUri
    Box(
        Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color.Black)
    ) {
        if (uri == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Import video to preview", color = Color.White)
            }
        } else {
            val player = remember(uri, state.aspectRatio, state.videoScaleMode, state.mediaRevision) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
                    val layout = when (state.videoScaleMode) {
                        VideoScaleMode.FIT -> Presentation.LAYOUT_SCALE_TO_FIT
                        VideoScaleMode.FILL -> Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                    }
                    setVideoEffects(listOf(
                        Presentation.createForAspectRatio(state.aspectRatio.ratio, layout)
                    ))
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(playbackState: Int) {
                            if (playbackState == Player.STATE_READY && duration > 0L) {
                                onDuration(duration)
                            }
                        }
                    })
                    prepare()
                    playWhenReady = true
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply {
                    this.player = player
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                } },
                update = { view ->
                    view.player = player
                    view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                },
                modifier = Modifier.fillMaxSize()
            )
        }
        NewsTemplateOverlay(state)
    }
}

@Composable
private fun NewsTemplateOverlay(state: EditorState) {
    val background = Color(state.style.backgroundColor)

    Column(Modifier.fillMaxSize()) {
        // Header: location + channel branding.
        BackgroundBox(
            style = state.style,
            modifier = Modifier.fillMaxWidth().weight(NewsLayoutMetrics.HEADER)
        ) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StyledText(
                    text = state.location,
                    style = state.textStyle(TextTarget.LOCATION),
                    modifier = Modifier.widthIn(min = 72.dp, max = 132.dp),
                    baseSp = 11f,
                    maxLines = 1
                )
                if (!state.channelLogoUri.isNullOrBlank()) {
                    UriImage(state.channelLogoUri, Modifier.width(82.dp).fillMaxHeight())
                } else {
                    StyledText(
                        text = state.logoText,
                        style = state.textStyle(TextTarget.CHANNEL),
                        modifier = Modifier.widthIn(min = 82.dp, max = 145.dp),
                        baseSp = 12f,
                        maxLines = 1
                    )
                }
            }
        }

        // Plain headline: no forced border/outline.
        BackgroundBox(
            style = state.style,
            modifier = Modifier.fillMaxWidth().weight(NewsLayoutMetrics.HEADLINE)
        ) {
            StyledText(
                text = state.headline,
                style = state.textStyle(TextTarget.HEADLINE),
                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 3.dp),
                baseSp = 18f,
                maxLines = 3
            )
        }

        // Inset video frame. Breaking News is a popup text overlay, not a row.
        Box(Modifier.fillMaxWidth().weight(NewsLayoutMetrics.MEDIA)) {
            Row(Modifier.fillMaxSize()) {
                BackgroundBox(state.style, Modifier.fillMaxHeight().weight(NewsLayoutMetrics.MEDIA_SIDE_INSET)) {}
                Box(
                    Modifier.fillMaxHeight().weight(1f - NewsLayoutMetrics.MEDIA_SIDE_INSET * 2f)
                        .border(1.dp, Color(state.style.borderColor))
                )
                BackgroundBox(state.style, Modifier.fillMaxHeight().weight(NewsLayoutMetrics.MEDIA_SIDE_INSET)) {}
            }

            StyledText(
                text = state.bannerText,
                style = state.textStyle(TextTarget.BREAKING),
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth(.68f).padding(top = 4.dp),
                baseSp = 17f,
                maxLines = 1
            )

            if (!state.watermarkLogoUri.isNullOrBlank()) {
                UriImage(
                    state.watermarkLogoUri,
                    Modifier.align(Alignment.TopEnd)
                        .padding(top = 38.dp, end = 22.dp)
                        .size(width = 74.dp, height = 34.dp)
                )
            }
        }

        // One white advertisement banner: large shop name, compact sponsor strip, contact line.
        Column(
            Modifier.fillMaxWidth().weight(NewsLayoutMetrics.AD)
                .background(Color.White)
                .border(1.dp, Color(0xFF222222))
        ) {
            Box(
                Modifier.fillMaxWidth().weight(NewsLayoutMetrics.AD_TITLE).padding(horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                StyledText(
                    text = state.advertiserName,
                    style = state.textStyle(TextTarget.ADVERTISER),
                    modifier = Modifier.fillMaxWidth(),
                    baseSp = 18f,
                    maxLines = 2
                )
            }

            SponsorStrip(
                state = state,
                modifier = Modifier.fillMaxWidth().weight(NewsLayoutMetrics.AD_SPONSOR)
            )

            Box(
                Modifier.fillMaxWidth().weight(NewsLayoutMetrics.AD_CONTACT)
                    .border(width = 0.5.dp, color = Color(0xFF303030))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                StyledText(
                    text = state.contactText,
                    style = state.textStyle(TextTarget.CONTACT),
                    modifier = Modifier.fillMaxWidth(),
                    baseSp = 11f,
                    maxLines = 3
                )
            }
        }

        // Independent LIVE + ticker strip.
        NewsMarqueeRow(
            state = state,
            modifier = Modifier.fillMaxWidth().weight(NewsLayoutMetrics.TICKER)
        )
    }
}

@Composable
private fun BackgroundBox(
    style: TemplateStyle,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.background(Color(style.backgroundColor))) {
        val uri = style.backgroundImageUri
        if (!uri.isNullOrBlank()) {
            AndroidView(
                factory = { ctx ->
                    ImageView(ctx).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                    }
                },
                update = { view ->
                    view.setImageURI(Uri.parse(uri))
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val blur = style.backgroundBlur
                        view.setRenderEffect(
                            if (blur > 0.1f) RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP) else null
                        )
                    }
                },
                modifier = Modifier.matchParentSize()
            )
        }
        content()
    }
}

@Composable
private fun StyledText(
    text: String,
    style: TextBoxStyle,
    modifier: Modifier = Modifier,
    baseSp: Float,
    maxLines: Int
) {
    val fontFamily = when (style.fontFamily) {
        FontFamilyOption.SANS -> FontFamily.SansSerif
        FontFamilyOption.SERIF -> FontFamily.Serif
        FontFamilyOption.MONOSPACE -> FontFamily.Monospace
    }
    val fontWeight = when (style.fontStyle) {
        FontStyleOption.BOLD, FontStyleOption.BOLD_ITALIC -> FontWeight.Bold
        else -> FontWeight.Normal
    }
    val fontStyle = when (style.fontStyle) {
        FontStyleOption.ITALIC, FontStyleOption.BOLD_ITALIC -> FontStyle.Italic
        else -> FontStyle.Normal
    }
    val textAlign = when (style.alignment) {
        TextAlignmentOption.START -> TextAlign.Start
        TextAlignmentOption.CENTER -> TextAlign.Center
        TextAlignmentOption.END -> TextAlign.End
    }
    val alignment = when (style.alignment) {
        TextAlignmentOption.START -> Alignment.CenterStart
        TextAlignmentOption.CENTER -> Alignment.Center
        TextAlignmentOption.END -> Alignment.CenterEnd
    }
    val bgModifier = if (style.backgroundEnabled) {
        Modifier.background(Color(style.backgroundColor), RoundedCornerShape(5.dp)).padding(horizontal = 5.dp, vertical = 2.dp)
    } else Modifier

    Box(modifier.then(bgModifier), contentAlignment = alignment) {
        Text(
            text = text,
            color = Color(style.textColor),
            textAlign = textAlign,
            fontFamily = fontFamily,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            fontSize = (baseSp * style.sizeScale).sp,
            maxLines = maxLines,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SponsorStrip(state: EditorState, modifier: Modifier = Modifier) {
    val visible = state.sponsors.take(state.style.sponsorColumns.coerceIn(1, 6))
    Box(modifier.border(width = 0.5.dp, color = Color(0xFF303030)), contentAlignment = Alignment.CenterStart) {
        if (visible.isNotEmpty() && state.style.sponsorMarqueeEnabled) {
            Row(
                Modifier.fillMaxHeight().basicMarquee(iterations = Int.MAX_VALUE),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(2) {
                    visible.forEach { sponsor ->
                        SponsorCell(sponsor, state.textStyle(TextTarget.SPONSOR), Modifier.width(150.dp).fillMaxHeight())
                    }
                }
            }
        } else if (visible.isNotEmpty()) {
            Row(Modifier.fillMaxSize()) {
                visible.forEach { sponsor ->
                    SponsorCell(sponsor, state.textStyle(TextTarget.SPONSOR), Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun SponsorCell(sponsor: SponsorItem, textStyle: TextBoxStyle, modifier: Modifier) {
    Box(
        modifier.border(width = 0.35.dp, color = Color(0xFF404040)).padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        if (sponsor.kind == SponsorKind.LOGO && !sponsor.imageUri.isNullOrBlank()) {
            UriImage(sponsor.imageUri, Modifier.fillMaxSize())
        } else {
            StyledText(sponsor.text, textStyle, Modifier.fillMaxSize(), baseSp = 10f, maxLines = 2)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NewsMarqueeRow(state: EditorState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "live-blink")
    val liveAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(animation = tween(500), repeatMode = RepeatMode.Reverse),
        label = "live-alpha"
    )
    val activeItems = state.marqueeItems.map { it.text.trim() }.filter { it.isNotEmpty() }
    val gapSpaces = when (state.marqueeInterval) {
        MarqueeIntervalOption.SHORT -> 8
        MarqueeIntervalOption.NORMAL -> 16
        MarqueeIntervalOption.LONG -> 28
        MarqueeIntervalOption.EXTRA_LONG -> 40
    }
    val separator = " ".repeat(gapSpaces) + "•" + " ".repeat(gapSpaces)
    val marqueeText = activeItems.joinToString(separator).ifBlank { "Add a news line" }
    val liveStyle = state.textStyle(TextTarget.LIVE)
    val tickerStyle = state.textStyle(TextTarget.TICKER)

    Row(modifier.background(Color(state.style.tickerBackgroundColor))) {
        Box(
            Modifier.fillMaxHeight().width(64.dp)
                .background(Color(if (liveStyle.backgroundEnabled) liveStyle.backgroundColor else state.style.accentColor)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                state.liveLabel,
                color = Color(liveStyle.textColor),
                fontFamily = when (liveStyle.fontFamily) {
                    FontFamilyOption.SANS -> FontFamily.SansSerif
                    FontFamilyOption.SERIF -> FontFamily.Serif
                    FontFamilyOption.MONOSPACE -> FontFamily.Monospace
                },
                fontWeight = if (liveStyle.fontStyle == FontStyleOption.BOLD || liveStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontWeight.Black else FontWeight.Normal,
                fontStyle = if (liveStyle.fontStyle == FontStyleOption.ITALIC || liveStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontStyle.Italic else FontStyle.Normal,
                fontSize = (10f * liveStyle.sizeScale).sp,
                modifier = Modifier.alpha(liveAlpha)
            )
        }
        Box(Modifier.fillMaxSize().padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
            Text(
                marqueeText,
                color = Color(tickerStyle.textColor),
                fontFamily = when (tickerStyle.fontFamily) {
                    FontFamilyOption.SANS -> FontFamily.SansSerif
                    FontFamilyOption.SERIF -> FontFamily.Serif
                    FontFamilyOption.MONOSPACE -> FontFamily.Monospace
                },
                fontWeight = if (tickerStyle.fontStyle == FontStyleOption.BOLD || tickerStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (tickerStyle.fontStyle == FontStyleOption.ITALIC || tickerStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontStyle.Italic else FontStyle.Normal,
                fontSize = (10f * tickerStyle.sizeScale).sp,
                maxLines = 1,
                modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE)
            )
        }
    }
}

@Composable
private fun UriImage(uri: String?, modifier: Modifier = Modifier) {
    if (uri.isNullOrBlank()) return
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            adjustViewBounds = true
        } },
        update = { it.setImageURI(Uri.parse(uri)) },
        modifier = modifier
    )
}

@Composable
private fun EditorControls(state: EditorState, vm: EditorViewModel) {
    val context = LocalContext.current
    val repo = remember(context) { ThemeRepository(context) }
    var savedThemes by remember { mutableStateOf(repo.list()) }
    var selectedThemeId by remember { mutableStateOf<String?>(null) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var themeName by remember { mutableStateOf("") }
    var sponsorLogoTarget by remember { mutableStateOf<Int?>(null) }
    var selectedTextTarget by remember { mutableStateOf(TextTarget.HEADLINE) }

    val channelLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setChannelLogoUri(it.toString()) }
    }
    val watermarkPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setWatermarkLogoUri(it.toString()) }
    }
    val sponsorLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val id = sponsorLogoTarget
        if (id != null && uri != null) {
            persistReadPermission(context, uri)
            vm.setSponsorLogo(id, uri.toString())
        }
        sponsorLogoTarget = null
    }
    val backgroundImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setBackgroundImageUri(it.toString())
        }
    }

    SectionCard("Layout") {
        Text("Aspect ratio", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(AspectRatioOption.entries, state.aspectRatio, { it.label }, vm::setAspectRatio)
        Text("Video framing", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(VideoScaleMode.entries, state.videoScaleMode, { it.label }, vm::setVideoScaleMode)
        Text("Duration", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(DurationOption.entries, state.duration, { it.label }, vm::setDuration)
        Text("Template", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(ThemePreset.entries, state.theme, { it.title }, vm::setTheme)
        if (state.sourceDurationMs > 1_000L) {
            Text("Trim start: ${state.trimStartMs / 1000}s")
            Slider(
                value = state.trimStartMs.toFloat(),
                onValueChange = { vm.setTrimStart(it.roundToLong()) },
                valueRange = 0f..(state.sourceDurationMs - 1_000L).toFloat()
            )
        }
    }

    SectionCard("News layout content") {
        OutlinedTextField(state.location, vm::setLocation, label = { Text("1. Location") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.logoText, vm::setLogoText, label = { Text("1. Channel name / logo text") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { channelLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Channel logo") }
            OutlinedButton(onClick = { watermarkPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Watermark") }
        }
        OutlinedTextField(state.headline, vm::setHeadline, label = { Text("2. Main headline") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.bannerText, vm::setBannerText, label = { Text("Breaking / Exclusive overlay") }, modifier = Modifier.fillMaxWidth())
        Text("Media is shown inside an inset frame; Breaking/Exclusive floats over it.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(state.advertiserName, vm::setAdvertiserName, label = { Text("Advertisement: shop / advertiser name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.contactText, vm::setContactText, label = { Text("Advertisement: address / contact") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            state.liveLabel,
            vm::setLiveLabel,
            label = { Text("Bottom ticker: LIVE label") },
            modifier = Modifier.fillMaxWidth()
        )
        Text("Bottom ticker: marquee news lines", style = MaterialTheme.typography.titleSmall)
        Text("Add several news lines. They scroll continuously one after another with the selected gap.", style = MaterialTheme.typography.bodySmall)
        state.marqueeItems.forEachIndexed { index, item ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = item.text,
                    onValueChange = { vm.setMarqueeText(item.id, it) },
                    label = { Text("News ${index + 1}") },
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = { vm.removeMarqueeLine(item.id) },
                    enabled = state.marqueeItems.size > 1
                ) { Text("Remove") }
            }
        }
        Button(onClick = vm::addMarqueeLine, enabled = state.marqueeItems.size < 10) { Text("+ Add news line") }
        Text("Gap between news lines", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(MarqueeIntervalOption.entries, state.marqueeInterval, { it.label }, vm::setMarqueeInterval)
    }

    SectionCard("Advertisement banner / sponsors") {
        Text("This is a compact banner strip. One item becomes a full-width banner; multiple items become columns.", style = MaterialTheme.typography.bodySmall)
        Text("Columns / visible items", style = MaterialTheme.typography.titleSmall)
        ChoiceRow((1..6).toList(), state.style.sponsorColumns, { it.toString() }, vm::setSponsorColumns)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::addSponsorText, enabled = state.sponsors.size < 6) { Text("+ Text") }
            Button(onClick = vm::addSponsorLogo, enabled = state.sponsors.size < 6) { Text("+ Logo / banner") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = state.style.sponsorMarqueeEnabled, onCheckedChange = vm::setSponsorMarqueeEnabled)
            Text("Move sponsor/logo strip like a marquee")
        }
        if (state.style.sponsorMarqueeEnabled) {
            Text("Gap between sponsor items", style = MaterialTheme.typography.titleSmall)
            ChoiceRow(MarqueeIntervalOption.entries, state.style.sponsorMarqueeInterval, { it.label }, vm::setSponsorMarqueeInterval)
        }
        state.sponsors.forEachIndexed { index, sponsor ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Banner item ${index + 1}", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(
                        sponsor.text,
                        { vm.setSponsorText(sponsor.id, it) },
                        label = { Text(if (sponsor.kind == SponsorKind.LOGO) "Logo label / fallback" else "Text") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (sponsor.kind == SponsorKind.LOGO) {
                            OutlinedButton(onClick = {
                                sponsorLogoTarget = sponsor.id
                                sponsorLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) { Text(if (sponsor.imageUri == null) "Choose image" else "Change image") }
                        }
                        TextButton(onClick = { vm.removeSponsor(sponsor.id) }) { Text("Remove") }
                    }
                }
            }
        }
    }

    SectionCard("Canvas background") {
        Text("Use any solid colour or choose an image. Image blur is saved with the theme.", style = MaterialTheme.typography.bodySmall)
        HexColorControl("Background colour", state.style.backgroundColor, vm::setBackgroundColor)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                backgroundImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text(if (state.style.backgroundImageUri == null) "Choose background image" else "Change background image") }
            if (state.style.backgroundImageUri != null) {
                TextButton(onClick = { vm.setBackgroundImageUri(null) }) { Text("Remove image") }
            }
        }
        if (state.style.backgroundImageUri != null) {
            Text("Background blur: ${state.style.backgroundBlur.toInt()}")
            Slider(
                value = state.style.backgroundBlur,
                onValueChange = vm::setBackgroundBlur,
                valueRange = 0f..30f
            )
        }
    }

    SectionCard("Style every text box") {
        Text("Choose a text box, then set its own colour, font, size, alignment and optional background.", style = MaterialTheme.typography.bodySmall)
        ChoiceRow(TextTarget.entries, selectedTextTarget, { it.label }) { selectedTextTarget = it }
        val selectedStyle = state.textStyle(selectedTextTarget)
        HexColorControl("Text colour", selectedStyle.textColor) { vm.setTextBoxTextColor(selectedTextTarget, it) }
        Text("Font family", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(FontFamilyOption.entries, selectedStyle.fontFamily, { it.label }) { vm.setTextBoxFontFamily(selectedTextTarget, it) }
        Text("Font style", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(FontStyleOption.entries, selectedStyle.fontStyle, { it.label }) { vm.setTextBoxFontStyle(selectedTextTarget, it) }
        Text("Font size: ${(selectedStyle.sizeScale * 100).toInt()}%")
        Slider(
            value = selectedStyle.sizeScale,
            onValueChange = { vm.setTextBoxSizeScale(selectedTextTarget, it) },
            valueRange = 0.55f..2.0f
        )
        Text("Alignment", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(TextAlignmentOption.entries, selectedStyle.alignment, { it.label }) { vm.setTextBoxAlignment(selectedTextTarget, it) }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(
                checked = selectedStyle.backgroundEnabled,
                onCheckedChange = { vm.setTextBoxBackgroundEnabled(selectedTextTarget, it) }
            )
            Text("Use background behind this text")
        }
        if (selectedStyle.backgroundEnabled) {
            HexColorControl("Text background colour", selectedStyle.backgroundColor) {
                vm.setTextBoxBackgroundColor(selectedTextTarget, it)
            }
        } else if (selectedTextTarget == TextTarget.BREAKING) {
            Text("Breaking News background is transparent.", style = MaterialTheme.typography.bodySmall)
        }
    }

    SectionCard("Theme colours") {
        HexColorControl("Accent / LIVE colour", state.style.accentColor, vm::setAccentColor)
        HexColorControl("Bottom ticker background", state.style.tickerBackgroundColor, vm::setTickerColor)
    }

    SectionCard("Saved themes") {
        if (savedThemes.isEmpty()) {
            Text("No saved themes yet.", style = MaterialTheme.typography.bodySmall)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(savedThemes) { theme ->
                    FilterChip(
                        selected = selectedThemeId == theme.id,
                        onClick = {
                            selectedThemeId = theme.id
                            vm.applySavedTheme(theme)
                        },
                        label = { Text(theme.name) }
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { themeName = ""; showSaveDialog = true }) { Text("Save as new") }
            OutlinedButton(
                enabled = selectedThemeId != null,
                onClick = {
                    val id = selectedThemeId
                    val old = savedThemes.firstOrNull { it.id == id }
                    if (id != null && old != null) {
                        repo.save(savedThemeFromState(state, id, old.name))
                        savedThemes = repo.list()
                    }
                }
            ) { Text("Update selected") }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save this design as a theme?") },
            text = {
                OutlinedTextField(themeName, { themeName = it }, label = { Text("Theme name") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = themeName.trim().ifBlank { "My News Theme" }
                    val id = "theme_${System.currentTimeMillis()}"
                    repo.save(savedThemeFromState(state, id, name))
                    savedThemes = repo.list()
                    selectedThemeId = id
                    showSaveDialog = false
                }) { Text("Save Theme") }
            },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Not Now") } }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun ColorPickerRow(label: String, selected: Int, onSelect: (Int) -> Unit, values: List<Int>) {
    Text(label, style = MaterialTheme.typography.titleSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        values.forEach { value ->
            Box(
                Modifier.size(34.dp).background(Color(value), RoundedCornerShape(17.dp))
                    .border(if (selected == value) 3.dp else 1.dp, if (selected == value) MaterialTheme.colorScheme.primary else Color.Gray,
                        RoundedCornerShape(17.dp))
                    .clickable { onSelect(value) }
            )
        }
    }
}

@Composable
private fun HexColorControl(label: String, color: Int, onColor: (Int) -> Unit) {
    var text by remember(color) { mutableStateOf(String.format("#%08X", color)) }
    OutlinedTextField(
        value = text,
        onValueChange = { value ->
            text = value
            parseColorOrNull(value)?.let(onColor)
        },
        label = { Text(label) },
        singleLine = true,
        leadingIcon = {
            Box(
                Modifier.size(22.dp)
                    .background(Color(color), RoundedCornerShape(11.dp))
                    .border(1.dp, Color.Gray, RoundedCornerShape(11.dp))
            )
        },
        supportingText = { Text("Use #RRGGBB or #AARRGGBB") },
        modifier = Modifier.fillMaxWidth()
    )
}

private fun parseColorOrNull(value: String): Int? = runCatching {
    android.graphics.Color.parseColor(value.trim())
}.getOrNull()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImageEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel(key = "image-editor")) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setMediaUri(it.toString())
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("News image editor") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Text(if (state.mediaUri == null) "Import image" else "Change image")
            }

            Box(Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color.Black)) {
                state.mediaUri?.let { value ->
                    AndroidView(
                        factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
                        update = { it.setImageURI(Uri.parse(value)) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                NewsTemplateOverlay(state)
            }

            EditorControls(state, vm)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting JPG to Gallery…")
                    val result = ImageExportManager(context).export(state)
                    vm.setExportStatus(result.fold(
                        { "Saved to Gallery: Pictures/Clipora/Images" },
                        { "Export failed: ${it.message ?: "unknown error"}" }
                    ))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export JPG to Gallery") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SavedThemesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember(context) { ThemeRepository(context) }
    var themes by remember { mutableStateOf(repo.list()) }
    var renameTheme by remember { mutableStateOf<SavedTheme?>(null) }
    var renameText by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("My Themes") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (themes.isEmpty()) Text("Save a theme from the editor and it will appear here.")
            themes.forEach { theme ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(theme.name, style = MaterialTheme.typography.titleMedium)
                        Text("${theme.style.fontFamily.label} • ${theme.style.fontStyle.label} • ${theme.style.sponsorColumns} sponsor columns • ${theme.marqueeInterval.label} ticker gap",
                            style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { renameTheme = theme; renameText = theme.name }) { Text("Rename") }
                            TextButton(onClick = {
                                val copy = theme.copy(id = "theme_${System.currentTimeMillis()}", name = "${theme.name} Copy")
                                repo.save(copy); themes = repo.list()
                            }) { Text("Duplicate") }
                            TextButton(onClick = { repo.delete(theme.id); themes = repo.list() }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    renameTheme?.let { theme ->
        AlertDialog(
            onDismissRequest = { renameTheme = null },
            title = { Text("Rename theme") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    repo.save(theme.copy(name = renameText.trim().ifBlank { theme.name }))
                    themes = repo.list(); renameTheme = null
                }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameTheme = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun <T> ChoiceRow(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(values) { value ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label(value)) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleListScreen(title: String, lines: List<String>, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            lines.forEach { Text(it) }
        }
    }
}

private fun savedThemeFromState(state: EditorState, id: String, name: String) = SavedTheme(
    id = id,
    name = name,
    style = state.style,
    textStyles = state.textStyles,
    logoText = state.logoText,
    channelLogoUri = state.channelLogoUri,
    watermarkLogoUri = state.watermarkLogoUri,
    bannerText = state.bannerText,
    liveLabel = state.liveLabel,
    marqueeInterval = state.marqueeInterval
)

private fun persistReadPermission(context: Context, uri: Uri) {
    runCatching {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}
