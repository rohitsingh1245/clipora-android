package com.clipora.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.clipora.app.R
import com.clipora.app.editor.EditorViewModel
import com.clipora.app.export.ImageExportManager
import com.clipora.app.export.VideoExportManager
import com.clipora.app.model.*
import com.clipora.app.storage.ThemeRepository
import kotlin.math.roundToLong

private enum class Screen { HOME, VIDEO, IMAGE, THEMES, PROJECTS }

@Composable
fun CliporaApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    when (screen) {
        Screen.HOME -> HomeScreen(
            onVideo = { screen = Screen.VIDEO },
            onImage = { screen = Screen.IMAGE },
            onThemes = { screen = Screen.THEMES },
            onProjects = { screen = Screen.PROJECTS }
        )
        Screen.VIDEO -> VideoEditorScreen(onBack = { screen = Screen.HOME })
        Screen.IMAGE -> ImageEditorScreen(onBack = { screen = Screen.HOME })
        Screen.THEMES -> SavedThemesScreen(onBack = { screen = Screen.HOME })
        Screen.PROJECTS -> SimpleListScreen(
            "My Projects",
            listOf("Project/draft persistence is planned after the V2 template editor is stable.")
        ) { screen = Screen.HOME }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(onVideo: () -> Unit, onImage: () -> Unit, onThemes: () -> Unit, onProjects: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(
                    painter = painterResource(R.drawable.clipora_app_icon),
                    contentDescription = "Clipora",
                    modifier = Modifier.size(34.dp)
                )
                Text("Clipora")
            }
        })
    }) { padding ->
        Column(
            Modifier.padding(padding).padding(20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.clipora_wordmark),
                contentDescription = "Clipora logo",
                modifier = Modifier.fillMaxWidth().heightIn(max = 96.dp)
            )
            Text("Create reusable news layouts, videos and images.", style = MaterialTheme.typography.titleMedium)
            ActionCard("Create Video", "8-row news editor + MP4 Gallery export", onVideo)
            ActionCard("Create Image", "Use the same template and export to Gallery", onImage)
            ActionCard("My Themes", "Saved reusable styles", onThemes)
            ActionCard("My Projects", "Saved projects", onProjects)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, action: () -> Unit) {
    Card(onClick = action, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun VideoEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setMediaUri(it.toString())
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("News video editor") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }) {
                Text(if (state.mediaUri == null) "Import video" else "Change video")
            }

            VideoPreview(state, vm::setSourceDuration)
            EditorControls(state, vm)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting MP4 to Gallery…")
                    VideoExportManager(context).export(state) { result ->
                        vm.setExportStatus(result.fold(
                            { "Saved to Gallery: Movies/Clipora/Videos" },
                            { "Export failed: ${it.message ?: "unknown error"}" }
                        ))
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export MP4 to Gallery") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPreview(state: EditorState, onDuration: (Long) -> Unit) {
    val context = LocalContext.current
    val uri = state.mediaUri
    Box(
        Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color.Black)
    ) {
        if (uri == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Import video to preview", color = Color.White)
            }
        } else {
            val player = remember(uri, state.aspectRatio) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
                    setVideoEffects(listOf(
                        Presentation.createForAspectRatio(state.aspectRatio.ratio, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
                    ))
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(playbackState: Int) {
                            if (playbackState == Player.STATE_READY && duration > 0L) onDuration(duration)
                        }
                    })
                    prepare()
                    playWhenReady = true
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxSize())
        }
        NewsTemplateOverlay(state)
    }
}

@Composable
private fun NewsTemplateOverlay(state: EditorState) {
    val style = state.style
    val fontFamily = when (style.fontFamily) {
        FontFamilyOption.SANS -> FontFamily.SansSerif
        FontFamilyOption.SERIF -> FontFamily.Serif
        FontFamilyOption.MONOSPACE -> FontFamily.Monospace
    }
    val fontWeight = when (style.fontStyle) {
        FontStyleOption.BOLD, FontStyleOption.BOLD_ITALIC -> FontWeight.Bold
        else -> FontWeight.Normal
    }
    val fontStyle = when (style.fontStyle) {
        FontStyleOption.ITALIC, FontStyleOption.BOLD_ITALIC -> FontStyle.Italic
        else -> FontStyle.Normal
    }
    val textColor = Color(style.textColor)
    val background = Color(style.backgroundColor)
    val accent = Color(style.accentColor)
    val secondary = Color(style.secondaryColor)

    Column(Modifier.fillMaxSize()) {
        // 1. Location + channel logo
        Row(
            Modifier.fillMaxWidth().weight(.08f).background(background).padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                state.location,
                color = Color.White,
                modifier = Modifier.background(accent, RoundedCornerShape(5.dp)).padding(horizontal = 7.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelSmall
            )
            if (!state.channelLogoUri.isNullOrBlank()) {
                UriImage(state.channelLogoUri, Modifier.width(76.dp).fillMaxHeight())
            } else {
                Text(state.logoText, color = textColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            }
        }

        // 2. Main headline
        Box(
            Modifier.fillMaxWidth().weight(.13f).background(background)
                .border(1.dp, Color(style.borderColor)).padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                state.headline,
                color = textColor,
                textAlign = TextAlign.Center,
                fontFamily = fontFamily,
                fontWeight = fontWeight,
                fontStyle = fontStyle,
                style = when (style.headlineSize) {
                    HeadlineSizeOption.SMALL -> MaterialTheme.typography.titleSmall
                    HeadlineSizeOption.MEDIUM -> MaterialTheme.typography.titleMedium
                    HeadlineSizeOption.LARGE -> MaterialTheme.typography.titleLarge
                },
                maxLines = 3
            )
        }

        // 3. Breaking / Exclusive
        Box(
            Modifier.fillMaxWidth().weight(.06f).background(accent).padding(horizontal = 32.dp, vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                state.bannerText,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().background(secondary, RoundedCornerShape(6.dp)).padding(2.dp)
            )
        }

        // 4. Video / image area
        Box(Modifier.fillMaxWidth().weight(.43f).border(1.dp, Color(style.borderColor))) {
            if (!state.watermarkLogoUri.isNullOrBlank()) {
                UriImage(
                    state.watermarkLogoUri,
                    Modifier.align(Alignment.TopEnd).padding(7.dp).size(width = 74.dp, height = 34.dp)
                )
            }
        }

        // 5. Advertiser / shop name
        Box(
            Modifier.fillMaxWidth().weight(.07f).background(background).padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(state.advertiserName, color = textColor, fontFamily = fontFamily, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 2, style = MaterialTheme.typography.labelLarge)
        }

        // 6. Dynamic sponsor columns
        Row(Modifier.fillMaxWidth().weight(.11f).background(Color.White)) {
            val visible = state.sponsors.take(style.sponsorColumns.coerceIn(1, 6))
            visible.forEachIndexed { index, sponsor ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().border(1.dp, Color(style.borderColor))
                        .background(if (index == 0) secondary else Color.White).padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (sponsor.kind == SponsorKind.LOGO && !sponsor.imageUri.isNullOrBlank()) {
                        UriImage(sponsor.imageUri, Modifier.fillMaxSize())
                    } else {
                        Text(sponsor.text, color = Color(0xFF202020), textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, maxLines = 3)
                    }
                }
            }
        }

        // 7. Address / contact
        Box(
            Modifier.fillMaxWidth().weight(.06f).background(background).padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(state.contactText, color = textColor, textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelSmall, maxLines = 2)
        }

        // 8. LIVE + ticker
        Row(Modifier.fillMaxWidth().weight(.06f).background(Color(style.tickerBackgroundColor))) {
            Box(Modifier.fillMaxHeight().width(64.dp).background(accent), contentAlignment = Alignment.Center) {
                Text(state.liveLabel, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
            }
            Box(Modifier.fillMaxSize().padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
                Text(state.ticker, color = textColor, maxLines = 1, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun UriImage(uri: String?, modifier: Modifier = Modifier) {
    if (uri.isNullOrBlank()) return
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            adjustViewBounds = true
        } },
        update = { it.setImageURI(Uri.parse(uri)) },
        modifier = modifier
    )
}

@Composable
private fun EditorControls(state: EditorState, vm: EditorViewModel) {
    val context = LocalContext.current
    val repo = remember(context) { ThemeRepository(context) }
    var savedThemes by remember { mutableStateOf(repo.list()) }
    var selectedThemeId by remember { mutableStateOf<String?>(null) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var themeName by remember { mutableStateOf("") }
    var sponsorLogoTarget by remember { mutableStateOf<Int?>(null) }

    val channelLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setChannelLogoUri(it.toString()) }
    }
    val watermarkPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setWatermarkLogoUri(it.toString()) }
    }
    val sponsorLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val id = sponsorLogoTarget
        if (id != null && uri != null) {
            persistReadPermission(context, uri)
            vm.setSponsorLogo(id, uri.toString())
        }
        sponsorLogoTarget = null
    }

    SectionCard("Layout") {
        Text("Aspect ratio", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(AspectRatioOption.entries, state.aspectRatio, { it.label }, vm::setAspectRatio)
        Text("Duration", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(DurationOption.entries, state.duration, { it.label }, vm::setDuration)
        Text("Template", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(ThemePreset.entries, state.theme, { it.title }, vm::setTheme)
        if (state.sourceDurationMs > 1_000L) {
            Text("Trim start: ${state.trimStartMs / 1000}s")
            Slider(
                value = state.trimStartMs.toFloat(),
                onValueChange = { vm.setTrimStart(it.roundToLong()) },
                valueRange = 0f..(state.sourceDurationMs - 1_000L).toFloat()
            )
        }
    }

    SectionCard("8-row content") {
        OutlinedTextField(state.location, vm::setLocation, label = { Text("1. Location") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.logoText, vm::setLogoText, label = { Text("1. Channel name / logo text") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { channelLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Channel logo") }
            OutlinedButton(onClick = { watermarkPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Watermark") }
        }
        OutlinedTextField(state.headline, vm::setHeadline, label = { Text("2. Main headline") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.bannerText, vm::setBannerText, label = { Text("3. Breaking / Exclusive") }, modifier = Modifier.fillMaxWidth())
        Text("4. Media area uses your imported video/image", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(state.advertiserName, vm::setAdvertiserName, label = { Text("5. Advertiser / shop name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state.contactText, vm::setContactText, label = { Text("7. Address / contact") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(state.liveLabel, vm::setLiveLabel, label = { Text("8. LIVE label") }, modifier = Modifier.weight(1f))
            OutlinedTextField(state.ticker, vm::setTicker, label = { Text("8. Ticker") }, modifier = Modifier.weight(2f))
        }
    }

    SectionCard("6. Sponsor / advertisement columns") {
        Text("Add up to 6 logo or text columns.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::addSponsorText, enabled = state.sponsors.size < 6) { Text("+ Text") }
            Button(onClick = vm::addSponsorLogo, enabled = state.sponsors.size < 6) { Text("+ Logo") }
        }
        state.sponsors.forEachIndexed { index, sponsor ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Column ${index + 1}", style = MaterialTheme.typography.labelLarge)
                    OutlinedTextField(
                        sponsor.text,
                        { vm.setSponsorText(sponsor.id, it) },
                        label = { Text(if (sponsor.kind == SponsorKind.LOGO) "Logo label / fallback" else "Text") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (sponsor.kind == SponsorKind.LOGO) {
                            OutlinedButton(onClick = {
                                sponsorLogoTarget = sponsor.id
                                sponsorLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }) { Text(if (sponsor.imageUri == null) "Choose logo" else "Change logo") }
                        }
                        TextButton(onClick = { vm.removeSponsor(sponsor.id) }) { Text("Remove") }
                    }
                }
            }
        }
    }

    SectionCard("Theme style") {
        ColorPickerRow("Background", state.style.backgroundColor, vm::setBackgroundColor,
            listOf(0xFF0B2B59.toInt(), 0xFF151515.toInt(), 0xFF4A1436.toInt(), 0xFF173755.toInt(), 0xFF3C256B.toInt()))
        ColorPickerRow("Accent", state.style.accentColor, vm::setAccentColor,
            listOf(0xFFD71920.toInt(), 0xFF0066CC.toInt(), 0xFF00875A.toInt(), 0xFF7A3EB1.toInt(), 0xFFFF7A00.toInt()))
        ColorPickerRow("Font color", state.style.textColor, vm::setTextColor,
            listOf(0xFFFFFFFF.toInt(), 0xFFFFF2A6.toInt(), 0xFFB9E7FF.toInt(), 0xFFB6FFB8.toInt(), 0xFFFFD0D0.toInt()))
        Text("Font family", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(FontFamilyOption.entries, state.style.fontFamily, { it.label }, vm::setFontFamily)
        Text("Font style", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(FontStyleOption.entries, state.style.fontStyle, { it.label }, vm::setFontStyle)
        Text("Headline size", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(HeadlineSizeOption.entries, state.style.headlineSize, { it.label }, vm::setHeadlineSize)
    }

    SectionCard("Saved themes") {
        if (savedThemes.isEmpty()) {
            Text("No saved themes yet.", style = MaterialTheme.typography.bodySmall)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(savedThemes) { theme ->
                    FilterChip(
                        selected = selectedThemeId == theme.id,
                        onClick = {
                            selectedThemeId = theme.id
                            vm.applySavedTheme(theme)
                        },
                        label = { Text(theme.name) }
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { themeName = ""; showSaveDialog = true }) { Text("Save as new") }
            OutlinedButton(
                enabled = selectedThemeId != null,
                onClick = {
                    val id = selectedThemeId
                    val old = savedThemes.firstOrNull { it.id == id }
                    if (id != null && old != null) {
                        repo.save(savedThemeFromState(state, id, old.name))
                        savedThemes = repo.list()
                    }
                }
            ) { Text("Update selected") }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save this design as a theme?") },
            text = {
                OutlinedTextField(themeName, { themeName = it }, label = { Text("Theme name") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = themeName.trim().ifBlank { "My News Theme" }
                    val id = "theme_${System.currentTimeMillis()}"
                    repo.save(savedThemeFromState(state, id, name))
                    savedThemes = repo.list()
                    selectedThemeId = id
                    showSaveDialog = false
                }) { Text("Save Theme") }
            },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Not Now") } }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun ColorPickerRow(label: String, selected: Int, onSelect: (Int) -> Unit, values: List<Int>) {
    Text(label, style = MaterialTheme.typography.titleSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        values.forEach { value ->
            Box(
                Modifier.size(34.dp).background(Color(value), RoundedCornerShape(17.dp))
                    .border(if (selected == value) 3.dp else 1.dp, if (selected == value) MaterialTheme.colorScheme.primary else Color.Gray,
                        RoundedCornerShape(17.dp))
                    .clickable { onSelect(value) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImageEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel(key = "image-editor")) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setMediaUri(it.toString())
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("News image editor") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Text(if (state.mediaUri == null) "Import image" else "Change image")
            }

            Box(Modifier.fillMaxWidth().aspectRatio(state.aspectRatio.ratio).background(Color.Black)) {
                state.mediaUri?.let { value ->
                    AndroidView(
                        factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
                        update = { it.setImageURI(Uri.parse(value)) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                NewsTemplateOverlay(state)
            }

            EditorControls(state, vm)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting JPG to Gallery…")
                    val result = ImageExportManager(context).export(state)
                    vm.setExportStatus(result.fold(
                        { "Saved to Gallery: Pictures/Clipora/Images" },
                        { "Export failed: ${it.message ?: "unknown error"}" }
                    ))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export JPG to Gallery") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SavedThemesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember(context) { ThemeRepository(context) }
    var themes by remember { mutableStateOf(repo.list()) }
    var renameTheme by remember { mutableStateOf<SavedTheme?>(null) }
    var renameText by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("My Themes") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (themes.isEmpty()) Text("Save a theme from the editor and it will appear here.")
            themes.forEach { theme ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(theme.name, style = MaterialTheme.typography.titleMedium)
                        Text("${theme.style.fontFamily.label} • ${theme.style.fontStyle.label} • ${theme.style.sponsorColumns} sponsor columns",
                            style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { renameTheme = theme; renameText = theme.name }) { Text("Rename") }
                            TextButton(onClick = {
                                val copy = theme.copy(id = "theme_${System.currentTimeMillis()}", name = "${theme.name} Copy")
                                repo.save(copy); themes = repo.list()
                            }) { Text("Duplicate") }
                            TextButton(onClick = { repo.delete(theme.id); themes = repo.list() }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    renameTheme?.let { theme ->
        AlertDialog(
            onDismissRequest = { renameTheme = null },
            title = { Text("Rename theme") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    repo.save(theme.copy(name = renameText.trim().ifBlank { theme.name }))
                    themes = repo.list(); renameTheme = null
                }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameTheme = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun <T> ChoiceRow(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(values) { value ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label(value)) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleListScreen(title: String, lines: List<String>, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            lines.forEach { Text(it) }
        }
    }
}

private fun savedThemeFromState(state: EditorState, id: String, name: String) = SavedTheme(
    id = id,
    name = name,
    style = state.style,
    logoText = state.logoText,
    channelLogoUri = state.channelLogoUri,
    watermarkLogoUri = state.watermarkLogoUri,
    bannerText = state.bannerText,
    liveLabel = state.liveLabel
)

private fun persistReadPermission(context: Context, uri: Uri) {
    runCatching {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}
