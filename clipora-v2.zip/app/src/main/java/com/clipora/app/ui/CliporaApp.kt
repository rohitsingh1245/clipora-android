package com.clipora.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.net.Uri
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.clipora.app.R
import com.clipora.app.editor.EditorViewModel
import com.clipora.app.export.ImageExportManager
import com.clipora.app.export.VideoExportManager
import com.clipora.app.export.ThumbnailCaptureManager
import com.clipora.app.model.*
import com.clipora.app.storage.ThemeRepository
import kotlin.math.roundToLong
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Screen { HOME, VIDEO, IMAGE, THEMES, PROJECTS }

@Composable
fun CliporaApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    when (screen) {
        Screen.HOME -> HomeScreen(
            onVideo = { screen = Screen.VIDEO },
            onImage = { screen = Screen.IMAGE },
            onThemes = { screen = Screen.THEMES },
            onProjects = { screen = Screen.PROJECTS }
        )
        Screen.VIDEO -> VideoEditorScreen(onBack = { screen = Screen.HOME })
        Screen.IMAGE -> ImageEditorScreen(onBack = { screen = Screen.HOME })
        Screen.THEMES -> SavedThemesScreen(onBack = { screen = Screen.HOME })
        Screen.PROJECTS -> SimpleListScreen(
            "My Projects",
            listOf("Project/draft persistence is planned after the V2 template editor is stable.")
        ) { screen = Screen.HOME }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(onVideo: () -> Unit, onImage: () -> Unit, onThemes: () -> Unit, onProjects: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Image(
                    painter = painterResource(R.drawable.clipora_app_icon),
                    contentDescription = "Clipora",
                    modifier = Modifier.size(34.dp)
                )
                Text("Clipora")
            }
        })
    }) { padding ->
        Column(
            Modifier.padding(padding).padding(20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.clipora_wordmark),
                contentDescription = "Clipora logo",
                modifier = Modifier.fillMaxWidth().heightIn(max = 96.dp)
            )
            Text("Create reusable layered news layouts, videos and images.", style = MaterialTheme.typography.titleMedium)
            ActionCard("Create Video", "Layered news editor + MP4 Gallery export", onVideo)
            ActionCard("Create Image", "Use the same template and export to Gallery", onImage)
            ActionCard("My Themes", "Saved reusable styles", onThemes)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, action: () -> Unit) {
    Card(onClick = action, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun VideoEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var previewPositionMs by remember { mutableStateOf(0L) }
    var thumbnailStatus by remember { mutableStateOf<String?>(null) }
    var thumbnailBusy by remember { mutableStateOf(false) }
    var capturedThumbnailUri by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setMediaUri(it.toString())
            thumbnailStatus = null
            capturedThumbnailUri = null
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("News video editor") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AssetSelectionRow(
                selected = state.mediaUri != null,
                chooseLabel = if (state.mediaUri == null) "Import video" else "Change video",
                onChoose = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                onRemove = {
                    vm.removeMedia()
                    thumbnailStatus = null
                    capturedThumbnailUri = null
                }
            )

            VideoPreview(
                state = state,
                onDuration = vm::setSourceDuration,
                onPosition = { previewPositionMs = it }
            )

            if (state.mediaUri != null) {
                OutlinedButton(
                    enabled = !thumbnailBusy,
                    onClick = {
                        thumbnailBusy = true
                        thumbnailStatus = "Creating thumbnail…"
                        val selectedUri = requireNotNull(state.mediaUri)
                        val position = previewPositionMs
                        val duration = state.sourceDurationMs
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                ThumbnailCaptureManager.capture(
                                    context = context,
                                    mediaUri = selectedUri,
                                    positionMs = position,
                                    durationMs = duration
                                )
                            }
                            thumbnailBusy = false
                            thumbnailStatus = result.fold(
                                { savedUri ->
                                    capturedThumbnailUri = savedUri.toString()
                                    "✓ Thumbnail saved to Pictures/Clipora/Thumbnails"
                                },
                                { error ->
                                    capturedThumbnailUri = null
                                    "Thumbnail failed: ${error.message ?: "unknown error"}"
                                }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (thumbnailBusy) "Creating thumbnail…" else "Capture thumbnail from current frame")
                }

                if (thumbnailBusy) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                capturedThumbnailUri?.let { thumbUri ->
                    UriImage(
                        thumbUri,
                        Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )
                }

                thumbnailStatus?.let {
                    Text(
                        it,
                        color = if (it.startsWith("✓")) Color(0xFF2E7D32) else if (thumbnailBusy) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            EditorControls(state, vm, EditorMediaMode.VIDEO)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting MP4 to Gallery…")
                    vm.setExportProgress(0)
                    VideoExportManager(context).export(
                        state = state,
                        onProgress = { vm.setExportProgress(it) }
                    ) { result ->
                        vm.setExportStatus(result.fold(
                            { "Saved to Gallery: Movies/Clipora/Videos" },
                            { "Export failed: ${it.message ?: "unknown error"}" }
                        ))
                        if (result.isFailure) vm.setExportProgress(null)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export MP4 to Gallery") }

            state.exportProgress?.let { progress ->
                LinearProgressIndicator(
                    progress = progress / 100f,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("$progress% complete", style = MaterialTheme.typography.bodySmall)
            }
            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPreview(state: EditorState, onDuration: (Long) -> Unit, onPosition: (Long) -> Unit) {
    val context = LocalContext.current
    val uri = state.mediaUri
    val spec = remember(state.aspectRatio, state.layoutPreset) {
        NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset)
    }

    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .aspectRatio(state.aspectRatio.ratio)
            .background(Color(state.style.backgroundColor))
    ) {
        val canvasWidth = maxWidth
        val canvasHeight = maxHeight
        val rect = spec.videoRect

        // Canvas/theme background must sit BEHIND the PlayerView.
        BackgroundBox(state.style, Modifier.fillMaxSize()) {}

        if (uri == null) {
            Box(
                Modifier
                    .offset(x = canvasWidth * rect.left, y = canvasHeight * rect.top)
                    .width(canvasWidth * rect.width)
                    .height(canvasHeight * rect.height)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Text("Import video to preview", color = Color.White)
            }
        } else {
            val player = remember(uri, state.mediaRevision) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(playbackState: Int) {
                            if (playbackState == Player.STATE_READY && duration > 0L) {
                                onDuration(duration)
                            }
                        }

                        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                            android.util.Log.e("CliporaPreview", "Video preview playback failed", error)
                        }
                    })
                    prepare()
                    playWhenReady = true
                }
            }

            DisposableEffect(player) { onDispose { player.release() } }
            LaunchedEffect(player) {
                while (true) {
                    onPosition(player.currentPosition.coerceAtLeast(0L))
                    delay(250L)
                }
            }

            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = true
                    }
                },
                update = { view ->
                    view.player = player
                    view.resizeMode = when (state.videoScaleMode) {
                        VideoScaleMode.FIT -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        VideoScaleMode.FILL -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    }
                },
                modifier = Modifier
                    .offset(x = canvasWidth * rect.left, y = canvasHeight * rect.top)
                    .width(canvasWidth * rect.width)
                    .height(canvasHeight * rect.height)
            )
        }

        NewsTemplateOverlay(state)
    }
}

@Composable
private fun NewsTemplateOverlay(state: EditorState) {
    val spec = remember(state.aspectRatio, state.layoutPreset) {
        NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cw = maxWidth
        val ch = maxHeight

        StyledText(
            text = state.location,
            style = state.textStyle(TextTarget.LOCATION),
            modifier = Modifier.layoutRect(spec.locationRect, cw, ch),
            baseSp = 11f,
            maxLines = 1
        )

        if (!state.channelLogoUri.isNullOrBlank()) {
            UriImage(
                state.channelLogoUri,
                Modifier.layoutRect(spec.logoRect, cw, ch)
            )
        } else {
            StyledText(
                text = state.logoText,
                style = state.textStyle(TextTarget.CHANNEL),
                modifier = Modifier.layoutRect(spec.logoRect, cw, ch),
                baseSp = 12f,
                maxLines = 1
            )
        }

        spec.headlineRect?.let { rect ->
            RotatingHeadlineText(
                items = state.headlineItems,
                interval = state.headlineInterval,
                style = state.textStyle(TextTarget.HEADLINE),
                accentColor = state.style.accentColor,
                modifier = Modifier.layoutRect(rect, cw, ch),
                baseSp = if (state.aspectRatio == AspectRatioOption.LANDSCAPE) 14f else 18f,
                maxLines = 3
            )
        }

        // Real viewport border. The PlayerView/ImageView is placed behind this exact rectangle.
        Box(
            Modifier
                .layoutRect(spec.videoRect, cw, ch)
                .border(1.dp, Color(state.style.borderColor))
        )

        spec.breakingBadgeRect?.let { rect ->
            BreakingBadge(
                state = state,
                modifier = Modifier.layoutRect(rect, cw, ch)
            )
        }

        if (!state.watermarkLogoUri.isNullOrBlank()) {
            val wr = NormalizedRect(
                left = (spec.videoRect.right - spec.videoRect.width * .22f).coerceAtLeast(spec.videoRect.left),
                top = spec.videoRect.top + spec.videoRect.height * .03f,
                right = spec.videoRect.right - spec.videoRect.width * .02f,
                bottom = spec.videoRect.top + spec.videoRect.height * .14f
            )
            UriImage(state.watermarkLogoUri, Modifier.layoutRect(wr, cw, ch))
        }

        spec.rightPanelRect?.let { rect ->
            SidePanelPreview(
                state = state,
                preset = state.layoutPreset,
                isLeft = false,
                modifier = Modifier.layoutRect(rect, cw, ch)
            )
        }
        spec.leftPanelRect?.let { rect ->
            SidePanelPreview(
                state = state,
                preset = state.layoutPreset,
                isLeft = true,
                modifier = Modifier.layoutRect(rect, cw, ch)
            )
        }

        spec.bottomHeadlineRect?.let { rect ->
            RotatingHeadlineText(
                items = state.lowerHeadlineItems,
                interval = state.lowerHeadlineInterval,
                style = state.textStyle(TextTarget.BOTTOM_HEADLINE),
                accentColor = state.style.accentColor,
                modifier = Modifier.layoutRect(rect, cw, ch),
                baseSp = 13f,
                maxLines = 2
            )
        }

        spec.adRect?.let { rect ->
            AdvertisementBannerArea(
                state = state,
                modifier = Modifier.layoutRect(rect, cw, ch)
            )
        }

        NewsMarqueeRow(
            state = state,
            modifier = Modifier.layoutRect(spec.tickerRect, cw, ch)
        )
    }
}

@Composable
private fun RotatingHeadlineText(
    items: List<HeadlineItem>,
    interval: MarqueeIntervalOption,
    style: TextBoxStyle,
    accentColor: Int,
    modifier: Modifier,
    baseSp: Float,
    maxLines: Int
) {
    val messages = items.map { it.text.trim() }.filter { it.isNotEmpty() }
    var active by remember(messages) { mutableStateOf(0) }
    val pop = remember { Animatable(1f) }

    LaunchedEffect(messages, interval) {
        active = 0
        if (messages.size > 1) {
            while (true) {
                delay(interval.millis.coerceAtLeast(500L))
                active = (active + 1) % messages.size
            }
        }
    }

    LaunchedEffect(active) {
        pop.snapTo(.92f)
        pop.animateTo(1f, animationSpec = tween(260))
    }

    ProfessionalHeadlineStrap(
        text = messages.getOrNull(active).orEmpty(),
        style = style,
        accentColor = accentColor,
        modifier = modifier.graphicsLayer {
            scaleX = pop.value
            scaleY = pop.value
            translationY = (1f - pop.value) * 36f
            alpha = ((pop.value - .90f) / .10f).coerceIn(.25f, 1f)
        },
        baseSp = baseSp,
        maxLines = maxLines
    )
}

@Composable
private fun ProfessionalHeadlineStrap(
    text: String,
    style: TextBoxStyle,
    accentColor: Int,
    modifier: Modifier,
    baseSp: Float,
    maxLines: Int
) {
    val shape = RoundedCornerShape(7.dp)
    Box(
        modifier
            .shadow(7.dp, shape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF071A33),
                        Color(0xFF0B2748),
                        Color(accentColor).copy(alpha = .78f)
                    )
                ),
                shape
            )
            .border(1.dp, Color.White.copy(alpha = .30f), shape)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .width(8.dp)
                .background(Color(accentColor), RoundedCornerShape(topStart = 7.dp, bottomStart = 7.dp))
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Color.White.copy(alpha = .18f))
        )
        StyledText(
            text = text,
            style = style.copy(backgroundEnabled = false),
            modifier = Modifier.fillMaxSize().padding(start = 16.dp, end = 8.dp, top = 3.dp, bottom = 3.dp),
            baseSp = baseSp,
            maxLines = maxLines
        )
    }
}

@Composable
private fun SidePanelPreview(
    state: EditorState,
    preset: LayoutPreset,
    isLeft: Boolean,
    modifier: Modifier
) {
    val shape = RoundedCornerShape(7.dp)
    Box(
        modifier
            .shadow(6.dp, shape)
            .background(Color(0xFF06172B), shape)
            .border(1.dp, Color.White.copy(alpha = .40f), shape)
            .padding(3.dp),
        contentAlignment = Alignment.Center
    ) {
        when (preset) {
            LayoutPreset.LANDSCAPE_SIDE_TEXT -> {
                Column(Modifier.fillMaxSize()) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .weight(.13f)
                            .background(Color(state.style.accentColor)),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            "TOP STORY",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                    StyledText(
                        state.sidePanelText,
                        state.textStyle(TextTarget.SIDE_TEXT).copy(
                            textColor = 0xFFFFFFFF.toInt(),
                            backgroundEnabled = false,
                            alignment = TextAlignmentOption.START
                        ),
                        Modifier.fillMaxWidth().weight(.87f).padding(8.dp),
                        baseSp = 12f,
                        maxLines = 8
                    )
                }
            }

            LayoutPreset.LANDSCAPE_SIDE_IMAGE -> {
                if (!state.sidePanelImageUri.isNullOrBlank()) {
                    UriImage(state.sidePanelImageUri, Modifier.fillMaxSize(), crop = true)
                } else {
                    val mask = CliporaRules.panelMaskSize(state.aspectRatio, preset)
                    Text(
                        mask?.let { "SIDE IMAGE\n${it.first} × ${it.second} px" } ?: "Add side image",
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            LayoutPreset.LANDSCAPE_SIDE_PANELS -> {
                val item = if (isLeft) state.sponsors.getOrNull(0) else state.sponsors.getOrNull(1)
                if (item?.kind == SponsorKind.LOGO && !item.imageUri.isNullOrBlank()) {
                    UriImage(item.imageUri, Modifier.fillMaxSize(), crop = true)
                } else {
                    val mask = CliporaRules.panelMaskSize(state.aspectRatio, preset, isLeft)
                    Text(
                        (if (isLeft) "LEFT IMAGE" else "RIGHT IMAGE") +
                            (mask?.let { "\n${it.first} × ${it.second} px" } ?: ""),
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            else -> Unit
        }

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(3.dp)
                .background(Color(state.style.accentColor))
        )
    }
}

private fun Modifier.layoutRect(rect: NormalizedRect, canvasWidth: androidx.compose.ui.unit.Dp, canvasHeight: androidx.compose.ui.unit.Dp): Modifier =
    this
        .offset(x = canvasWidth * rect.left, y = canvasHeight * rect.top)
        .width(canvasWidth * rect.width)
        .height(canvasHeight * rect.height)


@Composable
private fun BreakingBadge(state: EditorState, modifier: Modifier = Modifier) {
    val labels = state.breakingItems
        .map { it.text.trim() }
        .filter { it.isNotEmpty() }
        .ifEmpty { listOf(state.bannerText) }

    var activeIndex by remember(labels) { mutableStateOf(0) }
    val rotationX = remember { Animatable(0f) }
    val shineAlpha = remember { Animatable(0f) }

    LaunchedEffect(
        labels,
        state.style.breakingInterval,
        state.style.breakingFlipEnabled,
        state.style.breakingFlashEnabled
    ) {
        activeIndex = 0
        rotationX.snapTo(0f)
        shineAlpha.snapTo(0f)

        while (true) {
            val total = state.style.breakingInterval.millis.coerceAtLeast(2_000L)
            val transition = (total * .24f).toLong().coerceIn(520L, 900L)
            delay((total - transition).coerceAtLeast(1_400L))

            if (state.style.breakingFlashEnabled) {
                shineAlpha.snapTo(0f)
                shineAlpha.animateTo(.42f, tween(170))
                shineAlpha.animateTo(0f, tween(260))
            }

            if (state.style.breakingFlipEnabled) {
                rotationX.animateTo(90f, tween((transition / 2).toInt()))
                activeIndex = (activeIndex + 1) % labels.size
                rotationX.snapTo(-90f)
                rotationX.animateTo(0f, tween((transition / 2).toInt()))
            } else {
                activeIndex = (activeIndex + 1) % labels.size
                delay(transition)
            }
        }
    }

    val textStyle = state.textStyle(TextTarget.BREAKING)
    val shape = RoundedCornerShape(3.dp)
    val bg = Color(textStyle.backgroundColor)

    Box(
        modifier = modifier
            .graphicsLayer {
                this.rotationX = rotationX.value
                cameraDistance = 22f * density
            }
            .then(
                if (textStyle.backgroundEnabled && state.style.breakingBadge3dEnabled) {
                    Modifier
                        .shadow(8.dp, shape)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.White.copy(alpha = .32f),
                                    bg,
                                    bg.copy(alpha = .90f),
                                    Color.Black.copy(alpha = .30f)
                                )
                            ),
                            shape
                        )
                        .border(1.dp, Color.White.copy(alpha = .34f), shape)
                } else if (textStyle.backgroundEnabled) {
                    Modifier.background(bg, shape)
                } else {
                    Modifier
                }
            )
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        StyledText(
            text = labels[activeIndex.coerceIn(0, labels.lastIndex)],
            style = textStyle.copy(backgroundEnabled = false),
            modifier = Modifier.fillMaxWidth(),
            baseSp = 17f,
            maxLines = 1
        )

        if (
            state.style.breakingFlashEnabled &&
            textStyle.backgroundEnabled &&
            state.style.breakingBadge3dEnabled
        ) {
            Box(
                Modifier
                    .matchParentSize()
                    .alpha(shineAlpha.value)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = .70f),
                                Color.Transparent
                            )
                        ),
                        shape
                    )
            )
        }
    }
}

@Composable
private fun BackgroundBox(
    style: TemplateStyle,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.background(Color(style.backgroundColor))) {
        val uri = style.backgroundImageUri
        if (!uri.isNullOrBlank()) {
            AndroidView(
                factory = { ctx ->
                    ImageView(ctx).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                    }
                },
                update = { view ->
                    view.setImageURI(Uri.parse(uri))
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val blur = style.backgroundBlur
                        view.setRenderEffect(
                            if (blur > 0.1f) RenderEffect.createBlurEffect(blur, blur, Shader.TileMode.CLAMP) else null
                        )
                    }
                },
                modifier = Modifier.matchParentSize()
            )
        }
        content()
    }
}

@Composable
private fun StyledText(
    text: String,
    style: TextBoxStyle,
    modifier: Modifier = Modifier,
    baseSp: Float,
    maxLines: Int
) {
    val fontFamily = when (style.fontFamily) {
        FontFamilyOption.SANS -> FontFamily.SansSerif
        FontFamilyOption.SERIF -> FontFamily.Serif
        FontFamilyOption.MONOSPACE -> FontFamily.Monospace
    }
    val fontWeight = when (style.fontStyle) {
        FontStyleOption.BOLD, FontStyleOption.BOLD_ITALIC -> FontWeight.Bold
        else -> FontWeight.Normal
    }
    val fontStyle = when (style.fontStyle) {
        FontStyleOption.ITALIC, FontStyleOption.BOLD_ITALIC -> FontStyle.Italic
        else -> FontStyle.Normal
    }
    val textAlign = when (style.alignment) {
        TextAlignmentOption.START -> TextAlign.Start
        TextAlignmentOption.CENTER -> TextAlign.Center
        TextAlignmentOption.END -> TextAlign.End
    }
    val alignment = when (style.alignment) {
        TextAlignmentOption.START -> Alignment.CenterStart
        TextAlignmentOption.CENTER -> Alignment.Center
        TextAlignmentOption.END -> Alignment.CenterEnd
    }
    val bgModifier = if (style.backgroundEnabled) {
        Modifier.background(Color(style.backgroundColor), RoundedCornerShape(5.dp)).padding(horizontal = 5.dp, vertical = 2.dp)
    } else Modifier

    Box(modifier.then(bgModifier), contentAlignment = alignment) {
        Text(
            text = text,
            color = Color(style.textColor),
            textAlign = textAlign,
            fontFamily = fontFamily,
            fontWeight = fontWeight,
            fontStyle = fontStyle,
            fontSize = (baseSp * style.sizeScale).sp,
            maxLines = maxLines,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AdvertisementBannerArea(state: EditorState, modifier: Modifier = Modifier) {
    val banners = state.sponsors
    var activeIndex by remember(banners, state.style.sponsorMarqueeEnabled) { mutableStateOf(0) }

    LaunchedEffect(banners.size, state.style.sponsorMarqueeEnabled, state.style.sponsorMarqueeInterval) {
        activeIndex = 0
        if (state.style.sponsorMarqueeEnabled && banners.size > 1) {
            while (true) {
                delay(state.style.sponsorMarqueeInterval.millis.coerceAtLeast(500L))
                activeIndex = (activeIndex + 1) % banners.size
            }
        }
    }

    Box(
        modifier.background(Color.White).border(1.dp, Color(0xFF222222)).padding(3.dp),
        contentAlignment = Alignment.Center
    ) {
        val banner = banners.getOrNull(activeIndex.coerceIn(0, (banners.size - 1).coerceAtLeast(0)))
        if (banner == null) {
            Text("Add advertisement banner", color = Color.DarkGray)
        } else if (banner.kind == SponsorKind.LOGO && !banner.imageUri.isNullOrBlank()) {
            UriImage(banner.imageUri, Modifier.fillMaxSize())
        } else {
            StyledText(
                banner.text,
                state.textStyle(TextTarget.SPONSOR),
                Modifier.fillMaxSize(),
                baseSp = 18f,
                maxLines = 3
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NewsMarqueeRow(state: EditorState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "live-blink")
    val liveAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(animation = tween(500), repeatMode = RepeatMode.Reverse),
        label = "live-alpha"
    )
    val activeItems = state.marqueeItems.map { it.text.trim() }.filter { it.isNotEmpty() }
    val gapSpaces = CliporaRules.marqueeGapSpaces(state.marqueeInterval)
    val separator = " ".repeat(gapSpaces) + "•" + " ".repeat(gapSpaces)
    val marqueeText = activeItems.joinToString(separator).ifBlank { "Add a news line" }
    val liveStyle = state.textStyle(TextTarget.LIVE)
    val tickerStyle = state.textStyle(TextTarget.TICKER)

    Row(modifier.background(Color(state.style.tickerBackgroundColor))) {
        Box(
            Modifier.fillMaxHeight().width(64.dp)
                .background(Color(if (liveStyle.backgroundEnabled) liveStyle.backgroundColor else state.style.accentColor)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                state.liveLabel,
                color = Color(liveStyle.textColor),
                fontFamily = when (liveStyle.fontFamily) {
                    FontFamilyOption.SANS -> FontFamily.SansSerif
                    FontFamilyOption.SERIF -> FontFamily.Serif
                    FontFamilyOption.MONOSPACE -> FontFamily.Monospace
                },
                fontWeight = if (liveStyle.fontStyle == FontStyleOption.BOLD || liveStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontWeight.Black else FontWeight.Normal,
                fontStyle = if (liveStyle.fontStyle == FontStyleOption.ITALIC || liveStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontStyle.Italic else FontStyle.Normal,
                fontSize = (10f * liveStyle.sizeScale).sp,
                modifier = Modifier.alpha(liveAlpha)
            )
        }
        Box(Modifier.fillMaxSize().padding(horizontal = 6.dp), contentAlignment = Alignment.CenterStart) {
            Text(
                marqueeText,
                color = Color(tickerStyle.textColor),
                fontFamily = when (tickerStyle.fontFamily) {
                    FontFamilyOption.SANS -> FontFamily.SansSerif
                    FontFamilyOption.SERIF -> FontFamily.Serif
                    FontFamilyOption.MONOSPACE -> FontFamily.Monospace
                },
                fontWeight = if (tickerStyle.fontStyle == FontStyleOption.BOLD || tickerStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (tickerStyle.fontStyle == FontStyleOption.ITALIC || tickerStyle.fontStyle == FontStyleOption.BOLD_ITALIC) FontStyle.Italic else FontStyle.Normal,
                fontSize = (10f * tickerStyle.sizeScale).sp,
                maxLines = 1,
                modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE)
            )
        }
    }
}

@Composable
private fun SelectedAssetPill(
    label: String = "Added",
    onRemove: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color(0xFFE8F5E9),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E7D32))
    ) {
        Row(
            modifier = Modifier.padding(start = 10.dp, end = 3.dp, top = 2.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                "✓ $label",
                color = Color(0xFF2E7D32),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall
            )
            TextButton(
                onClick = onRemove,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("×", color = Color(0xFF2E7D32), fontSize = 20.sp)
            }
        }
    }
}

@Composable
private fun AssetSelectionRow(
    selected: Boolean,
    chooseLabel: String,
    onChoose: () -> Unit,
    onRemove: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(onClick = onChoose) { Text(chooseLabel) }
        if (selected && onRemove != null) {
            SelectedAssetPill(onRemove = onRemove)
        } else if (selected) {
            Text(
                "✓ Added",
                color = Color(0xFF2E7D32),
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun UriImage(uri: String?, modifier: Modifier = Modifier, crop: Boolean = false) {
    if (uri.isNullOrBlank()) return
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply {
            scaleType = if (crop) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.CENTER_INSIDE
            adjustViewBounds = false
        } },
        update = { view ->
            view.scaleType = if (crop) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.CENTER_INSIDE
            view.setImageURI(Uri.parse(uri))
        },
        modifier = modifier
    )
}

@Composable
private fun EditorControls(state: EditorState, vm: EditorViewModel, mode: EditorMediaMode) {
    val context = LocalContext.current
    val repo = remember(context) { ThemeRepository(context) }
    var savedThemes by remember { mutableStateOf(repo.list()) }
    var selectedThemeId by remember { mutableStateOf<String?>(null) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var themeName by remember { mutableStateOf("") }
    var showVideoOptions by remember { mutableStateOf(false) }
    var showAppearance by remember { mutableStateOf(false) }
    var sponsorLogoTarget by remember { mutableStateOf<Int?>(null) }
    var selectedTextTarget by remember { mutableStateOf(TextTarget.HEADLINE) }
    val availableTextTargets = CliporaRules.editableTextTargets(state.layoutPreset)

    LaunchedEffect(state.layoutPreset) {
        if (selectedTextTarget !in availableTextTargets) {
            selectedTextTarget = availableTextTargets.first()
        }
    }

    val channelLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setChannelLogoUri(it.toString()) }
    }
    val sponsorLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val id = sponsorLogoTarget
        if (id != null && uri != null) {
            persistReadPermission(context, uri)
            vm.setSponsorLogo(id, uri.toString())
        }
        sponsorLogoTarget = null
    }
    val backgroundImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setBackgroundImageUri(it.toString()) }
    }
    val sidePanelImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { persistReadPermission(context, it); vm.setSidePanelImageUri(it.toString()) }
    }

    SectionCard("Format") {
        Text("Video size", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(AspectRatioOption.entries, state.aspectRatio, { it.label }, vm::setAspectRatio)

        val layouts = CliporaRules.validLayouts(state.aspectRatio)
        if (layouts.size > 1) {
            Text("Design", style = MaterialTheme.typography.titleSmall)
            ChoiceRow(layouts, state.layoutPreset, { it.label }, vm::setLayoutPreset)
        }

        if (state.aspectRatio == AspectRatioOption.LANDSCAPE) {
            Text(
                "YouTube output 16:9 · video window also stays 16:9",
                style = MaterialTheme.typography.bodySmall
            )
        }

        TextButton(onClick = vm::applyDemoContentForCurrentLayout) {
            Text("Use sample text for this design")
        }
    }

    SectionCard("Content") {
        OutlinedTextField(
            value = state.location,
            onValueChange = vm::setLocation,
            label = { Text("Location") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        AssetSelectionRow(
            selected = !state.channelLogoUri.isNullOrBlank(),
            chooseLabel = if (state.channelLogoUri.isNullOrBlank()) "Add logo" else "Change logo",
            onChoose = { channelLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            onRemove = { vm.setChannelLogoUri(null) }
        )
        CliporaRules.logoMaskSize(state.aspectRatio, state.layoutPreset).let { mask ->
            Text("Logo mask: ${mask.first} × ${mask.second} px", style = MaterialTheme.typography.bodySmall)
        }
        if (state.channelLogoUri.isNullOrBlank()) {
            OutlinedTextField(
                value = state.logoText,
                onValueChange = vm::setLogoText,
                label = { Text("Channel name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (CliporaRules.usesTopHeadline(state.layoutPreset)) {
            SimpleSectionLabel("Headlines")
            state.headlineItems.take(CliporaRules.MAX_HEADLINE_ITEMS).forEachIndexed { index, item ->
                OutlinedTextField(
                    value = item.text,
                    onValueChange = { vm.setHeadlineText(item.id, it) },
                    label = { Text("Heading ${index + 1}") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (CliporaRules.usesSideText(state.layoutPreset)) {
            SimpleSectionLabel("Side story")
            OutlinedTextField(
                value = state.sidePanelText,
                onValueChange = vm::setSidePanelText,
                label = { Text("Text beside video") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (state.layoutPreset == LayoutPreset.LANDSCAPE_SIDE_IMAGE) {
            SimpleSectionLabel("Side image")
            CliporaRules.panelMaskSize(state.aspectRatio, state.layoutPreset)?.let { mask ->
                Text(
                    "Fixed image mask: ${mask.first} × ${mask.second} px · image crops to fill, never stretches",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            AssetSelectionRow(
                selected = !state.sidePanelImageUri.isNullOrBlank(),
                chooseLabel = if (state.sidePanelImageUri.isNullOrBlank()) "Add side image" else "Change side image",
                onChoose = { sidePanelImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                onRemove = { vm.setSidePanelImageUri(null) }
            )
        }

        if (CliporaRules.usesBreakingBadge(state.layoutPreset)) {
            SimpleSectionLabel("Breaking News")
            Text(
                "Glossy 3D style and front/back flip are automatic.",
                style = MaterialTheme.typography.bodySmall
            )
            state.breakingItems.take(CliporaRules.MAX_BREAKING_ITEMS).forEachIndexed { index, item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = item.text,
                        onValueChange = { vm.setBreakingText(item.id, it) },
                        label = { Text("Text ${index + 1}") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    if (state.breakingItems.size > 1) {
                        SelectedAssetPill(label = "Text ${index + 1}") { vm.removeBreakingItem(item.id) }
                    }
                }
            }
            if (state.breakingItems.size < CliporaRules.MAX_BREAKING_ITEMS) {
                TextButton(onClick = vm::addBreakingItem) { Text("+ Add text") }
            }
            if (mode == EditorMediaMode.VIDEO) {
                Text("Change every", style = MaterialTheme.typography.labelMedium)
                ChoiceRow(
                    listOf(MarqueeIntervalOption.EXTRA_LONG, MarqueeIntervalOption.FIVE_SECONDS),
                    state.style.breakingInterval,
                    { it.label },
                    vm::setBreakingInterval
                )
            }
        }

        if (CliporaRules.usesLowerHeadline(state.layoutPreset)) {
            SimpleSectionLabel("Headlines below video")
            state.lowerHeadlineItems.take(CliporaRules.MAX_LOWER_HEADLINE_ITEMS).forEachIndexed { index, item ->
                OutlinedTextField(
                    value = item.text,
                    onValueChange = { vm.setLowerHeadlineText(item.id, it) },
                    label = { Text("Breaking heading ${index + 1}") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        SimpleSectionLabel("Bottom news ticker")
        state.marqueeItems.forEachIndexed { index, item ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = item.text,
                    onValueChange = { vm.setMarqueeText(item.id, it) },
                    label = { Text("News ${index + 1}") },
                    modifier = Modifier.weight(1f)
                )
                if (state.marqueeItems.size > 1) {
                    SelectedAssetPill(label = "News ${index + 1}") { vm.removeMarqueeLine(item.id) }
                }
            }
        }
        if (state.marqueeItems.size < CliporaRules.MAX_MARQUEE_ITEMS) {
            TextButton(onClick = vm::addMarqueeLine) { Text("+ Add news line") }
        }
    }

    if (CliporaRules.usesAdvertisementBanner(state.layoutPreset)) {
        SectionCard("Advertisement") {
            val adMask = CliporaRules.advertisementMaskSize(state.aspectRatio, state.layoutPreset)
            Text(
                buildString {
                    append("Upload one complete banner. Add more only if you want banners to rotate.")
                    if (adMask != null) append(" Fixed mask: ${adMask.first} × ${adMask.second} px.")
                },
                style = MaterialTheme.typography.bodySmall
            )
            state.sponsors.take(CliporaRules.maxEditableAdvertisementBanners(mode)).forEachIndexed { index, banner ->
                Card(Modifier.fillMaxWidth()) {
                    Column(
                        Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Banner ${index + 1}", style = MaterialTheme.typography.labelLarge)
                        AssetSelectionRow(
                            selected = !banner.imageUri.isNullOrBlank(),
                            chooseLabel = if (banner.imageUri.isNullOrBlank()) "Choose banner image" else "Change banner image",
                            onChoose = {
                                sponsorLogoTarget = banner.id
                                sponsorLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onRemove = { vm.clearSponsorLogo(banner.id) }
                        )
                        if (banner.imageUri.isNullOrBlank()) {
                            OutlinedTextField(
                                value = banner.text,
                                onValueChange = { vm.setSponsorText(banner.id, it) },
                                label = { Text("Banner text") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        if (state.sponsors.size > 1) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                SelectedAssetPill(label = "Banner ${index + 1}") { vm.removeSponsor(banner.id) }
                            }
                        }
                    }
                }
            }
            if (mode == EditorMediaMode.VIDEO && state.sponsors.size < CliporaRules.MAX_AD_BANNERS) {
                TextButton(onClick = vm::addSponsorLogo) { Text("+ Add another banner") }
            }
            if (mode == EditorMediaMode.VIDEO && state.sponsors.size > 1) {
                Text("Banners rotate automatically.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    if (state.layoutPreset == LayoutPreset.LANDSCAPE_SIDE_PANELS) {
        SectionCard("Left / right images") {
            val leftMask = CliporaRules.panelMaskSize(state.aspectRatio, state.layoutPreset, true)
            val rightMask = CliporaRules.panelMaskSize(state.aspectRatio, state.layoutPreset, false)
            Text(
                if (leftMask != null && rightMask != null)
                    "Fixed masks — left ${leftMask.first} × ${leftMask.second} px · right ${rightMask.first} × ${rightMask.second} px. Images crop to fill; no stretching."
                else "Use two fixed image panels beside the 16:9 video.",
                style = MaterialTheme.typography.bodySmall
            )
            state.sponsors.take(2).forEachIndexed { index, banner ->
                AssetSelectionRow(
                    selected = !banner.imageUri.isNullOrBlank(),
                    chooseLabel = if (banner.imageUri.isNullOrBlank()) {
                        if (index == 0) "Add left image" else "Add right image"
                    } else {
                        if (index == 0) "Change left image" else "Change right image"
                    },
                    onChoose = {
                        sponsorLogoTarget = banner.id
                        sponsorLogoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onRemove = { vm.clearSponsorLogo(banner.id) }
                )
            }
            if (state.sponsors.size < 2) {
                TextButton(onClick = vm::addSponsorLogo) { Text("+ Add second side image") }
            }
        }
    }

    SectionCard("Background") {
        CliporaRules.backgroundCanvasSize(state.aspectRatio).let { size ->
            Text("Background canvas: ${size.first} × ${size.second} px", style = MaterialTheme.typography.bodySmall)
        }
        HexColorControl("Background colour", state.style.backgroundColor, vm::setBackgroundColor)
        AssetSelectionRow(
            selected = !state.style.backgroundImageUri.isNullOrBlank(),
            chooseLabel = if (state.style.backgroundImageUri.isNullOrBlank()) "Add background image" else "Change background image",
            onChoose = { backgroundImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            onRemove = { vm.setBackgroundImageUri(null) }
        )
        if (!state.style.backgroundImageUri.isNullOrBlank()) {
            Text("Blur: ${state.style.backgroundBlur.toInt()}")
            Slider(
                value = state.style.backgroundBlur,
                onValueChange = vm::setBackgroundBlur,
                valueRange = 0f..30f
            )
        }
        HexColorControl("LIVE colour", state.style.accentColor, vm::setAccentColor)
        HexColorControl("Ticker background", state.style.tickerBackgroundColor, vm::setTickerColor)
    }

    ExpandableEditorCard(
        title = "Text appearance",
        subtitle = "Font, size and colour",
        expanded = showAppearance,
        onToggle = { showAppearance = !showAppearance }
    ) {
        ChoiceRow(availableTextTargets, selectedTextTarget, { it.label }) { selectedTextTarget = it }
        val selectedStyle = state.textStyle(selectedTextTarget)
        HexColorControl("Text colour", selectedStyle.textColor) { vm.setTextBoxTextColor(selectedTextTarget, it) }
        Text("Font", style = MaterialTheme.typography.labelMedium)
        ChoiceRow(FontFamilyOption.entries, selectedStyle.fontFamily, { it.label }) {
            vm.setTextBoxFontFamily(selectedTextTarget, it)
        }
        ChoiceRow(FontStyleOption.entries, selectedStyle.fontStyle, { it.label }) {
            vm.setTextBoxFontStyle(selectedTextTarget, it)
        }
        Text("Size: ${(selectedStyle.sizeScale * 100).toInt()}%")
        Slider(
            value = selectedStyle.sizeScale,
            onValueChange = { vm.setTextBoxSizeScale(selectedTextTarget, it) },
            valueRange = 0.65f..1.6f
        )
        Text("Alignment", style = MaterialTheme.typography.labelMedium)
        ChoiceRow(TextAlignmentOption.entries, selectedStyle.alignment, { it.label }) {
            vm.setTextBoxAlignment(selectedTextTarget, it)
        }
    }

    ExpandableEditorCard(
        title = if (mode == EditorMediaMode.VIDEO) "Video options" else "Image options",
        subtitle = if (mode == EditorMediaMode.VIDEO) "Fit, duration and trim" else "Fit or crop",
        expanded = showVideoOptions,
        onToggle = { showVideoOptions = !showVideoOptions }
    ) {
        ChoiceRow(VideoScaleMode.entries, state.videoScaleMode, {
            if (mode == EditorMediaMode.VIDEO) it.label
            else when (it) {
                VideoScaleMode.FIT -> "Fit - full image"
                VideoScaleMode.FILL -> "Fill - crop"
            }
        }, vm::setVideoScaleMode)

        if (mode == EditorMediaMode.VIDEO) {
            Text("Duration", style = MaterialTheme.typography.labelMedium)
            ChoiceRow(DurationOption.entries, state.duration, { it.label }, vm::setDuration)
            if (state.sourceDurationMs > 1_000L) {
                Text("Trim start: ${state.trimStartMs / 1000}s")
                Slider(
                    value = state.trimStartMs.toFloat(),
                    onValueChange = { vm.setTrimStart(it.roundToLong()) },
                    valueRange = 0f..(state.sourceDurationMs - 1_000L).toFloat()
                )
            }
        }
    }

    SectionCard("Theme") {
        if (savedThemes.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(savedThemes) { theme ->
                    FilterChip(
                        selected = selectedThemeId == theme.id,
                        onClick = {
                            selectedThemeId = theme.id
                            vm.applySavedTheme(theme)
                        },
                        label = { Text(theme.name) }
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { themeName = ""; showSaveDialog = true }) { Text("Save theme") }
            if (selectedThemeId != null) {
                OutlinedButton(onClick = {
                    val id = selectedThemeId
                    val old = savedThemes.firstOrNull { it.id == id }
                    if (id != null && old != null) {
                        repo.save(savedThemeFromState(state, id, old.name))
                        savedThemes = repo.list()
                    }
                }) { Text("Update") }
                OutlinedButton(onClick = {
                    val id = selectedThemeId
                    if (id != null) {
                        repo.delete(id)
                        selectedThemeId = null
                        savedThemes = repo.list()
                    }
                }) { Text("Delete") }
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save this design as a theme?") },
            text = {
                OutlinedTextField(
                    value = themeName,
                    onValueChange = { themeName = it },
                    label = { Text("Theme name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = themeName.trim().ifBlank { "My News Theme" }
                    val id = "theme_${System.currentTimeMillis()}"
                    repo.save(savedThemeFromState(state, id, name))
                    savedThemes = repo.list()
                    selectedThemeId = id
                    showSaveDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("Not now") } }
        )
    }
}

@Composable
private fun SimpleSectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall)
}

@Composable
private fun ExpandableEditorCard(
    title: String,
    subtitle: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall)
                }
                Text(if (expanded) "▲" else "▼")
            }
            if (expanded) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    content = content
                )
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun ColorPickerRow(label: String, selected: Int, onSelect: (Int) -> Unit, values: List<Int>) {
    Text(label, style = MaterialTheme.typography.titleSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        values.forEach { value ->
            Box(
                Modifier.size(34.dp).background(Color(value), RoundedCornerShape(17.dp))
                    .border(if (selected == value) 3.dp else 1.dp, if (selected == value) MaterialTheme.colorScheme.primary else Color.Gray,
                        RoundedCornerShape(17.dp))
                    .clickable { onSelect(value) }
            )
        }
    }
}

@Composable
private fun HexColorControl(label: String, color: Int, onColor: (Int) -> Unit) {
    var showPicker by remember { mutableStateOf(false) }
    val hex = remember(color) { colorToHex(color) }

    OutlinedCard(
        modifier = Modifier.fillMaxWidth().clickable { showPicker = true }
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.size(34.dp)
                    .background(Color(color), RoundedCornerShape(8.dp))
                    .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
            )
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelMedium)
                Text(hex, style = MaterialTheme.typography.bodyMedium)
            }
            Text("Pick", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        }
    }

    if (showPicker) {
        ColorPickerDialog(
            title = label,
            initialColor = color,
            onDismiss = { showPicker = false },
            onApply = {
                onColor(it)
                showPicker = false
            }
        )
    }
}

@Composable
private fun ColorPickerDialog(
    title: String,
    initialColor: Int,
    onDismiss: () -> Unit,
    onApply: (Int) -> Unit
) {
    var alpha by remember(initialColor) { mutableFloatStateOf(android.graphics.Color.alpha(initialColor).toFloat()) }
    var red by remember(initialColor) { mutableFloatStateOf(android.graphics.Color.red(initialColor).toFloat()) }
    var green by remember(initialColor) { mutableFloatStateOf(android.graphics.Color.green(initialColor).toFloat()) }
    var blue by remember(initialColor) { mutableFloatStateOf(android.graphics.Color.blue(initialColor).toFloat()) }
    var hexText by remember(initialColor) { mutableStateOf(colorToHex(initialColor)) }

    fun selectedColor(): Int = android.graphics.Color.argb(
        alpha.roundToInt().coerceIn(0, 255),
        red.roundToInt().coerceIn(0, 255),
        green.roundToInt().coerceIn(0, 255),
        blue.roundToInt().coerceIn(0, 255)
    )

    fun syncHexFromSliders() {
        hexText = colorToHex(selectedColor())
    }

    val palette = listOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFF44336.toInt(), 0xFFFF1744.toInt(),
        0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(), 0xFF00BCD4.toInt(),
        0xFF2196F3.toInt(), 0xFF3F51B5.toInt(), 0xFF673AB7.toInt(), 0xFFE91E63.toInt()
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(52.dp)
                        .background(Color(selectedColor()), RoundedCornerShape(10.dp))
                        .border(1.dp, Color.Gray, RoundedCornerShape(10.dp))
                )

                Text("Quick colours", style = MaterialTheme.typography.labelLarge)
                palette.chunked(6).forEach { rowColours ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowColours.forEach { value ->
                            Box(
                                Modifier.size(36.dp)
                                    .background(Color(value), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                                    .clickable {
                                        alpha = android.graphics.Color.alpha(value).toFloat()
                                        red = android.graphics.Color.red(value).toFloat()
                                        green = android.graphics.Color.green(value).toFloat()
                                        blue = android.graphics.Color.blue(value).toFloat()
                                        syncHexFromSliders()
                                    }
                            )
                        }
                    }
                }

                ColorSlider("Red", red, Color.Red) {
                    red = it
                    syncHexFromSliders()
                }
                ColorSlider("Green", green, Color.Green) {
                    green = it
                    syncHexFromSliders()
                }
                ColorSlider("Blue", blue, Color.Blue) {
                    blue = it
                    syncHexFromSliders()
                }
                ColorSlider("Opacity", alpha, Color.Gray) {
                    alpha = it
                    syncHexFromSliders()
                }

                OutlinedTextField(
                    value = hexText,
                    onValueChange = { value ->
                        hexText = value
                        parseColorOrNull(value)?.let { parsed ->
                            alpha = android.graphics.Color.alpha(parsed).toFloat()
                            red = android.graphics.Color.red(parsed).toFloat()
                            green = android.graphics.Color.green(parsed).toFloat()
                            blue = android.graphics.Color.blue(parsed).toFloat()
                        }
                    },
                    label = { Text("Hex colour") },
                    supportingText = { Text("#RRGGBB or #AARRGGBB") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onApply(selectedColor()) }) { Text("Apply") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ColorSlider(label: String, value: Float, tint: Color, onValue: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value.roundToInt().toString(), style = MaterialTheme.typography.labelMedium)
        }
        Slider(
            value = value,
            onValueChange = onValue,
            valueRange = 0f..255f,
            colors = SliderDefaults.colors(
                thumbColor = tint,
                activeTrackColor = tint
            )
        )
    }
}

private fun colorToHex(color: Int): String = String.format("#%08X", color)

private fun parseColorOrNull(value: String): Int? = runCatching {
    android.graphics.Color.parseColor(value.trim())
}.getOrNull()

@Composable
private fun ImageMediaLayer(state: EditorState) {
    val spec = remember(state.aspectRatio, state.layoutPreset) {
        NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val rect = spec.videoRect
        val cw = maxWidth
        val ch = maxHeight

        Box(
            Modifier
                .layoutRect(rect, cw, ch)
                .background(Color.Black)
        ) {
            state.mediaUri?.let { value ->
                AndroidView(
                    factory = { ctx -> ImageView(ctx) },
                    update = { view ->
                        view.scaleType = when (state.videoScaleMode) {
                            VideoScaleMode.FIT -> ImageView.ScaleType.FIT_CENTER
                            VideoScaleMode.FILL -> ImageView.ScaleType.CENTER_CROP
                        }
                        view.setImageURI(Uri.parse(value))
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ImageEditorScreen(onBack: () -> Unit, vm: EditorViewModel = viewModel(key = "image-editor")) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let {
            persistReadPermission(context, it)
            vm.setMediaUri(it.toString())
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("News image editor") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AssetSelectionRow(
                selected = state.mediaUri != null,
                chooseLabel = if (state.mediaUri == null) "Import image" else "Change image",
                onChoose = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                onRemove = vm::removeMedia
            )

            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(state.aspectRatio.ratio)
                    .background(Color(state.style.backgroundColor))
            ) {
                BackgroundBox(state.style, Modifier.fillMaxSize()) {}
                ImageMediaLayer(state)
                NewsTemplateOverlay(state)
            }

            EditorControls(state, vm, EditorMediaMode.IMAGE)

            Button(
                enabled = state.mediaUri != null,
                onClick = {
                    vm.setExportStatus("Exporting JPG to Gallery…")
                    val result = ImageExportManager(context).export(state)
                    vm.setExportStatus(result.fold(
                        { "Saved to Gallery: Pictures/Clipora/Images" },
                        { "Export failed: ${it.message ?: "unknown error"}" }
                    ))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export JPG to Gallery") }

            state.exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SavedThemesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember(context) { ThemeRepository(context) }
    var themes by remember { mutableStateOf(repo.list()) }
    var renameTheme by remember { mutableStateOf<SavedTheme?>(null) }
    var renameText by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(title = { Text("My Themes") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (themes.isEmpty()) Text("Save a theme from the editor and it will appear here.")
            themes.forEach { theme ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(theme.name, style = MaterialTheme.typography.titleMedium)
                        Text("${theme.style.fontFamily.label} • ${theme.style.fontStyle.label} • ${theme.style.sponsorColumns} sponsor columns • ${theme.marqueeInterval.label} ticker gap",
                            style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { renameTheme = theme; renameText = theme.name }) { Text("Rename") }
                            TextButton(onClick = {
                                val copy = theme.copy(id = "theme_${System.currentTimeMillis()}", name = "${theme.name} Copy")
                                repo.save(copy); themes = repo.list()
                            }) { Text("Duplicate") }
                            TextButton(onClick = { repo.delete(theme.id); themes = repo.list() }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    renameTheme?.let { theme ->
        AlertDialog(
            onDismissRequest = { renameTheme = null },
            title = { Text("Rename theme") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    repo.save(theme.copy(name = renameText.trim().ifBlank { theme.name }))
                    themes = repo.list(); renameTheme = null
                }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameTheme = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun <T> ChoiceRow(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(values) { value ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label(value)) })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleListScreen(title: String, lines: List<String>, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            lines.forEach { Text(it) }
        }
    }
}

private fun savedThemeFromState(state: EditorState, id: String, name: String) = SavedTheme(
    id = id,
    name = name,
    style = state.style,
    textStyles = state.textStyles,
    logoText = state.logoText,
    channelLogoUri = state.channelLogoUri,
    watermarkLogoUri = state.watermarkLogoUri,
    bannerText = state.bannerText,
    breakingItems = state.breakingItems,
    liveLabel = state.liveLabel,
    marqueeInterval = state.marqueeInterval,
    aspectRatio = state.aspectRatio,
    layoutPreset = state.layoutPreset
)

private fun persistReadPermission(context: Context, uri: Uri) {
    runCatching {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}
