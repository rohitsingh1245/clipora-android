package com.clipora.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.clipora.app.ui.CliporaApp
import com.clipora.app.ui.theme.CliporaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CliporaTheme {
                CliporaApp()
            }
        }
    }
}
