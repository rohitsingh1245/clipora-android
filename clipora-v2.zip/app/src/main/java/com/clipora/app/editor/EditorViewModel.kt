package com.clipora.app.editor

import androidx.lifecycle.ViewModel
import com.clipora.app.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class EditorViewModel : ViewModel() {
    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()
    private var nextSponsorId = 10
    private var nextMarqueeId = 10
    private var nextBreakingId = 10
    private var nextHeadlineId = 20
    private var nextLowerHeadlineId = 120

    fun setMediaUri(uri: String) = _state.update { current ->
        current.copy(
            mediaUri = uri,
            mediaRevision = current.mediaRevision + 1,
            trimStartMs = 0L,
            sourceDurationMs = 0L,
            exportStatus = null,
            exportProgress = null
        )
    }

    fun removeMedia() = _state.update { current ->
        current.copy(
            mediaUri = null,
            mediaRevision = current.mediaRevision + 1,
            trimStartMs = 0L,
            sourceDurationMs = 0L,
            exportStatus = null,
            exportProgress = null
        )
    }

    fun setSourceDuration(durationMs: Long) = _state.update { it.copy(sourceDurationMs = durationMs.coerceAtLeast(0L)) }
    fun setAspectRatio(value: AspectRatioOption) = _state.update { current ->
        val preset = CliporaRules.defaultLayout(value)
        val base = current.copy(
            aspectRatio = value,
            layoutPreset = preset,
            mediaRevision = current.mediaRevision + 1,
            exportStatus = null
        )
        if (current.isUsingDemoContent) base.withDemoContent(preset) else base
    }

    fun setLayoutPreset(value: LayoutPreset) = _state.update { current ->
        val normalized = CliporaRules.normalizeLayout(current.aspectRatio, value)
        val base = current.copy(layoutPreset = normalized, mediaRevision = current.mediaRevision + 1, exportStatus = null)
        if (current.isUsingDemoContent) base.withDemoContent(normalized) else base
    }

    fun applyDemoContentForCurrentLayout() = _state.update { current ->
        current.withDemoContent(current.layoutPreset).copy(isUsingDemoContent = true)
    }
    fun setVideoScaleMode(value: VideoScaleMode) = _state.update { current ->
        current.copy(videoScaleMode = value, mediaRevision = current.mediaRevision + 1, exportStatus = null)
    }
    fun setDuration(value: DurationOption) = _state.update { it.copy(duration = value) }
    fun setTheme(value: ThemePreset) = _state.update { it.copy(theme = value, style = presetStyle(value)) }
    fun setLocation(value: String) = _state.update { it.copy(location = value, isUsingDemoContent = false) }
    fun setLogoText(value: String) = _state.update { it.copy(logoText = value, isUsingDemoContent = false) }
    fun setChannelLogoUri(value: String?) = _state.update { it.copy(channelLogoUri = value, isUsingDemoContent = false) }
    fun setHeadline(value: String) = _state.update { current ->
        val updated = current.headlineItems.mapIndexed { index, item ->
            if (index == 0) item.copy(text = value) else item
        }
        current.copy(headline = value, headlineItems = updated, isUsingDemoContent = false)
    }

    fun setHeadlineText(id: Int, value: String) = _state.update { current ->
        val updated = current.headlineItems.map { if (it.id == id) it.copy(text = value) else it }
        current.copy(headlineItems = updated, headline = updated.firstOrNull()?.text.orEmpty(), isUsingDemoContent = false)
    }

    fun addHeadlineItem() = _state.update { current ->
        if (current.headlineItems.size >= CliporaRules.MAX_HEADLINE_ITEMS) current
        else current.copy(headlineItems = current.headlineItems + HeadlineItem(nextHeadlineId++, ""))
    }

    fun removeHeadlineItem(id: Int) = _state.update { current ->
        if (current.headlineItems.size <= 1) current
        else {
            val updated = current.headlineItems.filterNot { it.id == id }
            current.copy(headlineItems = updated, headline = updated.firstOrNull()?.text.orEmpty(), isUsingDemoContent = false)
        }
    }

    fun setLowerHeadlineText(id: Int, value: String) = _state.update { current ->
        current.copy(isUsingDemoContent = false, lowerHeadlineItems = current.lowerHeadlineItems.map {
            if (it.id == id) it.copy(text = value) else it
        })
    }

    fun addLowerHeadlineItem() = _state.update { current ->
        if (current.lowerHeadlineItems.size >= CliporaRules.MAX_LOWER_HEADLINE_ITEMS) current
        else current.copy(lowerHeadlineItems = current.lowerHeadlineItems + HeadlineItem(nextLowerHeadlineId++, ""))
    }

    fun removeLowerHeadlineItem(id: Int) = _state.update { current ->
        if (current.lowerHeadlineItems.size <= 1) current
        else current.copy(lowerHeadlineItems = current.lowerHeadlineItems.filterNot { it.id == id })
    }

    fun setHeadlineInterval(value: MarqueeIntervalOption) = _state.update { it.copy(headlineInterval = value) }
    fun setLowerHeadlineInterval(value: MarqueeIntervalOption) = _state.update { it.copy(lowerHeadlineInterval = value) }
    fun setSidePanelText(value: String) = _state.update { it.copy(sidePanelText = value, isUsingDemoContent = false) }
    fun setSidePanelImageUri(value: String?) = _state.update { it.copy(sidePanelImageUri = value, isUsingDemoContent = false) }
    fun setBannerText(value: String) = _state.update { current ->
        val updated = if (current.breakingItems.isEmpty()) {
            listOf(BreakingItem(nextBreakingId++, value))
        } else {
            current.breakingItems.mapIndexed { index, item -> if (index == 0) item.copy(text = value) else item }
        }
        current.copy(bannerText = value, breakingItems = updated)
    }

    fun addBreakingItem() = _state.update { current ->
        if (current.breakingItems.size >= CliporaRules.MAX_BREAKING_ITEMS) current
        else current.copy(breakingItems = current.breakingItems + BreakingItem(nextBreakingId++, "NEW LABEL"))
    }

    fun setBreakingText(id: Int, value: String) = _state.update { current ->
        val updated = current.breakingItems.map { if (it.id == id) it.copy(text = value) else it }
        current.copy(
            breakingItems = updated,
            bannerText = updated.firstOrNull()?.text ?: current.bannerText
        )
    }

    fun removeBreakingItem(id: Int) = _state.update { current ->
        if (current.breakingItems.size <= 1) current
        else {
            val updated = current.breakingItems.filterNot { it.id == id }
            current.copy(isUsingDemoContent = false, breakingItems = updated, bannerText = updated.firstOrNull()?.text ?: current.bannerText)
        }
    }
    fun setWatermarkLogoUri(value: String?) = _state.update { it.copy(watermarkLogoUri = value, isUsingDemoContent = false) }
    fun setLiveLabel(value: String) = _state.update { it.copy(liveLabel = value, isUsingDemoContent = false) }
    fun setMarqueeInterval(value: MarqueeIntervalOption) = _state.update { it.copy(marqueeInterval = value) }

    fun addMarqueeLine() = _state.update { current ->
        if (current.marqueeItems.size >= CliporaRules.MAX_MARQUEE_ITEMS) current
        else current.copy(marqueeItems = current.marqueeItems + MarqueeItem(nextMarqueeId++, "New news line"))
    }

    fun setMarqueeText(id: Int, value: String) = _state.update { current ->
        current.copy(marqueeItems = current.marqueeItems.map { if (it.id == id) it.copy(text = value) else it }, isUsingDemoContent = false)
    }

    fun removeMarqueeLine(id: Int) = _state.update { current ->
        if (current.marqueeItems.size <= 1) current
        else current.copy(marqueeItems = current.marqueeItems.filterNot { it.id == id })
    }

    fun setBackgroundColor(value: Int) = updateStyle { it.copy(backgroundColor = value) }
    fun setBackgroundImageUri(value: String?) = updateStyle { it.copy(backgroundImageUri = value) }
    fun setBackgroundBlur(value: Float) = updateStyle { it.copy(backgroundBlur = value.coerceIn(0f, 30f)) }
    fun setAccentColor(value: Int) = updateStyle { it.copy(accentColor = value) }
    fun setTextColor(value: Int) = updateStyle { it.copy(textColor = value) }
    fun setTickerColor(value: Int) = updateStyle { it.copy(tickerBackgroundColor = value) }
    fun setFontFamily(value: FontFamilyOption) = updateStyle { it.copy(fontFamily = value) }
    fun setFontStyle(value: FontStyleOption) = updateStyle { it.copy(fontStyle = value) }
    fun setHeadlineSize(value: HeadlineSizeOption) = updateStyle { it.copy(headlineSize = value) }
    fun setSponsorColumns(value: Int) = updateStyle { it.copy(sponsorColumns = value.coerceIn(1, 6)) }
    fun setSponsorMarqueeEnabled(value: Boolean) = updateStyle { it.copy(sponsorMarqueeEnabled = value) }
    fun setSponsorMarqueeInterval(value: MarqueeIntervalOption) = updateStyle { it.copy(sponsorMarqueeInterval = value) }
    fun setBreakingFlashEnabled(value: Boolean) = updateStyle { it.copy(breakingFlashEnabled = value) }
    fun setBreakingFlipEnabled(value: Boolean) = updateStyle { it.copy(breakingFlipEnabled = value) }
    fun setBreakingBadge3dEnabled(value: Boolean) = updateStyle { it.copy(breakingBadge3dEnabled = value) }
    fun setBreakingInterval(value: MarqueeIntervalOption) = updateStyle { it.copy(breakingInterval = value) }

    fun setTextBoxTextColor(target: TextTarget, value: Int) = updateTextStyle(target) { it.copy(textColor = value) }
    fun setTextBoxBackgroundColor(target: TextTarget, value: Int) = updateTextStyle(target) { it.copy(backgroundColor = value) }
    fun setTextBoxBackgroundEnabled(target: TextTarget, value: Boolean) = updateTextStyle(target) { it.copy(backgroundEnabled = value) }
    fun setTextBoxFontFamily(target: TextTarget, value: FontFamilyOption) = updateTextStyle(target) { it.copy(fontFamily = value) }
    fun setTextBoxFontStyle(target: TextTarget, value: FontStyleOption) = updateTextStyle(target) { it.copy(fontStyle = value) }
    fun setTextBoxSizeScale(target: TextTarget, value: Float) = updateTextStyle(target) { it.copy(sizeScale = value.coerceIn(0.55f, 2.0f)) }
    fun setTextBoxAlignment(target: TextTarget, value: TextAlignmentOption) = updateTextStyle(target) { it.copy(alignment = value) }

    private fun updateStyle(block: (TemplateStyle) -> TemplateStyle) = _state.update { it.copy(style = block(it.style)) }
    private fun updateTextStyle(target: TextTarget, block: (TextBoxStyle) -> TextBoxStyle) = _state.update { current ->
        val existing = current.textStyle(target)
        current.copy(textStyles = current.textStyles + (target to block(existing)))
    }

    fun applySavedTheme(theme: SavedTheme) = _state.update {
        it.copy(
            aspectRatio = theme.aspectRatio,
            layoutPreset = CliporaRules.normalizeLayout(theme.aspectRatio, theme.layoutPreset),
            style = theme.style,
            textStyles = theme.textStyles,
            logoText = theme.logoText,
            channelLogoUri = theme.channelLogoUri,
            watermarkLogoUri = theme.watermarkLogoUri,
            bannerText = theme.bannerText,
            breakingItems = theme.breakingItems,
            liveLabel = theme.liveLabel,
            marqueeInterval = theme.marqueeInterval,
            mediaRevision = it.mediaRevision + 1
        )
    }

    fun addSponsorText() = _state.update { current ->
        if (current.sponsors.size == 1 &&
            current.sponsors.first().kind == SponsorKind.TEXT &&
            current.sponsors.first().text in setOf("YOUR ADVERTISEMENT BANNER", "YOUR ADVERTISEMENT")
        ) {
            current.copy(
                sponsors = listOf(
                    current.sponsors.first().copy(text = "NEW TEXT")
                ),
                isUsingDemoContent = false
            )
        } else if (current.sponsors.size >= CliporaRules.MAX_AD_BANNERS) {
            current
        } else {
            val updated = current.sponsors + SponsorItem(nextSponsorId++, SponsorKind.TEXT, "NEW TEXT")
            current.copy(
                sponsors = updated,
                style = current.style.copy(sponsorMarqueeEnabled = CliporaRules.shouldRotateAdvertisements(updated.size)),
                isUsingDemoContent = false
            )
        }
    }

    fun addSponsorLogo() = _state.update { current ->
        if (current.sponsors.size == 1 &&
            current.sponsors.first().kind == SponsorKind.TEXT &&
            current.sponsors.first().text in setOf("YOUR ADVERTISEMENT BANNER", "YOUR ADVERTISEMENT")
        ) {
            current.copy(
                sponsors = listOf(
                    current.sponsors.first().copy(kind = SponsorKind.LOGO, text = "LOGO", imageUri = null)
                ),
                isUsingDemoContent = false
            )
        } else if (current.sponsors.size >= CliporaRules.MAX_AD_BANNERS) {
            current
        } else {
            val updated = current.sponsors + SponsorItem(nextSponsorId++, SponsorKind.LOGO, "LOGO")
            current.copy(
                sponsors = updated,
                style = current.style.copy(sponsorMarqueeEnabled = CliporaRules.shouldRotateAdvertisements(updated.size)),
                isUsingDemoContent = false
            )
        }
    }

    fun removeSponsor(id: Int) = _state.update { current ->
        if (current.sponsors.size <= 1) current
        else {
            val updated = current.sponsors.filterNot { it.id == id }
            current.copy(
                sponsors = updated,
                style = current.style.copy(sponsorMarqueeEnabled = CliporaRules.shouldRotateAdvertisements(updated.size)),
                isUsingDemoContent = false
            )
        }
    }

    fun setSponsorText(id: Int, value: String) = _state.update { current ->
        current.copy(sponsors = current.sponsors.map { if (it.id == id) it.copy(text = value) else it }, isUsingDemoContent = false)
    }

    fun setSponsorLogo(id: Int, uri: String?) = _state.update { current ->
        current.copy(sponsors = current.sponsors.map {
            if (it.id == id) it.copy(kind = SponsorKind.LOGO, imageUri = uri) else it
        }, isUsingDemoContent = false)
    }

    fun clearSponsorLogo(id: Int) = _state.update { current ->
        current.copy(sponsors = current.sponsors.map {
            if (it.id == id) it.copy(imageUri = null) else it
        }, isUsingDemoContent = false)
    }

    fun setTrimStart(valueMs: Long) = _state.update { current ->
        val maxStart = (current.sourceDurationMs - 1_000L).coerceAtLeast(0L)
        current.copy(trimStartMs = valueMs.coerceIn(0L, maxStart))
    }

    fun setExportStatus(message: String?) = _state.update { it.copy(exportStatus = message) }
    fun setExportProgress(progress: Int?) = _state.update {
        it.copy(exportProgress = progress?.coerceIn(0, 100))
    }
    private fun EditorState.withDemoContent(preset: LayoutPreset): EditorState {
        val demo = CliporaRules.demoContent(preset)
        val top = (0 until CliporaRules.MAX_HEADLINE_ITEMS).map { index ->
            HeadlineItem(index + 1, demo.topHeadlines.getOrNull(index).orEmpty())
        }
        val lower = (0 until CliporaRules.MAX_LOWER_HEADLINE_ITEMS).map { index ->
            HeadlineItem(101 + index, demo.lowerHeadlines.getOrNull(index).orEmpty())
        }
        val breaking = demo.breakingLabels.take(CliporaRules.MAX_BREAKING_ITEMS).mapIndexed { index, value ->
            BreakingItem(index + 1, value)
        }.ifEmpty { listOf(BreakingItem(1, "BREAKING NEWS")) }
        val ticker = demo.tickerItems.take(CliporaRules.MAX_MARQUEE_ITEMS).mapIndexed { index, value ->
            MarqueeItem(index + 1, value)
        }.ifEmpty { listOf(MarqueeItem(1, "Latest news updates")) }
        val sponsors = if (CliporaRules.usesAdvertisementBanner(preset)) {
            listOf(SponsorItem(1, SponsorKind.TEXT, demo.advertisementText.ifBlank { "YOUR ADVERTISEMENT" }))
        } else {
            this.sponsors
        }
        return copy(
            location = demo.location,
            logoText = demo.logoText,
            headline = top.firstOrNull()?.text.orEmpty(),
            headlineItems = top,
            lowerHeadlineItems = lower,
            sidePanelText = demo.sideText,
            bannerText = breaking.first().text,
            breakingItems = breaking,
            marqueeItems = ticker,
            sponsors = sponsors,
            style = style.copy(
                breakingFlashEnabled = true,
                breakingFlipEnabled = true,
                breakingBadge3dEnabled = true,
                breakingInterval = MarqueeIntervalOption.EXTRA_LONG,
                sponsorMarqueeEnabled = false
            ),
            isUsingDemoContent = true
        )
    }

}
