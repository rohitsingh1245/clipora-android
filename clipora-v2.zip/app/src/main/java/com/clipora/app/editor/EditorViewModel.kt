package com.clipora.app.editor

import androidx.lifecycle.ViewModel
import com.clipora.app.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class EditorViewModel : ViewModel() {
    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()
    private var nextSponsorId = 10
    private var nextMarqueeId = 10

    fun setMediaUri(uri: String) = _state.update { current ->
        current.copy(
            mediaUri = uri,
            mediaRevision = current.mediaRevision + 1,
            trimStartMs = 0L,
            sourceDurationMs = 0L,
            exportStatus = null
        )
    }

    fun setSourceDuration(durationMs: Long) = _state.update { it.copy(sourceDurationMs = durationMs.coerceAtLeast(0L)) }
    fun setAspectRatio(value: AspectRatioOption) = _state.update { current ->
        current.copy(aspectRatio = value, mediaRevision = current.mediaRevision + 1, exportStatus = null)
    }
    fun setVideoScaleMode(value: VideoScaleMode) = _state.update { current ->
        current.copy(videoScaleMode = value, mediaRevision = current.mediaRevision + 1, exportStatus = null)
    }
    fun setDuration(value: DurationOption) = _state.update { it.copy(duration = value) }
    fun setTheme(value: ThemePreset) = _state.update { it.copy(theme = value, style = presetStyle(value)) }
    fun setLocation(value: String) = _state.update { it.copy(location = value) }
    fun setLogoText(value: String) = _state.update { it.copy(logoText = value) }
    fun setChannelLogoUri(value: String?) = _state.update { it.copy(channelLogoUri = value) }
    fun setHeadline(value: String) = _state.update { it.copy(headline = value) }
    fun setBannerText(value: String) = _state.update { it.copy(bannerText = value) }
    fun setWatermarkLogoUri(value: String?) = _state.update { it.copy(watermarkLogoUri = value) }
    fun setAdvertiserName(value: String) = _state.update { it.copy(advertiserName = value) }
    fun setContactText(value: String) = _state.update { it.copy(contactText = value) }
    fun setLiveLabel(value: String) = _state.update { it.copy(liveLabel = value) }
    fun setMarqueeInterval(value: MarqueeIntervalOption) = _state.update { it.copy(marqueeInterval = value) }

    fun addMarqueeLine() = _state.update { current ->
        if (current.marqueeItems.size >= 10) current
        else current.copy(marqueeItems = current.marqueeItems + MarqueeItem(nextMarqueeId++, "New news line"))
    }

    fun setMarqueeText(id: Int, value: String) = _state.update { current ->
        current.copy(marqueeItems = current.marqueeItems.map { if (it.id == id) it.copy(text = value) else it })
    }

    fun removeMarqueeLine(id: Int) = _state.update { current ->
        if (current.marqueeItems.size <= 1) current
        else current.copy(marqueeItems = current.marqueeItems.filterNot { it.id == id })
    }

    fun setBackgroundColor(value: Int) = updateStyle { it.copy(backgroundColor = value) }
    fun setBackgroundImageUri(value: String?) = updateStyle { it.copy(backgroundImageUri = value) }
    fun setBackgroundBlur(value: Float) = updateStyle { it.copy(backgroundBlur = value.coerceIn(0f, 30f)) }
    fun setAccentColor(value: Int) = updateStyle { it.copy(accentColor = value) }
    fun setTextColor(value: Int) = updateStyle { it.copy(textColor = value) }
    fun setTickerColor(value: Int) = updateStyle { it.copy(tickerBackgroundColor = value) }
    fun setFontFamily(value: FontFamilyOption) = updateStyle { it.copy(fontFamily = value) }
    fun setFontStyle(value: FontStyleOption) = updateStyle { it.copy(fontStyle = value) }
    fun setHeadlineSize(value: HeadlineSizeOption) = updateStyle { it.copy(headlineSize = value) }
    fun setSponsorColumns(value: Int) = updateStyle { it.copy(sponsorColumns = value.coerceIn(1, 6)) }
    fun setSponsorMarqueeEnabled(value: Boolean) = updateStyle { it.copy(sponsorMarqueeEnabled = value) }
    fun setSponsorMarqueeInterval(value: MarqueeIntervalOption) = updateStyle { it.copy(sponsorMarqueeInterval = value) }

    fun setTextBoxTextColor(target: TextTarget, value: Int) = updateTextStyle(target) { it.copy(textColor = value) }
    fun setTextBoxBackgroundColor(target: TextTarget, value: Int) = updateTextStyle(target) { it.copy(backgroundColor = value) }
    fun setTextBoxBackgroundEnabled(target: TextTarget, value: Boolean) = updateTextStyle(target) { it.copy(backgroundEnabled = value) }
    fun setTextBoxFontFamily(target: TextTarget, value: FontFamilyOption) = updateTextStyle(target) { it.copy(fontFamily = value) }
    fun setTextBoxFontStyle(target: TextTarget, value: FontStyleOption) = updateTextStyle(target) { it.copy(fontStyle = value) }
    fun setTextBoxSizeScale(target: TextTarget, value: Float) = updateTextStyle(target) { it.copy(sizeScale = value.coerceIn(0.55f, 2.0f)) }
    fun setTextBoxAlignment(target: TextTarget, value: TextAlignmentOption) = updateTextStyle(target) { it.copy(alignment = value) }

    private fun updateStyle(block: (TemplateStyle) -> TemplateStyle) = _state.update { it.copy(style = block(it.style)) }
    private fun updateTextStyle(target: TextTarget, block: (TextBoxStyle) -> TextBoxStyle) = _state.update { current ->
        val existing = current.textStyle(target)
        current.copy(textStyles = current.textStyles + (target to block(existing)))
    }

    fun applySavedTheme(theme: SavedTheme) = _state.update {
        it.copy(
            style = theme.style,
            textStyles = theme.textStyles,
            logoText = theme.logoText,
            channelLogoUri = theme.channelLogoUri,
            watermarkLogoUri = theme.watermarkLogoUri,
            bannerText = theme.bannerText,
            liveLabel = theme.liveLabel,
            marqueeInterval = theme.marqueeInterval
        )
    }

    fun addSponsorText() = _state.update { current ->
        if (current.sponsors.size >= 6) current
        else {
            val updated = current.sponsors + SponsorItem(nextSponsorId++, SponsorKind.TEXT, "NEW TEXT")
            current.copy(sponsors = updated, style = current.style.copy(sponsorColumns = updated.size.coerceAtMost(6)))
        }
    }

    fun addSponsorLogo() = _state.update { current ->
        if (current.sponsors.size >= 6) current
        else {
            val updated = current.sponsors + SponsorItem(nextSponsorId++, SponsorKind.LOGO, "LOGO")
            current.copy(sponsors = updated, style = current.style.copy(sponsorColumns = updated.size.coerceAtMost(6)))
        }
    }

    fun removeSponsor(id: Int) = _state.update { current ->
        val updated = current.sponsors.filterNot { it.id == id }
        current.copy(sponsors = updated, style = current.style.copy(sponsorColumns = updated.size.coerceIn(1, 6)))
    }

    fun setSponsorText(id: Int, value: String) = _state.update { current ->
        current.copy(sponsors = current.sponsors.map { if (it.id == id) it.copy(text = value) else it })
    }

    fun setSponsorLogo(id: Int, uri: String?) = _state.update { current ->
        current.copy(sponsors = current.sponsors.map {
            if (it.id == id) it.copy(kind = SponsorKind.LOGO, imageUri = uri) else it
        })
    }

    fun setTrimStart(valueMs: Long) = _state.update { current ->
        val maxStart = (current.sourceDurationMs - 1_000L).coerceAtLeast(0L)
        current.copy(trimStartMs = valueMs.coerceIn(0L, maxStart))
    }

    fun setExportStatus(message: String?) = _state.update { it.copy(exportStatus = message) }
}
