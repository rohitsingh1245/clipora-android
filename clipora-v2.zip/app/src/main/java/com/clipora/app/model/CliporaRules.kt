package com.clipora.app.model

data class FloatRectSpec(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
}

data class BreakingAnimationFrame(
    val labelIndex: Int,
    val rotationX: Float,
    val phase: Float,
    val inTransition: Boolean
)

object CliporaRules {
    const val MAX_BREAKING_ITEMS = 8
    const val MAX_HEADLINE_ITEMS = 3
    const val MAX_LOWER_HEADLINE_ITEMS = 5
    const val MAX_MARQUEE_ITEMS = 10
    const val MAX_AD_BANNERS = 10

    const val MIN_BREAKING_INTERVAL_MS = 2_000L
    const val MIN_AD_ROTATION_INTERVAL_MS = 500L
    const val LIVE_BLINK_INTERVAL_US = 500_000L
    const val BREAKING_TRANSITION_START = 0.76f

    const val VIDEO_GALLERY_PATH = "Movies/Clipora/Videos"
    const val IMAGE_GALLERY_PATH = "Pictures/Clipora/Images"
    const val THUMBNAIL_GALLERY_PATH = "Pictures/Clipora/Thumbnails"

    fun outputSize(aspect: AspectRatioOption): Pair<Int, Int> = when (aspect) {
        AspectRatioOption.PORTRAIT -> 1080 to 1920
        AspectRatioOption.LANDSCAPE -> 1920 to 1080
        AspectRatioOption.SQUARE -> 1080 to 1080
        AspectRatioOption.SOCIAL -> 1080 to 1350
    }

    fun fitDestinationRect(
        sourceWidth: Int,
        sourceHeight: Int,
        targetLeft: Float,
        targetTop: Float,
        targetRight: Float,
        targetBottom: Float
    ): FloatRectSpec {
        require(sourceWidth > 0 && sourceHeight > 0)
        val targetWidth = targetRight - targetLeft
        val targetHeight = targetBottom - targetTop
        require(targetWidth > 0f && targetHeight > 0f)

        val scale = minOf(
            targetWidth / sourceWidth.toFloat(),
            targetHeight / sourceHeight.toFloat()
        )
        val width = sourceWidth * scale
        val height = sourceHeight * scale
        val left = targetLeft + (targetWidth - width) / 2f
        val top = targetTop + (targetHeight - height) / 2f
        return FloatRectSpec(left, top, left + width, top + height)
    }

    fun fillSourceCropRect(
        sourceWidth: Int,
        sourceHeight: Int,
        targetRatio: Float
    ): FloatRectSpec {
        require(sourceWidth > 0 && sourceHeight > 0)
        require(targetRatio > 0f)
        val sourceRatio = sourceWidth.toFloat() / sourceHeight.toFloat()

        return if (sourceRatio > targetRatio) {
            val cropWidth = sourceHeight * targetRatio
            val left = (sourceWidth - cropWidth) / 2f
            FloatRectSpec(left, 0f, left + cropWidth, sourceHeight.toFloat())
        } else {
            val cropHeight = sourceWidth / targetRatio
            val top = (sourceHeight - cropHeight) / 2f
            FloatRectSpec(0f, top, sourceWidth.toFloat(), top + cropHeight)
        }
    }



    fun editableTextTargets(preset: LayoutPreset): List<TextTarget> = buildList {
        add(TextTarget.LOCATION)
        add(TextTarget.CHANNEL)
        if (usesTopHeadline(preset)) add(TextTarget.HEADLINE)
        if (usesLowerHeadline(preset)) add(TextTarget.BOTTOM_HEADLINE)
        if (usesSideText(preset)) add(TextTarget.SIDE_TEXT)
        if (usesBreakingBadge(preset)) add(TextTarget.BREAKING)
        if (usesAdvertisementBanner(preset) || preset == LayoutPreset.LANDSCAPE_SIDE_PANELS) add(TextTarget.SPONSOR)
        add(TextTarget.LIVE)
        add(TextTarget.TICKER)
    }

    fun supportsTimelineControls(mode: EditorMediaMode): Boolean =
        mode == EditorMediaMode.VIDEO

    fun supportsAnimationControls(mode: EditorMediaMode): Boolean =
        mode == EditorMediaMode.VIDEO

    fun maxEditableAdvertisementBanners(mode: EditorMediaMode): Int =
        if (mode == EditorMediaMode.VIDEO) MAX_AD_BANNERS else 1


    fun validLayouts(aspect: AspectRatioOption): List<LayoutPreset> =
        NewsLayoutEngine.presetsFor(aspect)

    fun defaultLayout(aspect: AspectRatioOption): LayoutPreset =
        NewsLayoutEngine.defaultPreset(aspect)

    fun normalizeLayout(aspect: AspectRatioOption, preset: LayoutPreset): LayoutPreset =
        NewsLayoutEngine.normalizePreset(aspect, preset)

    fun activeRotatingTextIndex(
        itemCount: Int,
        intervalMillis: Long,
        presentationTimeUs: Long
    ): Int {
        if (itemCount <= 0) return -1
        val intervalUs = intervalMillis.coerceAtLeast(500L) * 1_000L
        return ((presentationTimeUs.coerceAtLeast(0L) / intervalUs) % itemCount).toInt()
    }

    fun usesSideText(preset: LayoutPreset): Boolean =
        preset == LayoutPreset.LANDSCAPE_SIDE_TEXT

    fun usesSideImage(preset: LayoutPreset): Boolean =
        preset == LayoutPreset.LANDSCAPE_SIDE_IMAGE ||
            preset == LayoutPreset.LANDSCAPE_SIDE_PANELS

    fun usesAdvertisementBanner(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).adRect != null

    fun usesTopHeadline(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).headlineRect != null

    fun usesLowerHeadline(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).bottomHeadlineRect != null

    fun usesBreakingBadge(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).breakingBadgeRect != null

    fun shouldRenderAdvertisement(itemCount: Int): Boolean = itemCount > 0

    fun activeAdvertisementIndex(
        itemCount: Int,
        rotationEnabled: Boolean,
        intervalMillis: Long,
        presentationTimeUs: Long
    ): Int {
        if (itemCount <= 0) return -1
        if (!rotationEnabled || itemCount == 1) return 0
        val intervalUs = intervalMillis.coerceAtLeast(MIN_AD_ROTATION_INTERVAL_MS) * 1_000L
        return ((presentationTimeUs.coerceAtLeast(0L) / intervalUs) % itemCount).toInt()
    }

    fun breakingAnimationFrame(
        itemCount: Int,
        intervalMillis: Long,
        presentationTimeUs: Long,
        flipEnabled: Boolean
    ): BreakingAnimationFrame {
        if (itemCount <= 0) return BreakingAnimationFrame(-1, 0f, 0f, false)

        val intervalUs = intervalMillis.coerceAtLeast(MIN_BREAKING_INTERVAL_MS) * 1_000L
        val safeTimeUs = presentationTimeUs.coerceAtLeast(0L)
        val cycleIndex = (safeTimeUs / intervalUs).toInt()
        val phase = (safeTimeUs % intervalUs).toFloat() / intervalUs.toFloat()

        var labelIndex = cycleIndex % itemCount
        var rotationX = 0f
        var inTransition = false

        if (flipEnabled && phase >= BREAKING_TRANSITION_START) {
            val local = ((phase - BREAKING_TRANSITION_START) / (1f - BREAKING_TRANSITION_START))
                .coerceIn(0f, 1f)
            inTransition = true
            if (local < 0.5f) {
                rotationX = 180f * local
            } else {
                labelIndex = (labelIndex + 1) % itemCount
                rotationX = -180f * (1f - local)
            }
        }

        return BreakingAnimationFrame(labelIndex, rotationX, phase, inTransition)
    }

    fun isLiveVisible(presentationTimeUs: Long): Boolean =
        (presentationTimeUs.coerceAtLeast(0L) / LIVE_BLINK_INTERVAL_US) % 2L == 0L
}
