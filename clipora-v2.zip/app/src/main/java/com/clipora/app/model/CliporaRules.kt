package com.clipora.app.model

data class FloatRectSpec(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
}



data class DemoContent(
    val location: String,
    val logoText: String,
    val topHeadlines: List<String>,
    val lowerHeadlines: List<String>,
    val sideText: String,
    val breakingLabels: List<String>,
    val tickerItems: List<String>,
    val advertisementText: String
)

data class BreakingAnimationFrame(
    val labelIndex: Int,
    val rotationX: Float,
    val phase: Float,
    val inTransition: Boolean
)

data class PopupAnimationFrame(
    val itemIndex: Int,
    val alpha: Float,
    val scale: Float,
    val translationFraction: Float
)

object CliporaRules {
    const val MAX_BREAKING_ITEMS = 3
    const val MAX_HEADLINE_ITEMS = 3
    const val MAX_LOWER_HEADLINE_ITEMS = 5
    const val MAX_MARQUEE_ITEMS = 10
    const val MAX_AD_BANNERS = 10

    const val MIN_BREAKING_INTERVAL_MS = 2_000L
    const val MIN_AD_ROTATION_INTERVAL_MS = 500L
    const val LIVE_BLINK_INTERVAL_US = 500_000L
    const val BREAKING_TRANSITION_START = 0.76f

    const val VIDEO_GALLERY_PATH = "Movies/Clipora/Videos"
    const val IMAGE_GALLERY_PATH = "Pictures/Clipora/Images"
    const val THUMBNAIL_GALLERY_PATH = "Pictures/Clipora/Thumbnails"

    fun outputSize(aspect: AspectRatioOption): Pair<Int, Int> = when (aspect) {
        AspectRatioOption.PORTRAIT -> 1080 to 1920
        AspectRatioOption.LANDSCAPE -> 1920 to 1080
        AspectRatioOption.SQUARE -> 1080 to 1080
        AspectRatioOption.SOCIAL -> 1080 to 1350
    }

    fun thumbnailPositionMs(positionMs: Long, durationMs: Long): Long {
        val safePosition = positionMs.coerceAtLeast(0L)
        if (durationMs <= 0L) return safePosition
        return safePosition.coerceAtMost((durationMs - 1L).coerceAtLeast(0L))
    }

    fun demoContent(preset: LayoutPreset): DemoContent = when (preset) {
        LayoutPreset.SHORTS_CLASSIC -> DemoContent(
            location = "नई दिल्ली",
            logoText = "NEWS 24",
            topHeadlines = listOf(
                "भारत की बड़ी खबर",
                "देश-दुनिया की ताज़ा अपडेट",
                "पूरी रिपोर्ट कुछ ही पलों में"
            ),
            lowerHeadlines = listOf(
                "ताज़ा अपडेट", "ब्रेकिंग खबर", "विशेष रिपोर्ट", "ग्राउंड रिपोर्ट", "अभी-अभी"
            ),
            sideText = "",
            breakingLabels = listOf("BREAKING NEWS", "EXCLUSIVE", "SPECIAL REPORT"),
            tickerItems = listOf("ताज़ा खबरें लगातार आपके साथ", "देश और दुनिया की बड़ी खबरें"),
            advertisementText = "YOUR ADVERTISEMENT"
        )

        LayoutPreset.LANDSCAPE_CLASSIC -> DemoContent(
            location = "NOIDA",
            logoText = "NEWS LIVE",
            topHeadlines = listOf(
                "सेहत से जुड़ी बड़ी खबर",
                "डॉक्टरों ने दी अहम सलाह",
                "पूरी रिपोर्ट देखें"
            ),
            lowerHeadlines = listOf(
                "अस्पताल में नई सुविधा शुरू",
                "विशेषज्ञों की बड़ी सलाह",
                "मरीजों को मिलेगी राहत",
                "स्वास्थ्य विभाग की नई पहल",
                "पूरी खबर के लिए जुड़े रहें"
            ),
            sideText = "",
            breakingLabels = listOf("BREAKING NEWS", "EXCLUSIVE", "SPECIAL REPORT"),
            tickerItems = listOf("LIVE अपडेट लगातार जारी", "देश-दुनिया की बड़ी खबरें"),
            advertisementText = ""
        )

        LayoutPreset.LANDSCAPE_SIDE_TEXT -> DemoContent(
            location = "LUCKNOW",
            logoText = "NEWS 24",
            topHeadlines = emptyList(),
            lowerHeadlines = listOf(
                "बड़ी खबर पर हमारी खास रिपोर्ट",
                "जमीनी हकीकत सामने आई",
                "लोगों ने रखी अपनी बात",
                "प्रशासन ने दिया जवाब",
                "पूरी खबर देखें"
            ),
            sideText = "मुख्य खबर से जुड़ी जरूरी जानकारी यहाँ लिखें। यह हिस्सा वीडियो के साथ कहानी को समझाने के लिए है।",
            breakingLabels = emptyList(),
            tickerItems = listOf("ताज़ा अपडेट", "ब्रेकिंग न्यूज़ लगातार"),
            advertisementText = ""
        )

        LayoutPreset.LANDSCAPE_SIDE_IMAGE -> DemoContent(
            location = "DELHI",
            logoText = "NEWS 24",
            topHeadlines = emptyList(),
            lowerHeadlines = listOf(
                "आज की सबसे बड़ी खबर",
                "तस्वीरों में पूरी कहानी",
                "विशेष रिपोर्ट",
                "ग्राउंड से अपडेट",
                "हमारे साथ जुड़े रहें"
            ),
            sideText = "",
            breakingLabels = emptyList(),
            tickerItems = listOf("LIVE न्यूज़ अपडेट", "नई जानकारी मिलते ही सबसे पहले"),
            advertisementText = ""
        )

        LayoutPreset.LANDSCAPE_SIDE_PANELS -> DemoContent(
            location = "MUMBAI",
            logoText = "NEWS LIVE",
            topHeadlines = listOf(
                "आज की बड़ी खबर",
                "दोनों पक्षों की तस्वीर",
                "विशेष रिपोर्ट"
            ),
            lowerHeadlines = listOf(
                "दोनों तरफ की जानकारी एक साथ",
                "मौके से बड़ी अपडेट",
                "विशेषज्ञों की राय",
                "नए तथ्य सामने आए",
                "पूरी खबर देखें"
            ),
            sideText = "",
            breakingLabels = emptyList(),
            tickerItems = listOf("LIVE अपडेट", "देश-दुनिया की खबरें"),
            advertisementText = ""
        )

        LayoutPreset.SQUARE_CLASSIC -> DemoContent(
            location = "नई दिल्ली",
            logoText = "NEWS",
            topHeadlines = listOf(
                "आज की बड़ी खबर",
                "सोशल मीडिया पर चर्चा",
                "पूरी जानकारी देखें"
            ),
            lowerHeadlines = listOf("ताज़ा अपडेट", "विशेष रिपोर्ट", "ब्रेकिंग न्यूज़", "मुख्य खबर", "अभी-अभी"),
            sideText = "",
            breakingLabels = listOf("BREAKING NEWS", "EXCLUSIVE", "SPECIAL REPORT"),
            tickerItems = listOf("ताज़ा अपडेट लगातार", "मुख्य खबरें आपके साथ"),
            advertisementText = "YOUR ADVERTISEMENT"
        )

        LayoutPreset.SOCIAL_FEED -> DemoContent(
            location = "नई दिल्ली",
            logoText = "NEWS LIVE",
            topHeadlines = listOf(
                "फेसबुक और इंस्टाग्राम की बड़ी खबर",
                "आज की सबसे अहम अपडेट",
                "पूरी खबर वीडियो में"
            ),
            lowerHeadlines = listOf("ताज़ा अपडेट", "विशेष रिपोर्ट", "ब्रेकिंग न्यूज़", "ग्राउंड रिपोर्ट", "अभी-अभी"),
            sideText = "",
            breakingLabels = listOf("BREAKING NEWS", "EXCLUSIVE", "SPECIAL REPORT"),
            tickerItems = listOf("LIVE अपडेट लगातार", "नई खबरों के लिए जुड़े रहें"),
            advertisementText = "YOUR ADVERTISEMENT"
        )
    }

    fun shouldRotateAdvertisements(itemCount: Int): Boolean = itemCount > 1

    fun fitDestinationRect(
        sourceWidth: Int,
        sourceHeight: Int,
        targetLeft: Float,
        targetTop: Float,
        targetRight: Float,
        targetBottom: Float
    ): FloatRectSpec {
        require(sourceWidth > 0 && sourceHeight > 0)
        val targetWidth = targetRight - targetLeft
        val targetHeight = targetBottom - targetTop
        require(targetWidth > 0f && targetHeight > 0f)

        val scale = minOf(
            targetWidth / sourceWidth.toFloat(),
            targetHeight / sourceHeight.toFloat()
        )
        val width = sourceWidth * scale
        val height = sourceHeight * scale
        val left = targetLeft + (targetWidth - width) / 2f
        val top = targetTop + (targetHeight - height) / 2f
        return FloatRectSpec(left, top, left + width, top + height)
    }

    fun fillSourceCropRect(
        sourceWidth: Int,
        sourceHeight: Int,
        targetRatio: Float
    ): FloatRectSpec {
        require(sourceWidth > 0 && sourceHeight > 0)
        require(targetRatio > 0f)
        val sourceRatio = sourceWidth.toFloat() / sourceHeight.toFloat()

        return if (sourceRatio > targetRatio) {
            val cropWidth = sourceHeight * targetRatio
            val left = (sourceWidth - cropWidth) / 2f
            FloatRectSpec(left, 0f, left + cropWidth, sourceHeight.toFloat())
        } else {
            val cropHeight = sourceWidth / targetRatio
            val top = (sourceHeight - cropHeight) / 2f
            FloatRectSpec(0f, top, sourceWidth.toFloat(), top + cropHeight)
        }
    }



    fun editableTextTargets(preset: LayoutPreset): List<TextTarget> = buildList {
        add(TextTarget.LOCATION)
        add(TextTarget.CHANNEL)
        if (usesTopHeadline(preset)) add(TextTarget.HEADLINE)
        if (usesLowerHeadline(preset)) add(TextTarget.BOTTOM_HEADLINE)
        if (usesSideText(preset)) add(TextTarget.SIDE_TEXT)
        if (usesBreakingBadge(preset)) add(TextTarget.BREAKING)
        if (usesAdvertisementBanner(preset) || preset == LayoutPreset.LANDSCAPE_SIDE_PANELS) add(TextTarget.SPONSOR)
        add(TextTarget.LIVE)
        add(TextTarget.TICKER)
    }

    fun supportsTimelineControls(mode: EditorMediaMode): Boolean =
        mode == EditorMediaMode.VIDEO

    fun supportsAnimationControls(mode: EditorMediaMode): Boolean =
        mode == EditorMediaMode.VIDEO

    fun maxEditableAdvertisementBanners(mode: EditorMediaMode): Int =
        if (mode == EditorMediaMode.VIDEO) MAX_AD_BANNERS else 1


    fun validLayouts(aspect: AspectRatioOption): List<LayoutPreset> =
        NewsLayoutEngine.presetsFor(aspect)

    fun defaultLayout(aspect: AspectRatioOption): LayoutPreset =
        NewsLayoutEngine.defaultPreset(aspect)

    fun normalizeLayout(aspect: AspectRatioOption, preset: LayoutPreset): LayoutPreset =
        NewsLayoutEngine.normalizePreset(aspect, preset)

    fun activeRotatingTextIndex(
        itemCount: Int,
        intervalMillis: Long,
        presentationTimeUs: Long
    ): Int {
        if (itemCount <= 0) return -1
        val intervalUs = intervalMillis.coerceAtLeast(500L) * 1_000L
        return ((presentationTimeUs.coerceAtLeast(0L) / intervalUs) % itemCount).toInt()
    }

    fun popupAnimationFrame(
        itemCount: Int,
        intervalMillis: Long,
        presentationTimeUs: Long
    ): PopupAnimationFrame {
        if (itemCount <= 0) return PopupAnimationFrame(-1, 0f, .94f, .35f)
        val intervalUs = intervalMillis.coerceAtLeast(500L) * 1_000L
        val safeTime = presentationTimeUs.coerceAtLeast(0L)
        val itemIndex = ((safeTime / intervalUs) % itemCount).toInt()
        val phase = (safeTime % intervalUs).toFloat() / intervalUs.toFloat()
        val visibility = when {
            phase < .12f -> (phase / .12f).coerceIn(0f, 1f)
            phase > .90f -> ((1f - phase) / .10f).coerceIn(0f, 1f)
            else -> 1f
        }
        return PopupAnimationFrame(
            itemIndex = itemIndex,
            alpha = visibility,
            scale = .94f + .06f * visibility,
            translationFraction = (1f - visibility) * .30f
        )
    }

    fun panelMaskSize(
        aspect: AspectRatioOption,
        preset: LayoutPreset,
        isLeft: Boolean = false
    ): Pair<Int, Int>? {
        val spec = NewsLayoutEngine.spec(aspect, preset)
        val rect = if (isLeft) spec.leftPanelRect else spec.rightPanelRect
        rect ?: return null
        val (w, h) = outputSize(aspect)
        return kotlin.math.round(rect.width * w).toInt() to kotlin.math.round(rect.height * h).toInt()
    }

    fun logoMaskSize(aspect: AspectRatioOption, preset: LayoutPreset): Pair<Int, Int> =
        rectPixelSize(NewsLayoutEngine.spec(aspect, preset).logoRect, aspect)

    fun advertisementMaskSize(aspect: AspectRatioOption, preset: LayoutPreset): Pair<Int, Int>? =
        NewsLayoutEngine.spec(aspect, preset).adRect?.let { rectPixelSize(it, aspect) }

    fun backgroundCanvasSize(aspect: AspectRatioOption): Pair<Int, Int> = outputSize(aspect)

    private fun rectPixelSize(rect: NormalizedRect, aspect: AspectRatioOption): Pair<Int, Int> {
        val (w, h) = outputSize(aspect)
        return kotlin.math.round(rect.width * w).toInt() to kotlin.math.round(rect.height * h).toInt()
    }

    fun marqueeGapSpaces(interval: MarqueeIntervalOption): Int = when {
        interval.millis <= 500L -> 8
        interval.millis <= 1_000L -> 16
        interval.millis <= 2_000L -> 28
        interval.millis <= 3_000L -> 40
        else -> 56
    }

    fun usesSideText(preset: LayoutPreset): Boolean =
        preset == LayoutPreset.LANDSCAPE_SIDE_TEXT

    fun usesSideImage(preset: LayoutPreset): Boolean =
        preset == LayoutPreset.LANDSCAPE_SIDE_IMAGE ||
            preset == LayoutPreset.LANDSCAPE_SIDE_PANELS

    fun usesAdvertisementBanner(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).adRect != null

    fun usesTopHeadline(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).headlineRect != null

    fun usesLowerHeadline(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).bottomHeadlineRect != null

    fun usesBreakingBadge(preset: LayoutPreset): Boolean =
        NewsLayoutEngine.spec(preset.aspect, preset).breakingBadgeRect != null

    fun shouldRenderAdvertisement(itemCount: Int): Boolean = itemCount > 0

    fun activeAdvertisementIndex(
        itemCount: Int,
        rotationEnabled: Boolean,
        intervalMillis: Long,
        presentationTimeUs: Long
    ): Int {
        if (itemCount <= 0) return -1
        if (!rotationEnabled || itemCount == 1) return 0
        val intervalUs = intervalMillis.coerceAtLeast(MIN_AD_ROTATION_INTERVAL_MS) * 1_000L
        return ((presentationTimeUs.coerceAtLeast(0L) / intervalUs) % itemCount).toInt()
    }

    fun breakingAnimationFrame(
        itemCount: Int,
        intervalMillis: Long,
        presentationTimeUs: Long,
        flipEnabled: Boolean
    ): BreakingAnimationFrame {
        if (itemCount <= 0) return BreakingAnimationFrame(-1, 0f, 0f, false)

        val intervalUs = intervalMillis.coerceAtLeast(MIN_BREAKING_INTERVAL_MS) * 1_000L
        val safeTimeUs = presentationTimeUs.coerceAtLeast(0L)
        val cycleIndex = (safeTimeUs / intervalUs).toInt()
        val phase = (safeTimeUs % intervalUs).toFloat() / intervalUs.toFloat()

        var labelIndex = cycleIndex % itemCount
        var rotationX = 0f
        var inTransition = false

        if (flipEnabled && phase >= BREAKING_TRANSITION_START) {
            val local = ((phase - BREAKING_TRANSITION_START) / (1f - BREAKING_TRANSITION_START))
                .coerceIn(0f, 1f)
            inTransition = true
            if (local < 0.5f) {
                rotationX = 180f * local
            } else {
                labelIndex = (labelIndex + 1) % itemCount
                rotationX = -180f * (1f - local)
            }
        }

        return BreakingAnimationFrame(labelIndex, rotationX, phase, inTransition)
    }

    fun isLiveVisible(presentationTimeUs: Long): Boolean =
        (presentationTimeUs.coerceAtLeast(0L) / LIVE_BLINK_INTERVAL_US) % 2L == 0L
}
