package com.clipora.app.media

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.clipora.app.model.*

class NewsTemplateRenderer(private val context: Context) {

    fun render(state: EditorState, width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val themeStyle = state.style
        val rows = rowRects(width, height)

        val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.backgroundColor }
        val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.accentColor }
        val secondary = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.secondaryColor }
        val ticker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.tickerBackgroundColor }
        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = themeStyle.borderColor
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.004f).coerceAtLeast(2f)
        }

        // Row 1: location + channel branding
        canvas.drawRect(rows[0], background)
        val locationBox = RectF(rows[0].left + width * .02f, rows[0].top + height * .008f,
            rows[0].left + width * .34f, rows[0].bottom - height * .008f)
        canvas.drawRoundRect(locationBox, 10f, 10f, accent)
        drawText(canvas, state.location, locationBox, width * .032f, themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)

        val logoBox = RectF(rows[0].right - width * .31f, rows[0].top + height * .006f,
            rows[0].right - width * .02f, rows[0].bottom - height * .006f)
        if (!state.channelLogoUri.isNullOrBlank()) {
            if (!drawUriImage(canvas, state.channelLogoUri, logoBox)) {
                drawText(canvas, state.logoText, logoBox, width * .034f, themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)
            }
        } else {
            drawText(canvas, state.logoText, logoBox, width * .034f, themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)
        }

        // Row 2: main headline
        canvas.drawRect(rows[1], background)
        canvas.drawLine(rows[1].left, rows[1].bottom, rows[1].right, rows[1].bottom, border)
        drawText(
            canvas,
            state.headline,
            rows[1].padded(width * .035f, height * .006f),
            width * .052f * themeStyle.headlineSize.scale,
            themeStyle.textColor,
            themeStyle,
            Layout.Alignment.ALIGN_CENTER
        )

        // Row 3: breaking/exclusive banner
        canvas.drawRect(rows[2], accent)
        val bannerInset = rows[2].padded(width * .08f, height * .004f)
        canvas.drawRoundRect(bannerInset, 10f, 10f, secondary)
        drawText(canvas, state.bannerText, bannerInset, width * .044f, Color.WHITE, themeStyle, Layout.Alignment.ALIGN_CENTER)

        // Row 4: main video/image area stays transparent. Only watermark/logo overlays it.
        canvas.drawRect(rows[3], border)
        if (!state.watermarkLogoUri.isNullOrBlank()) {
            val watermark = RectF(
                rows[3].right - width * .24f,
                rows[3].top + height * .012f,
                rows[3].right - width * .025f,
                rows[3].top + height * .075f
            )
            drawUriImage(canvas, state.watermarkLogoUri, watermark)
        }

        // Row 5: advertiser/shop name
        canvas.drawRect(rows[4], background)
        drawText(canvas, state.advertiserName, rows[4].padded(width * .02f, height * .004f), width * .041f,
            themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)

        // Row 6: dynamic sponsor/offer columns
        canvas.drawRect(rows[5], white)
        val sponsorItems = state.sponsors.take(6)
        if (sponsorItems.isNotEmpty()) {
            val columns = sponsorItems.size
            val columnWidth = rows[5].width() / columns
            sponsorItems.forEachIndexed { index, item ->
                val cell = RectF(
                    rows[5].left + columnWidth * index,
                    rows[5].top,
                    rows[5].left + columnWidth * (index + 1),
                    rows[5].bottom
                )
                canvas.drawRect(cell, border)
                if (item.kind == SponsorKind.LOGO && !item.imageUri.isNullOrBlank()) {
                    if (!drawUriImage(canvas, item.imageUri, cell.padded(width * .012f, height * .006f))) {
                        drawText(canvas, item.text, cell.padded(width * .008f, height * .004f), width * .028f,
                            Color.DKGRAY, themeStyle, Layout.Alignment.ALIGN_CENTER)
                    }
                } else {
                    if (index == 0) canvas.drawRect(cell.padded(width * .006f, height * .006f), secondary)
                    drawText(canvas, item.text, cell.padded(width * .008f, height * .004f), width * .030f,
                        Color.rgb(25, 25, 25), themeStyle, Layout.Alignment.ALIGN_CENTER)
                }
            }
        }

        // Row 7: address/contact
        canvas.drawRect(rows[6], background)
        drawText(canvas, state.contactText, rows[6].padded(width * .02f, height * .003f), width * .027f,
            themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)

        // Row 8: live label + ticker
        canvas.drawRect(rows[7], ticker)
        val liveWidth = width * .20f
        val liveRect = RectF(rows[7].left, rows[7].top, rows[7].left + liveWidth, rows[7].bottom)
        canvas.drawRect(liveRect, accent)
        drawText(canvas, state.liveLabel, liveRect, width * .032f, Color.WHITE, themeStyle, Layout.Alignment.ALIGN_CENTER)
        val tickerRect = RectF(liveRect.right, rows[7].top, rows[7].right, rows[7].bottom)
        drawText(canvas, state.ticker, tickerRect.padded(width * .015f, 0f), width * .027f,
            themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_NORMAL)

        return bitmap
    }

    private fun rowRects(width: Int, height: Int): List<RectF> {
        val weights = floatArrayOf(.08f, .13f, .06f, .43f, .07f, .11f, .06f, .06f)
        var y = 0f
        return weights.map { weight ->
            val next = y + height * weight
            RectF(0f, y, width.toFloat(), next).also { y = next }
        }
    }

    private fun drawText(
        canvas: Canvas,
        text: String,
        rect: RectF,
        textSize: Float,
        color: Int,
        style: TemplateStyle,
        alignment: Layout.Alignment
    ) {
        if (text.isBlank() || rect.width() <= 1f || rect.height() <= 1f) return
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSize.coerceAtLeast(12f)
            typeface = typeface(style)
        }
        val layout = StaticLayout.Builder.obtain(text.trim(), 0, text.trim().length, paint, rect.width().toInt().coerceAtLeast(1))
            .setAlignment(alignment)
            .setIncludePad(false)
            .setLineSpacing(0f, 0.92f)
            .build()
        val dy = ((rect.height() - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left, rect.top + dy)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun typeface(style: TemplateStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun drawUriImage(canvas: Canvas, uriString: String?, rect: RectF): Boolean {
        if (uriString.isNullOrBlank()) return false
        return runCatching {
            val bitmap = context.contentResolver.openInputStream(Uri.parse(uriString)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            val src = Rect(0, 0, bitmap.width, bitmap.height)
            val dst = fitRect(bitmap.width, bitmap.height, rect)
            canvas.drawBitmap(bitmap, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            bitmap.recycle()
            true
        }.getOrDefault(false)
    }

    private fun fitRect(bitmapWidth: Int, bitmapHeight: Int, target: RectF): RectF {
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return target
        val scale = minOf(target.width() / bitmapWidth, target.height() / bitmapHeight)
        val w = bitmapWidth * scale
        val h = bitmapHeight * scale
        val left = target.centerX() - w / 2f
        val top = target.centerY() - h / 2f
        return RectF(left, top, left + w, top + h)
    }

    private fun RectF.padded(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right - dx, bottom - dy)
}
