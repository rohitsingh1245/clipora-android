package com.clipora.app.media

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.clipora.app.model.*

class NewsTemplateRenderer(private val context: Context) {

    fun render(state: EditorState, width: Int, height: Int, includeTickerText: Boolean = true): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val themeStyle = state.style
        val sections = sectionRects(width, height)

        val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.backgroundColor }
        val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.accentColor }
        val secondary = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.secondaryColor }
        val ticker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = themeStyle.tickerBackgroundColor }
        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val darkText = Color.rgb(30, 30, 30)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = themeStyle.borderColor
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.004f).coerceAtLeast(2f)
        }
        val darkBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = themeStyle.backgroundColor
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.003f).coerceAtLeast(2f)
        }

        // Section 1: location + channel branding.
        canvas.drawRect(sections[0], background)
        val locationBox = RectF(
            sections[0].left + width * .02f,
            sections[0].top + height * .008f,
            sections[0].left + width * .34f,
            sections[0].bottom - height * .008f
        )
        canvas.drawRoundRect(locationBox, 10f, 10f, accent)
        drawText(canvas, state.location, locationBox, width * .032f, themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)

        val logoBox = RectF(
            sections[0].right - width * .31f,
            sections[0].top + height * .006f,
            sections[0].right - width * .02f,
            sections[0].bottom - height * .006f
        )
        if (!state.channelLogoUri.isNullOrBlank()) {
            if (!drawUriImage(canvas, state.channelLogoUri, logoBox)) {
                drawText(canvas, state.logoText, logoBox, width * .034f, themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)
            }
        } else {
            drawText(canvas, state.logoText, logoBox, width * .034f, themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_CENTER)
        }

        // Section 2: headline.
        canvas.drawRect(sections[1], background)
        canvas.drawLine(sections[1].left, sections[1].bottom, sections[1].right, sections[1].bottom, border)
        drawText(
            canvas,
            state.headline,
            sections[1].padded(width * .035f, height * .006f),
            width * .052f * themeStyle.headlineSize.scale,
            themeStyle.textColor,
            themeStyle,
            Layout.Alignment.ALIGN_CENTER
        )

        // Section 3: inset media frame. The underlying source video/image remains visible only inside the frame.
        val mediaSection = sections[2]
        val sideInset = width * .045f
        val frame = RectF(
            mediaSection.left + sideInset,
            mediaSection.top + height * .004f,
            mediaSection.right - sideInset,
            mediaSection.bottom - height * .004f
        )
        canvas.drawRect(RectF(mediaSection.left, mediaSection.top, frame.left, mediaSection.bottom), background)
        canvas.drawRect(RectF(frame.right, mediaSection.top, mediaSection.right, mediaSection.bottom), background)
        canvas.drawRect(frame, border)

        // BREAKING / EXCLUSIVE is a popup overlay on the video, not a separate layout row.
        val bannerHeight = (mediaSection.height() * .105f).coerceAtLeast(height * .035f)
        val bannerRect = RectF(
            width * .19f,
            frame.top + height * .004f,
            width * .81f,
            frame.top + height * .004f + bannerHeight
        )
        canvas.drawRoundRect(bannerRect, 12f, 12f, secondary)
        canvas.drawRoundRect(bannerRect, 12f, 12f, darkBorder)
        drawText(canvas, state.bannerText, bannerRect.padded(width * .012f, height * .002f), width * .044f,
            Color.WHITE, themeStyle, Layout.Alignment.ALIGN_CENTER)

        if (!state.watermarkLogoUri.isNullOrBlank()) {
            val watermark = RectF(
                frame.right - width * .23f,
                bannerRect.bottom + height * .008f,
                frame.right - width * .018f,
                bannerRect.bottom + height * .072f
            )
            drawUriImage(canvas, state.watermarkLogoUri, watermark)
        }

        // Section 4: one unified white advertisement panel.
        val ad = sections[3]
        canvas.drawRect(ad, white)
        canvas.drawRect(ad, darkBorder)
        val titleBottom = ad.top + ad.height() * .30f
        val sponsorBottom = ad.top + ad.height() * .74f
        val adTitle = RectF(ad.left, ad.top, ad.right, titleBottom)
        val sponsorRow = RectF(ad.left, titleBottom, ad.right, sponsorBottom)
        val contact = RectF(ad.left, sponsorBottom, ad.right, ad.bottom)

        drawText(
            canvas,
            state.advertiserName,
            adTitle.padded(width * .02f, height * .003f),
            width * .041f,
            themeStyle.accentColor,
            themeStyle,
            Layout.Alignment.ALIGN_CENTER
        )

        val sponsorItems = state.sponsors.take(themeStyle.sponsorColumns.coerceIn(1, 6))
        if (sponsorItems.isNotEmpty()) {
            val columnWidth = sponsorRow.width() / sponsorItems.size
            sponsorItems.forEachIndexed { index, item ->
                val cell = RectF(
                    sponsorRow.left + columnWidth * index,
                    sponsorRow.top,
                    sponsorRow.left + columnWidth * (index + 1),
                    sponsorRow.bottom
                )
                if (index > 0) canvas.drawLine(cell.left, cell.top, cell.left, cell.bottom, darkBorder)
                if (item.kind == SponsorKind.LOGO && !item.imageUri.isNullOrBlank()) {
                    if (!drawUriImage(canvas, item.imageUri, cell.padded(width * .012f, height * .006f))) {
                        drawText(canvas, item.text, cell.padded(width * .008f, height * .004f), width * .028f,
                            darkText, themeStyle, Layout.Alignment.ALIGN_CENTER)
                    }
                } else {
                    if (index == 0) canvas.drawRect(cell.padded(width * .006f, height * .006f), secondary)
                    drawText(canvas, item.text, cell.padded(width * .008f, height * .004f), width * .030f,
                        darkText, themeStyle, Layout.Alignment.ALIGN_CENTER)
                }
            }
        }

        canvas.drawLine(contact.left, contact.top, contact.right, contact.top, darkBorder)
        drawText(
            canvas,
            state.contactText,
            contact.padded(width * .025f, height * .005f),
            width * .026f,
            darkText,
            themeStyle,
            Layout.Alignment.ALIGN_CENTER
        )

        // Section 5: independent bottom LIVE + ticker strip.
        canvas.drawRect(sections[4], ticker)
        val liveWidth = width * .20f
        val liveRect = RectF(sections[4].left, sections[4].top, sections[4].left + liveWidth, sections[4].bottom)
        canvas.drawRect(liveRect, accent)
        if (includeTickerText) {
            drawText(canvas, state.liveLabel, liveRect, width * .032f, Color.WHITE, themeStyle, Layout.Alignment.ALIGN_CENTER)
            val tickerRect = RectF(liveRect.right, sections[4].top, sections[4].right, sections[4].bottom)
            val firstTicker = state.marqueeItems.firstOrNull { it.text.isNotBlank() }?.text.orEmpty()
            drawText(canvas, firstTicker, tickerRect.padded(width * .015f, 0f), width * .027f,
                themeStyle.textColor, themeStyle, Layout.Alignment.ALIGN_NORMAL)
        }

        return bitmap
    }

    private fun sectionRects(width: Int, height: Int): List<RectF> {
        // Breaking News is intentionally not a row: it overlays the media frame.
        // Advertisement title, sponsors and contact share one white section.
        val weights = floatArrayOf(.08f, .13f, .465f, .26f, .065f)
        var y = 0f
        return weights.map { weight ->
            val next = y + height * weight
            RectF(0f, y, width.toFloat(), next).also { y = next }
        }
    }

    private fun drawText(
        canvas: Canvas,
        text: String,
        rect: RectF,
        textSize: Float,
        color: Int,
        style: TemplateStyle,
        alignment: Layout.Alignment
    ) {
        if (text.isBlank() || rect.width() <= 1f || rect.height() <= 1f) return
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSize.coerceAtLeast(12f)
            typeface = typeface(style)
        }
        val layout = StaticLayout.Builder.obtain(text.trim(), 0, text.trim().length, paint, rect.width().toInt().coerceAtLeast(1))
            .setAlignment(alignment)
            .setIncludePad(false)
            .setLineSpacing(0f, 0.92f)
            .build()
        val dy = ((rect.height() - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left, rect.top + dy)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun typeface(style: TemplateStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun drawUriImage(canvas: Canvas, uriString: String?, rect: RectF): Boolean {
        if (uriString.isNullOrBlank()) return false
        return runCatching {
            val bitmap = context.contentResolver.openInputStream(Uri.parse(uriString)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            val src = Rect(0, 0, bitmap.width, bitmap.height)
            val dst = fitRect(bitmap.width, bitmap.height, rect)
            canvas.drawBitmap(bitmap, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            bitmap.recycle()
            true
        }.getOrDefault(false)
    }

    private fun fitRect(bitmapWidth: Int, bitmapHeight: Int, target: RectF): RectF {
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return target
        val scale = minOf(target.width() / bitmapWidth, target.height() / bitmapHeight)
        val w = bitmapWidth * scale
        val h = bitmapHeight * scale
        val left = target.centerX() - w / 2f
        val top = target.centerY() - h / 2f
        return RectF(left, top, left + w, top + h)
    }

    private fun RectF.padded(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right - dx, bottom - dy)
}
