package com.clipora.app.media

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.clipora.app.model.*

class NewsTemplateRenderer(private val context: Context) {

    fun render(
        state: EditorState,
        width: Int,
        height: Int,
        includeTickerText: Boolean = true,
        includeSponsorContent: Boolean = true,
        includeBreakingContent: Boolean = true,
        includeHeadlineContent: Boolean = true,
        includeLowerHeadlineContent: Boolean = true
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val style = state.style
        val spec = NewsLayoutEngine.spec(state.aspectRatio, state.layoutPreset)
        val backgroundBitmap = loadBackgroundBitmap(style.backgroundImageUri, style.backgroundBlur)

        // Opaque full-canvas background; the only transparent hole is the media viewport.
        drawBackground(canvas, RectF(0f, 0f, width.toFloat(), height.toFloat()), style, backgroundBitmap)

        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = style.borderColor
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.003f).coerceAtLeast(2f)
        }
        val panelBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = style.borderColor
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.002f).coerceAtLeast(1.5f)
        }

        val locationRect = spec.locationRect.toAndroidRect(width, height)
        drawStyledText(
            canvas, state.location, locationRect,
            baseTextSize = minOf(width, height) * .033f,
            textStyle = state.textStyle(TextTarget.LOCATION),
            fallbackBackgroundColor = style.accentColor
        )

        val logoRect = spec.logoRect.toAndroidRect(width, height)
        if (!state.channelLogoUri.isNullOrBlank()) {
            if (!drawUriImage(canvas, state.channelLogoUri, logoRect)) {
                drawStyledText(canvas, state.logoText, logoRect, minOf(width, height) * .034f, state.textStyle(TextTarget.CHANNEL))
            }
        } else {
            drawStyledText(canvas, state.logoText, logoRect, minOf(width, height) * .034f, state.textStyle(TextTarget.CHANNEL))
        }

        spec.headlineRect?.let { normalized ->
            val rect = normalized.toAndroidRect(width, height)
            if (includeHeadlineContent) {
                val text = state.headlineItems.firstOrNull { it.text.isNotBlank() }?.text ?: state.headline
                drawStyledText(
                    canvas, text, rect,
                    minOf(width, height) * .050f,
                    state.textStyle(TextTarget.HEADLINE)
                )
            }
        }

        // Media viewport mask: source video/image can never leak outside this exact rectangle.
        val mediaRect = spec.videoRect.toAndroidRect(width, height)
        canvas.drawRect(
            mediaRect,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            }
        )
        canvas.drawRect(mediaRect, border)

        spec.breakingBadgeRect?.let { normalized ->
            if (includeBreakingContent) {
                val rect = normalized.toAndroidRect(width, height)
                val label = state.breakingItems.firstOrNull { it.text.isNotBlank() }?.text ?: state.bannerText
                drawBreakingBadge(canvas, state, rect, label, 255)
            }
        }

        if (!state.watermarkLogoUri.isNullOrBlank()) {
            val w = mediaRect.width() * .20f
            val h = mediaRect.height() * .11f
            drawUriImage(
                canvas,
                state.watermarkLogoUri,
                RectF(mediaRect.right - w - 8f, mediaRect.top + 8f, mediaRect.right - 8f, mediaRect.top + h + 8f)
            )
        }

        spec.rightPanelRect?.let { normalized ->
            val rect = normalized.toAndroidRect(width, height)
            drawPanel(canvas, state, rect, state.layoutPreset, isLeft = false)
            canvas.drawRect(rect, panelBorder)
        }
        spec.leftPanelRect?.let { normalized ->
            val rect = normalized.toAndroidRect(width, height)
            drawPanel(canvas, state, rect, state.layoutPreset, isLeft = true)
            canvas.drawRect(rect, panelBorder)
        }

        spec.bottomHeadlineRect?.let { normalized ->
            if (includeLowerHeadlineContent) {
                val rect = normalized.toAndroidRect(width, height)
                val text = state.lowerHeadlineItems.firstOrNull { it.text.isNotBlank() }?.text.orEmpty()
                drawStyledText(
                    canvas, text, rect,
                    minOf(width, height) * .034f,
                    state.textStyle(TextTarget.BOTTOM_HEADLINE),
                    fallbackBackgroundColor = style.accentColor
                )
            }
        }

        spec.adRect?.let { normalized ->
            val rect = normalized.toAndroidRect(width, height)
            canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            canvas.drawRect(rect, panelBorder)
            if (includeSponsorContent) drawSingleAdBanner(canvas, state, rect)
        }

        val tickerRect = spec.tickerRect.toAndroidRect(width, height)
        canvas.drawRect(tickerRect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = style.tickerBackgroundColor })
        val liveWidth = tickerRect.width() * .16f
        val liveRect = RectF(tickerRect.left, tickerRect.top, tickerRect.left + liveWidth, tickerRect.bottom)
        val liveStyle = state.textStyle(TextTarget.LIVE)
        val liveBg = if (liveStyle.backgroundEnabled) liveStyle.backgroundColor else style.accentColor
        canvas.drawRect(liveRect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = liveBg })

        if (includeTickerText) {
            drawStyledText(canvas, state.liveLabel, liveRect, minOf(width, height) * .028f, liveStyle, style.accentColor)
            val firstTicker = state.marqueeItems.firstOrNull { it.text.isNotBlank() }?.text.orEmpty()
            drawStyledText(
                canvas,
                firstTicker,
                RectF(liveRect.right + 4f, tickerRect.top, tickerRect.right, tickerRect.bottom),
                minOf(width, height) * .025f,
                state.textStyle(TextTarget.TICKER)
            )
        }

        backgroundBitmap?.recycle()
        return bitmap
    }

    private fun drawPanel(
        canvas: Canvas,
        state: EditorState,
        rect: RectF,
        preset: LayoutPreset,
        isLeft: Boolean
    ) {
        canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        when (preset) {
            LayoutPreset.LANDSCAPE_SIDE_TEXT -> {
                drawStyledText(
                    canvas,
                    state.sidePanelText,
                    rect.padded(rect.width() * .05f, rect.height() * .05f),
                    rect.width() * .085f,
                    state.textStyle(TextTarget.SIDE_TEXT)
                )
            }
            LayoutPreset.LANDSCAPE_SIDE_IMAGE -> {
                if (!drawUriImage(canvas, state.sidePanelImageUri, rect.padded(4f, 4f))) {
                    drawStyledText(
                        canvas, "Add side image", rect, rect.width() * .08f,
                        state.textStyle(TextTarget.SIDE_TEXT)
                    )
                }
            }
            LayoutPreset.LANDSCAPE_SIDE_PANELS -> {
                val banner = if (isLeft) state.sponsors.getOrNull(0) else state.sponsors.getOrNull(1)
                if (banner != null && banner.kind == SponsorKind.LOGO && !banner.imageUri.isNullOrBlank()) {
                    if (!drawUriImage(canvas, banner.imageUri, rect.padded(4f, 4f))) {
                        drawStyledText(canvas, banner.text, rect, rect.width() * .08f, state.textStyle(TextTarget.SPONSOR))
                    }
                } else {
                    drawStyledText(
                        canvas,
                        banner?.text ?: if (isLeft) "Left panel" else "Right panel",
                        rect,
                        rect.width() * .08f,
                        state.textStyle(TextTarget.SPONSOR)
                    )
                }
            }
            else -> Unit
        }
    }

    private fun NormalizedRect.toAndroidRect(width: Int, height: Int): RectF =
        RectF(left * width, top * height, right * width, bottom * height)

    private fun drawBreakingBadge(canvas: Canvas, state: EditorState, rect: RectF, text: String, alpha: Int) {
        if (text.isBlank()) return
        val textStyle = state.textStyle(TextTarget.BREAKING)
        val radius = rect.height() * .08f

        canvas.saveLayerAlpha(rect, alpha.coerceIn(0, 255))

        if (textStyle.backgroundEnabled) {
            if (state.style.breakingBadge3dEnabled) {
                val shadow = RectF(rect).apply { offset(0f, rect.height() * .10f) }
                canvas.drawRoundRect(
                    shadow,
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x70000000 }
                )

                val bg = textStyle.backgroundColor
                val gradient = LinearGradient(
                    rect.left,
                    rect.top,
                    rect.left,
                    rect.bottom,
                    intArrayOf(
                        lightenColor(bg, .34f),
                        bg,
                        darkenColor(bg, .18f),
                        darkenColor(bg, .42f)
                    ),
                    floatArrayOf(0f, .23f, .68f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(
                    rect,
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient }
                )

                canvas.drawRoundRect(
                    RectF(rect.left + 2f, rect.top + 2f, rect.right - 2f, rect.top + rect.height() * .20f),
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF }
                )
                canvas.drawRect(
                    RectF(
                        rect.left + rect.width() * .02f,
                        rect.bottom - rect.height() * .10f,
                        rect.right - rect.width() * .02f,
                        rect.bottom - rect.height() * .045f
                    ),
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000 }
                )
            } else {
                canvas.drawRoundRect(
                    rect,
                    radius,
                    radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color = textStyle.backgroundColor }
                )
            }
        }

        drawStyledText(
            canvas,
            text,
            rect.padded(rect.width() * .03f, rect.height() * .01f),
            rect.height() * .60f,
            textStyle.copy(backgroundEnabled = false)
        )
        canvas.restore()
    }

    private fun lightenColor(color: Int, amount: Float): Int {
        val a = amount.coerceIn(0f, 1f)
        return Color.argb(
            Color.alpha(color),
            (Color.red(color) + (255 - Color.red(color)) * a).toInt(),
            (Color.green(color) + (255 - Color.green(color)) * a).toInt(),
            (Color.blue(color) + (255 - Color.blue(color)) * a).toInt()
        )
    }

    private fun darkenColor(color: Int, amount: Float): Int {
        val factor = (1f - amount).coerceIn(0f, 1f)
        return Color.argb(
            Color.alpha(color),
            (Color.red(color) * factor).toInt(),
            (Color.green(color) * factor).toInt(),
            (Color.blue(color) * factor).toInt()
        )
    }

    private fun drawSingleAdBanner(canvas: Canvas, state: EditorState, adRect: RectF) {
        val item = state.sponsors.firstOrNull() ?: return
        val content = adRect.padded(adRect.width() * .012f, adRect.height() * .06f)
        if (item.kind == SponsorKind.LOGO && !item.imageUri.isNullOrBlank()) {
            if (!drawUriImage(canvas, item.imageUri, content)) {
                drawStyledText(canvas, item.text, content, adRect.height() * .28f, state.textStyle(TextTarget.SPONSOR))
            }
        } else {
            drawStyledText(canvas, item.text, content, adRect.height() * .28f, state.textStyle(TextTarget.SPONSOR))
        }
    }

    private fun drawStyledText(
        canvas: Canvas,
        text: String,
        rect: RectF,
        baseTextSize: Float,
        textStyle: TextBoxStyle,
        fallbackBackgroundColor: Int? = null
    ) {
        if (text.isBlank() || rect.width() <= 1f || rect.height() <= 1f) return
        if (textStyle.backgroundEnabled) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (textStyle.backgroundColor == 0 && fallbackBackgroundColor != null) fallbackBackgroundColor else textStyle.backgroundColor
            }
            canvas.drawRoundRect(rect, 10f, 10f, bg)
        }
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textStyle.textColor
            textSize = (baseTextSize * textStyle.sizeScale).coerceAtLeast(12f)
            typeface = typeface(textStyle)
        }
        val trimmed = text.trim()
        val alignment = when (textStyle.alignment) {
            TextAlignmentOption.START -> Layout.Alignment.ALIGN_NORMAL
            TextAlignmentOption.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignmentOption.END -> Layout.Alignment.ALIGN_OPPOSITE
        }
        val layout = StaticLayout.Builder.obtain(trimmed, 0, trimmed.length, paint, rect.width().toInt().coerceAtLeast(1))
            .setAlignment(alignment)
            .setIncludePad(false)
            .setLineSpacing(0f, 0.94f)
            .build()
        val dy = ((rect.height() - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left, rect.top + dy)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun typeface(style: TextBoxStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun loadBackgroundBitmap(uriString: String?, blur: Float): Bitmap? {
        if (uriString.isNullOrBlank()) return null
        return runCatching {
            val source = context.contentResolver.openInputStream(Uri.parse(uriString)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            if (blur <= 0.1f) source else {
                val divisor = (2f + blur / 3f).coerceIn(2f, 12f)
                val w = (source.width / divisor).toInt().coerceAtLeast(24)
                val h = (source.height / divisor).toInt().coerceAtLeast(24)
                val small = Bitmap.createScaledBitmap(source, w, h, true)
                source.recycle()
                small
            }
        }.getOrNull()
    }

    private fun drawBackground(canvas: Canvas, rect: RectF, style: TemplateStyle, bitmap: Bitmap?) {
        if (rect.width() <= 0f || rect.height() <= 0f) return
        if (bitmap == null) {
            canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = style.backgroundColor })
            return
        }
        val srcRatio = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
        val dstRatio = rect.width() / rect.height().coerceAtLeast(1f)
        val src = if (srcRatio > dstRatio) {
            val wantedW = (bitmap.height * dstRatio).toInt().coerceAtLeast(1)
            val left = ((bitmap.width - wantedW) / 2).coerceAtLeast(0)
            Rect(left, 0, (left + wantedW).coerceAtMost(bitmap.width), bitmap.height)
        } else {
            val wantedH = (bitmap.width / dstRatio).toInt().coerceAtLeast(1)
            val top = ((bitmap.height - wantedH) / 2).coerceAtLeast(0)
            Rect(0, top, bitmap.width, (top + wantedH).coerceAtMost(bitmap.height))
        }
        canvas.drawBitmap(bitmap, src, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawUriImage(canvas: Canvas, uriString: String?, rect: RectF): Boolean {
        if (uriString.isNullOrBlank()) return false
        return runCatching {
            val bitmap = context.contentResolver.openInputStream(Uri.parse(uriString)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            val src = Rect(0, 0, bitmap.width, bitmap.height)
            val dst = fitRect(bitmap.width, bitmap.height, rect)
            canvas.drawBitmap(bitmap, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            bitmap.recycle()
            true
        }.getOrDefault(false)
    }

    private fun fitRect(bitmapWidth: Int, bitmapHeight: Int, target: RectF): RectF {
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return target
        val scale = minOf(target.width() / bitmapWidth, target.height() / bitmapHeight)
        val w = bitmapWidth * scale
        val h = bitmapHeight * scale
        val left = target.centerX() - w / 2f
        val top = target.centerY() - h / 2f
        return RectF(left, top, left + w, top + h)
    }

    private fun RectF.padded(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right - dx, bottom - dy)
}
