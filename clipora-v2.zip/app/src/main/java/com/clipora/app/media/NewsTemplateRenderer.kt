package com.clipora.app.media

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.clipora.app.model.*

class NewsTemplateRenderer(private val context: Context) {

    fun render(
        state: EditorState,
        width: Int,
        height: Int,
        includeTickerText: Boolean = true,
        includeSponsorContent: Boolean = true
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val style = state.style
        val sections = sectionRects(width, height)
        val backgroundBitmap = loadBackgroundBitmap(style.backgroundImageUri, style.backgroundBlur)

        val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = style.accentColor }
        val ticker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = style.tickerBackgroundColor }
        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = style.borderColor
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.003f).coerceAtLeast(2f)
        }
        val darkBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 35)
            this.style = Paint.Style.STROKE
            strokeWidth = (width * 0.002f).coerceAtLeast(1.5f)
        }

        // 1. Header: editable background plus location/channel branding.
        drawBackground(canvas, sections[0], style, backgroundBitmap)
        val locationBox = RectF(
            sections[0].left + width * .02f,
            sections[0].top + height * .008f,
            sections[0].left + width * .34f,
            sections[0].bottom - height * .008f
        )
        drawStyledText(canvas, state.location, locationBox, width * .032f, state.textStyle(TextTarget.LOCATION), style.accentColor)

        val logoBox = RectF(
            sections[0].right - width * .31f,
            sections[0].top + height * .006f,
            sections[0].right - width * .02f,
            sections[0].bottom - height * .006f
        )
        if (!state.channelLogoUri.isNullOrBlank()) {
            if (!drawUriImage(canvas, state.channelLogoUri, logoBox)) {
                drawStyledText(canvas, state.logoText, logoBox, width * .034f, state.textStyle(TextTarget.CHANNEL))
            }
        } else {
            drawStyledText(canvas, state.logoText, logoBox, width * .034f, state.textStyle(TextTarget.CHANNEL))
        }

        // 2. Headline: intentionally plain; no forced border/box.
        drawBackground(canvas, sections[1], style, backgroundBitmap)
        drawStyledText(
            canvas,
            state.headline,
            sections[1].padded(width * .035f, height * .006f),
            width * .052f,
            state.textStyle(TextTarget.HEADLINE)
        )

        // 3. Inset media frame. Only gutters are painted, leaving the centre transparent for video/image.
        val mediaSection = sections[2]
        val sideInset = width * NewsLayoutMetrics.MEDIA_SIDE_INSET
        val frame = RectF(
            mediaSection.left + sideInset,
            mediaSection.top + height * .004f,
            mediaSection.right - sideInset,
            mediaSection.bottom - height * .004f
        )
        drawBackground(canvas, RectF(mediaSection.left, mediaSection.top, frame.left, mediaSection.bottom), style, backgroundBitmap)
        drawBackground(canvas, RectF(frame.right, mediaSection.top, mediaSection.right, mediaSection.bottom), style, backgroundBitmap)
        canvas.drawRect(frame, border)

        // BREAKING / EXCLUSIVE: bold red text by default, transparent unless the user enables a background.
        val bannerRect = RectF(
            width * .16f,
            frame.top + height * .006f,
            width * .84f,
            frame.top + height * .058f
        )
        drawStyledText(
            canvas,
            state.bannerText,
            bannerRect.padded(width * .008f, 0f),
            width * .042f,
            state.textStyle(TextTarget.BREAKING)
        )

        if (!state.watermarkLogoUri.isNullOrBlank()) {
            val watermark = RectF(
                frame.right - width * .23f,
                bannerRect.bottom + height * .006f,
                frame.right - width * .018f,
                bannerRect.bottom + height * .070f
            )
            drawUriImage(canvas, state.watermarkLogoUri, watermark)
        }

        // 4. Advertisement is one single banner area.
        // A user can upload one complete banner artwork; multiple banners can rotate during preview/export.
        val ad = sections[3]
        canvas.drawRect(ad, white)
        canvas.drawRect(ad, darkBorder)
        if (includeSponsorContent) {
            drawSingleAdBanner(canvas, state, ad)
        }

        // 5. Independent LIVE + news marquee strip.
        canvas.drawRect(sections[4], ticker)
        val liveWidth = width * .20f
        val liveRect = RectF(sections[4].left, sections[4].top, sections[4].left + liveWidth, sections[4].bottom)
        val liveStyle = state.textStyle(TextTarget.LIVE)
        val liveBg = if (liveStyle.backgroundEnabled) liveStyle.backgroundColor else style.accentColor
        canvas.drawRect(liveRect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = liveBg })
        if (includeTickerText) {
            drawStyledText(canvas, state.liveLabel, liveRect, width * .032f, liveStyle, style.accentColor)
            val tickerRect = RectF(liveRect.right, sections[4].top, sections[4].right, sections[4].bottom)
            val firstTicker = state.marqueeItems.firstOrNull { it.text.isNotBlank() }?.text.orEmpty()
            drawStyledText(
                canvas,
                firstTicker,
                tickerRect.padded(width * .015f, 0f),
                width * .027f,
                state.textStyle(TextTarget.TICKER)
            )
        }

        backgroundBitmap?.recycle()
        return bitmap
    }

    private fun drawSingleAdBanner(canvas: Canvas, state: EditorState, adRect: RectF) {
        val item = state.sponsors.firstOrNull() ?: return
        val content = adRect.padded(adRect.width() * .012f, adRect.height() * .06f)
        if (item.kind == SponsorKind.LOGO && !item.imageUri.isNullOrBlank()) {
            if (!drawUriImage(canvas, item.imageUri, content)) {
                drawStyledText(canvas, item.text, content, adRect.height() * .28f, state.textStyle(TextTarget.SPONSOR))
            }
        } else {
            drawStyledText(canvas, item.text, content, adRect.height() * .28f, state.textStyle(TextTarget.SPONSOR))
        }
    }

    private fun sectionRects(width: Int, height: Int): List<RectF> {
        val weights = floatArrayOf(
            NewsLayoutMetrics.HEADER,
            NewsLayoutMetrics.HEADLINE,
            NewsLayoutMetrics.MEDIA,
            NewsLayoutMetrics.AD,
            NewsLayoutMetrics.TICKER
        )
        var y = 0f
        return weights.map { weight ->
            val next = y + height * weight
            RectF(0f, y, width.toFloat(), next).also { y = next }
        }
    }

    private fun drawStyledText(
        canvas: Canvas,
        text: String,
        rect: RectF,
        baseTextSize: Float,
        textStyle: TextBoxStyle,
        fallbackBackgroundColor: Int? = null
    ) {
        if (text.isBlank() || rect.width() <= 1f || rect.height() <= 1f) return
        if (textStyle.backgroundEnabled) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (textStyle.backgroundColor == 0 && fallbackBackgroundColor != null) fallbackBackgroundColor else textStyle.backgroundColor
            }
            canvas.drawRoundRect(rect, 10f, 10f, bg)
        }
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textStyle.textColor
            textSize = (baseTextSize * textStyle.sizeScale).coerceAtLeast(12f)
            typeface = typeface(textStyle)
        }
        val trimmed = text.trim()
        val alignment = when (textStyle.alignment) {
            TextAlignmentOption.START -> Layout.Alignment.ALIGN_NORMAL
            TextAlignmentOption.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignmentOption.END -> Layout.Alignment.ALIGN_OPPOSITE
        }
        val layout = StaticLayout.Builder.obtain(trimmed, 0, trimmed.length, paint, rect.width().toInt().coerceAtLeast(1))
            .setAlignment(alignment)
            .setIncludePad(false)
            .setLineSpacing(0f, 0.94f)
            .build()
        val dy = ((rect.height() - layout.height) / 2f).coerceAtLeast(0f)
        canvas.save()
        canvas.clipRect(rect)
        canvas.translate(rect.left, rect.top + dy)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun typeface(style: TextBoxStyle): Typeface {
        val family = when (style.fontFamily) {
            FontFamilyOption.SANS -> Typeface.SANS_SERIF
            FontFamilyOption.SERIF -> Typeface.SERIF
            FontFamilyOption.MONOSPACE -> Typeface.MONOSPACE
        }
        val styleValue = when (style.fontStyle) {
            FontStyleOption.NORMAL -> Typeface.NORMAL
            FontStyleOption.BOLD -> Typeface.BOLD
            FontStyleOption.ITALIC -> Typeface.ITALIC
            FontStyleOption.BOLD_ITALIC -> Typeface.BOLD_ITALIC
        }
        return Typeface.create(family, styleValue)
    }

    private fun loadBackgroundBitmap(uriString: String?, blur: Float): Bitmap? {
        if (uriString.isNullOrBlank()) return null
        return runCatching {
            val source = context.contentResolver.openInputStream(Uri.parse(uriString)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            if (blur <= 0.1f) source else {
                val divisor = (2f + blur / 3f).coerceIn(2f, 12f)
                val w = (source.width / divisor).toInt().coerceAtLeast(24)
                val h = (source.height / divisor).toInt().coerceAtLeast(24)
                val small = Bitmap.createScaledBitmap(source, w, h, true)
                source.recycle()
                small
            }
        }.getOrNull()
    }

    private fun drawBackground(canvas: Canvas, rect: RectF, style: TemplateStyle, bitmap: Bitmap?) {
        if (rect.width() <= 0f || rect.height() <= 0f) return
        if (bitmap == null) {
            canvas.drawRect(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = style.backgroundColor })
            return
        }
        val srcRatio = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
        val dstRatio = rect.width() / rect.height().coerceAtLeast(1f)
        val src = if (srcRatio > dstRatio) {
            val wantedW = (bitmap.height * dstRatio).toInt().coerceAtLeast(1)
            val left = ((bitmap.width - wantedW) / 2).coerceAtLeast(0)
            Rect(left, 0, (left + wantedW).coerceAtMost(bitmap.width), bitmap.height)
        } else {
            val wantedH = (bitmap.width / dstRatio).toInt().coerceAtLeast(1)
            val top = ((bitmap.height - wantedH) / 2).coerceAtLeast(0)
            Rect(0, top, bitmap.width, (top + wantedH).coerceAtMost(bitmap.height))
        }
        canvas.drawBitmap(bitmap, src, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawUriImage(canvas: Canvas, uriString: String?, rect: RectF): Boolean {
        if (uriString.isNullOrBlank()) return false
        return runCatching {
            val bitmap = context.contentResolver.openInputStream(Uri.parse(uriString)).use { input ->
                requireNotNull(input)
                requireNotNull(BitmapFactory.decodeStream(input))
            }
            val src = Rect(0, 0, bitmap.width, bitmap.height)
            val dst = fitRect(bitmap.width, bitmap.height, rect)
            canvas.drawBitmap(bitmap, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            bitmap.recycle()
            true
        }.getOrDefault(false)
    }

    private fun fitRect(bitmapWidth: Int, bitmapHeight: Int, target: RectF): RectF {
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return target
        val scale = minOf(target.width() / bitmapWidth, target.height() / bitmapHeight)
        val w = bitmapWidth * scale
        val h = bitmapHeight * scale
        val left = target.centerX() - w / 2f
        val top = target.centerY() - h / 2f
        return RectF(left, top, left + w, top + h)
    }

    private fun RectF.padded(dx: Float, dy: Float): RectF = RectF(left + dx, top + dy, right - dx, bottom - dy)
}
