package com.clipora.app.media

object NewsLayoutMetrics {
    const val HEADER = 0.08f
    const val HEADLINE = 0.13f
    const val MEDIA = 0.57f
    const val AD = 0.155f
    const val TICKER = 0.065f

    const val MEDIA_SIDE_INSET = 0.045f

    fun adTop(height: Int): Float = height * (HEADER + HEADLINE + MEDIA)
    fun adBottom(height: Int): Float = height * (HEADER + HEADLINE + MEDIA + AD)
    fun sponsorTop(height: Int): Float = adTop(height)
    fun sponsorBottom(height: Int): Float = adBottom(height)
    fun tickerTop(height: Int): Float = height * (HEADER + HEADLINE + MEDIA + AD)
}
