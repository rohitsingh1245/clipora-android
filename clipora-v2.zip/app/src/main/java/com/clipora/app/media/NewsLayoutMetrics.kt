package com.clipora.app.media

object NewsLayoutMetrics {
    const val HEADER = 0.08f
    const val HEADLINE = 0.13f
    const val MEDIA = 0.52f
    const val AD = 0.205f
    const val TICKER = 0.065f

    const val AD_TITLE = 0.46f
    const val AD_SPONSOR = 0.24f
    const val AD_CONTACT = 0.30f

    const val MEDIA_SIDE_INSET = 0.045f

    fun adTop(height: Int): Float = height * (HEADER + HEADLINE + MEDIA)
    fun sponsorTop(height: Int): Float = adTop(height) + height * AD * AD_TITLE
    fun sponsorBottom(height: Int): Float = sponsorTop(height) + height * AD * AD_SPONSOR
    fun tickerTop(height: Int): Float = height * (HEADER + HEADLINE + MEDIA + AD)
}
