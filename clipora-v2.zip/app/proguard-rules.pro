# Clipora Phase 1 - no custom ProGuard rules required yet.
