# Clipora Product Specification

## Product
A template-driven Android editor where real video or an image can be placed inside reusable layouts and exported as video or static artwork.

## Output targets
- Video: MP4, H.264 + AAC planned
- Image: JPG planned; PNG later
- Ratios: 9:16, 16:9, 1:1, 4:5
- YouTube thumbnail preset: 1280x720 design target

## Theme engine
Built-in categories begin with News, Wedding, Birthday, Business and Custom.
Users will later be able to create, duplicate, save, edit and reuse their own themes.

A theme can contain:
- base video/image area
- logo
- headline
- scrolling ticker
- breaking-news/exclusive strip
- lower third
- location badge
- sponsor/ad area
- watermark
- text/image/shape/sticker layers
- audio/music and animations in video mode

## Monetisation
- One month free trial
- Paid subscription thereafter
- Reinstall must not restart the trial
- Entitlement restored from signed-in account + server + Google Play Billing state
