package com.clipora.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.clipora.app.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateProjectScreen(
    initialDraft: EditorDraft,
    onBack: () -> Unit,
    onOpenEditor: (EditorDraft) -> Unit
) {
    var draft by remember { mutableStateOf(initialDraft) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) draft = draft.copy(mediaUri = uri.toString())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (draft.kind == ProjectKind.VIDEO) "New Video" else "New Image") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
        ) {
            Text("Aspect ratio", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AspectRatioPreset.entries.forEach { preset ->
                    FilterChip(
                        selected = draft.aspectRatio == preset,
                        onClick = { draft = draft.copy(aspectRatio = preset) },
                        label = { Text(preset.label) }
                    )
                }
            }

            if (draft.kind == ProjectKind.VIDEO) {
                Spacer(Modifier.height(22.dp))
                Text("Target duration", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30, 60, 120).forEach { seconds ->
                        FilterChip(
                            selected = draft.durationSeconds == seconds,
                            onClick = { draft = draft.copy(durationSeconds = seconds) },
                            label = { Text(if (seconds < 60) "${seconds}s" else "${seconds / 60} min") }
                        )
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            Text("Media", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val type = if (draft.kind == ProjectKind.VIDEO) {
                        ActivityResultContracts.PickVisualMedia.VideoOnly
                    } else {
                        ActivityResultContracts.PickVisualMedia.ImageOnly
                    }
                    picker.launch(PickVisualMediaRequest(type))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (draft.mediaUri == null) "Choose media" else "Change media")
            }
            if (draft.mediaUri != null) {
                Spacer(Modifier.height(6.dp))
                Text("Media selected", color = MaterialTheme.colorScheme.primary)
            }

            Spacer(Modifier.height(22.dp))
            Text("Theme", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ThemePreset.entries.forEach { theme ->
                    FilterChip(
                        selected = draft.theme == theme,
                        onClick = { draft = draft.copy(theme = theme) },
                        label = { Text(theme.title) }
                    )
                }
            }

            Spacer(Modifier.weight(1f))
            Button(
                onClick = { onOpenEditor(draft) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Open Editor")
            }
        }
    }
}
