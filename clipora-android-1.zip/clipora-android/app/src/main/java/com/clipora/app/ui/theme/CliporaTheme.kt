package com.clipora.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CliporaColors = lightColorScheme(
    primary = Color(0xFF5A45D6),
    secondary = Color(0xFF6C5CE7),
    tertiary = Color(0xFFE94F64),
    background = Color(0xFFF7F7FA),
    surface = Color.White
)

@Composable
fun CliporaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CliporaColors,
        content = content
    )
}
