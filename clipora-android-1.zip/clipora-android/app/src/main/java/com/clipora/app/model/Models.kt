package com.clipora.app.model

enum class ProjectKind { VIDEO, IMAGE }

enum class AspectRatioPreset(val label: String, val ratio: Float) {
    VERTICAL_9_16("9:16", 9f / 16f),
    LANDSCAPE_16_9("16:9", 16f / 9f),
    SQUARE_1_1("1:1", 1f),
    PORTRAIT_4_5("4:5", 4f / 5f),
    YOUTUBE_THUMBNAIL("YouTube", 16f / 9f)
}

enum class ThemePreset(val title: String) {
    NEWS("News"),
    WEDDING("Wedding"),
    BIRTHDAY("Birthday"),
    BUSINESS("Business"),
    CUSTOM("Custom")
}

data class EditorDraft(
    val kind: ProjectKind = ProjectKind.VIDEO,
    val aspectRatio: AspectRatioPreset = AspectRatioPreset.VERTICAL_9_16,
    val durationSeconds: Int = 120,
    val mediaUri: String? = null,
    val theme: ThemePreset = ThemePreset.NEWS,
    val headline: String = "Your headline goes here",
    val ticker: String = "Breaking news • Add your scrolling message here",
    val logoText: String = "CLIPORA"
)
