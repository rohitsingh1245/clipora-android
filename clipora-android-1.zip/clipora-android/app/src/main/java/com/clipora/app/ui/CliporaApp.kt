package com.clipora.app.ui

import androidx.compose.runtime.*
import com.clipora.app.model.EditorDraft
import com.clipora.app.model.ProjectKind
import com.clipora.app.ui.screens.CreateProjectScreen
import com.clipora.app.ui.screens.EditorScreen
import com.clipora.app.ui.screens.HomeScreen
import com.clipora.app.ui.screens.LoginScreen

private enum class Screen { LOGIN, HOME, CREATE, EDITOR }

@Composable
fun CliporaApp() {
    var screen by rememberSaveable { mutableStateOf(Screen.LOGIN) }
    var draft by remember { mutableStateOf(EditorDraft()) }

    when (screen) {
        Screen.LOGIN -> LoginScreen(onContinue = { screen = Screen.HOME })
        Screen.HOME -> HomeScreen(
            onCreateVideo = {
                draft = EditorDraft(kind = ProjectKind.VIDEO)
                screen = Screen.CREATE
            },
            onCreateImage = {
                draft = EditorDraft(kind = ProjectKind.IMAGE)
                screen = Screen.CREATE
            }
        )
        Screen.CREATE -> CreateProjectScreen(
            initialDraft = draft,
            onBack = { screen = Screen.HOME },
            onOpenEditor = {
                draft = it
                screen = Screen.EDITOR
            }
        )
        Screen.EDITOR -> EditorScreen(
            initialDraft = draft,
            onDraftChanged = { draft = it },
            onBack = { screen = Screen.CREATE }
        )
    }
}
