package com.clipora.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clipora.app.ui.components.ChoiceCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onCreateVideo: () -> Unit,
    onCreateImage: () -> Unit
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Clipora", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
        ) {
            Text("Create something", fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Use the same theme engine for video, thumbnails and JPG posters.")
            Spacer(Modifier.height(22.dp))

            ChoiceCard(
                title = "Create Video",
                subtitle = "Import real video, choose ratio and duration, then add a reusable theme.",
                onClick = onCreateVideo
            )
            Spacer(Modifier.height(14.dp))
            ChoiceCard(
                title = "Create Thumbnail / Image",
                subtitle = "Create a static design using News, Wedding, Birthday or custom templates.",
                onClick = onCreateImage
            )
            Spacer(Modifier.height(14.dp))
            ChoiceCard(
                title = "My Themes",
                subtitle = "Theme saving and duplication is the next persistence milestone.",
                onClick = {}
            )
            Spacer(Modifier.height(14.dp))
            ChoiceCard(
                title = "My Projects",
                subtitle = "Saved projects will appear here after local persistence is connected.",
                onClick = {}
            )
        }
    }
}
