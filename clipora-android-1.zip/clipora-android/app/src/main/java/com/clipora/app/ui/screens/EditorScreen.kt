package com.clipora.app.ui.screens

import android.net.Uri
import android.widget.ImageView
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.clipora.app.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    initialDraft: EditorDraft,
    onDraftChanged: (EditorDraft) -> Unit,
    onBack: () -> Unit
) {
    var draft by remember { mutableStateOf(initialDraft) }
    var showExportMessage by remember { mutableStateOf(false) }

    fun update(next: EditorDraft) {
        draft = next
        onDraftChanged(next)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editor") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    TextButton(onClick = { showExportMessage = true }) { Text("Export") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
        ) {
            Spacer(Modifier.height(8.dp))
            ThemePreview(draft = draft)
            Spacer(Modifier.height(16.dp))

            Text("Theme", style = MaterialTheme.typography.titleMedium)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ThemePreset.entries.forEach { theme ->
                    FilterChip(
                        selected = draft.theme == theme,
                        onClick = { update(draft.copy(theme = theme)) },
                        label = { Text(theme.title) }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = draft.headline,
                onValueChange = { update(draft.copy(headline = it)) },
                label = { Text("Headline / title") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = draft.ticker,
                onValueChange = { update(draft.copy(ticker = it)) },
                label = { Text("Ticker / secondary text") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = draft.logoText,
                onValueChange = { update(draft.copy(logoText = it)) },
                label = { Text("Logo text") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (showExportMessage) {
                Spacer(Modifier.height(12.dp))
                Card {
                    Text(
                        text = if (draft.kind == ProjectKind.VIDEO)
                            "MP4 renderer is the next implementation milestone. The editor and media/template flow are working in this build."
                        else
                            "JPG renderer is the next implementation milestone. The editor and media/template flow are working in this build.",
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemePreview(draft: EditorDraft) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 460.dp),
        shape = RoundedCornerShape(20.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(draft.aspectRatio.ratio)
                .background(Color(0xFF15151A))
        ) {
            BaseMedia(draft)
            when (draft.theme) {
                ThemePreset.NEWS -> NewsOverlay(draft)
                ThemePreset.WEDDING -> WeddingOverlay(draft)
                ThemePreset.BIRTHDAY -> BirthdayOverlay(draft)
                ThemePreset.BUSINESS -> BusinessOverlay(draft)
                ThemePreset.CUSTOM -> CustomOverlay(draft)
            }
        }
    }
}

@Composable
private fun BaseMedia(draft: EditorDraft) {
    val value = draft.mediaUri
    if (value == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Your media", color = Color.White.copy(alpha = 0.55f), fontSize = 22.sp)
        }
        return
    }

    if (draft.kind == ProjectKind.VIDEO) {
        AndroidView(
            factory = { context ->
                VideoView(context).apply {
                    setVideoURI(Uri.parse(value))
                    setOnPreparedListener { player ->
                        player.isLooping = true
                        start()
                    }
                }
            },
            update = { view ->
                if (view.tag != value) {
                    view.tag = value
                    view.setVideoURI(Uri.parse(value))
                    view.setOnPreparedListener { player ->
                        player.isLooping = true
                        view.start()
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    } else {
        AndroidView(
            factory = { context ->
                ImageView(context).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageURI(Uri.parse(value))
                }
            },
            update = { view ->
                if (view.tag != value) {
                    view.tag = value
                    view.setImageURI(Uri.parse(value))
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun NewsOverlay(draft: EditorDraft) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("LIVE", color = Color.White, modifier = Modifier.background(Color(0xFFD22E3E)).padding(6.dp))
            Text(draft.logoText, color = Color.White, modifier = Modifier.background(Color.Black.copy(alpha = .65f)).padding(6.dp))
        }
        Spacer(Modifier.weight(1f))
        Text(
            draft.headline,
            color = Color.White,
            fontSize = 21.sp,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = .72f))
                .padding(10.dp)
        )
        Text(
            "BREAKING NEWS",
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFD22E3E))
                .padding(horizontal = 10.dp, vertical = 5.dp)
        )
        Text(
            draft.ticker,
            color = Color.White,
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = .88f))
                .padding(horizontal = 10.dp, vertical = 7.dp)
        )
    }
}

@Composable
private fun WeddingOverlay(draft: EditorDraft) {
    Box(Modifier.fillMaxSize()) {
        Text(
            draft.logoText,
            color = Color.White,
            modifier = Modifier.align(Alignment.TopCenter).padding(14.dp)
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.White.copy(alpha = .82f))
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Together Forever", fontSize = 22.sp)
            Text(draft.headline)
            Text(draft.ticker, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun BirthdayOverlay(draft: EditorDraft) {
    Column(
        Modifier.fillMaxSize().padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("HAPPY BIRTHDAY", color = Color.White, fontSize = 24.sp)
        Spacer(Modifier.weight(1f))
        Text(
            draft.headline,
            color = Color.White,
            modifier = Modifier.background(Color.Black.copy(alpha = .55f)).padding(10.dp)
        )
        Text(draft.ticker, color = Color.White, modifier = Modifier.padding(8.dp))
    }
}

@Composable
private fun BusinessOverlay(draft: EditorDraft) {
    Box(Modifier.fillMaxSize()) {
        Text(
            draft.logoText,
            color = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).background(Color.Black.copy(alpha = .6f)).padding(6.dp)
        )
        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth(.9f).background(Color.White.copy(alpha = .9f)).padding(12.dp)
        ) {
            Text(draft.headline, style = MaterialTheme.typography.titleMedium)
            Text(draft.ticker, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CustomOverlay(draft: EditorDraft) {
    Box(Modifier.fillMaxSize()) {
        Text(
            draft.headline,
            color = Color.White,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp).background(Color.Black.copy(alpha = .5f)).padding(10.dp)
        )
    }
}
